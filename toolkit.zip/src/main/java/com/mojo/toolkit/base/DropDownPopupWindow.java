package com.mojo.toolkit.base;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.PopupWindow;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.mojo.toolkit.R;
import com.mojo.toolkit.classes.AnimationUtil;
import com.mojo.toolkit.manager.InputManager;
import com.mojo.toolkit.utils.DecorViewUtil;
import com.mojo.toolkit.utils.ViewUtils;

import java.util.Timer;
import java.util.TimerTask;

public abstract class DropDownPopupWindow extends PopupWindow {
    public final Context mContext;
    private View rootView;
    private FrameLayout contentView;
    private int height = -2;

    private boolean fillWidth = true;
    private boolean fillHeight = true;

    public DropDownPopupWindow(Context mContext) {
        super(mContext);
        this.mContext = mContext;
        initView();
    }

    private void initView() {
        rootView = View.inflate(mContext, R.layout.view_drop_down_pop, null);
        contentView = rootView.findViewById(R.id.frame);
        contentView.setOnClickListener(view -> dismiss());
        this.setContentView(rootView);
        this.setFocusable(true);
        this.setBackgroundDrawable(new ColorDrawable(0x000000000));
        rootView.setOnClickListener(view -> dismiss());
    }

    public void setView(View view) {
        contentView.addView(view);
    }


    /**
     * @param fillWidth 是否横向占满全屏
     */
    public void setFillWidth(boolean fillWidth) {
        this.fillWidth = fillWidth;
    }

    /**
     * @param fillHeight 是否纵向占满全屏
     */
    public void setFillHeight(boolean fillHeight) {
        this.fillHeight = fillHeight;
        if (!fillHeight) {
            //必须设置，不然宽度总比设定宽度小一点，有空隙。
            Drawable drawable = ContextCompat.getDrawable(mContext, R.drawable.bg_radius);
            rootView.setBackground(drawable);
            contentView.setBackgroundColor(0x000000000);
            this.setBackgroundDrawable(drawable);
            this.setElevation(6);
        }
    }

    public void openPop(View view) {
        this.setWidth(fillWidth ? ViewGroup.LayoutParams.MATCH_PARENT : view.getWidth());
        this.setHeight(fillHeight ? measureDownSpaceHeight(view) : height);
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                if (!InputManager.isShow(mContext)) {
                    Message message = new Message();
                    message.obj = view;
                    handler.sendMessage(message);
                    this.cancel();
                }
            }
        }, 0, 1);
    }

    public void setPopHeight(int height) {
        this.height = height;
    }


    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            View view = (View) message.obj;
            showAsDropDown(view);
            if (fillHeight) {
                AnimationUtil.createAnimation(true, rootView, contentView, null);
            }
            return false;
        }
    });

    /**
     * @param view 计算占满view下方屏幕的高度s
     */
    private int measureDownSpaceHeight(View view) {
        int screenHeight = DecorViewUtil.getScreenHeight(mContext);
        int[] location = new int[2];
        view.getLocationInWindow(location);
        ViewUtils.getViewMeasuredHeight(view);
        return screenHeight - location[1] - view.getHeight();
    }


    public void closePop() {
        super.dismiss();
    }

    @Override
    public void dismiss() {
        //super.dismiss();
        //执行推出动画，列表上滑退出，同时背景变透明
        if (fillHeight) {
            //动画执行完毕后消失
            AnimationUtil.createAnimation(false, rootView, contentView, this::closePop);
        } else {
            super.dismiss();
        }

    }

}
