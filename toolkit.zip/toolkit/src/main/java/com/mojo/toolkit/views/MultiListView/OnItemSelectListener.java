package com.mojo.toolkit.views.MultiListView;

public interface OnItemSelectListener {
    void onItemSelect(MultiItem item);
}
