package com.mojo.toolkit.base;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.NonNull;

import com.mojo.toolkit.R;


public abstract class BaseDialog extends AlertDialog {
    public Context context;
    private WindowManager.LayoutParams params;
    private int width = 0;
    private int height = 0;

    public BaseDialog(@NonNull Context context) {
        super(context);
        this.context = context;
        init();
    }

    public BaseDialog(@NonNull Context context, int layoutId) {
        this(context);
        View view = View.inflate(context,layoutId,null);
        this.setContentView(view);
    }

    private void init() {
        this.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        params = this.getWindow().getAttributes();
        this.setView(getView());
    }

    public abstract View getView();

    /**
     * @param resourceId 背景资源Id
     */
    public void setBackground(int resourceId) {
        this.getWindow().setBackgroundDrawableResource(resourceId);
    }

    /**
     * @param resource 背景资源
     */
    public void setBackground(Drawable resource) {
        this.getWindow().setBackgroundDrawable(resource);
    }

    /**
     * @param width 设置宽度值
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * @param height 设置高度值
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * @param xOffset 弹窗横向的位置偏移量
     * @param yOffset 弹窗纵向的位置偏移量
     */
    public void setOffset(int xOffset, int yOffset) {
        params.horizontalMargin = xOffset;
        params.verticalMargin = yOffset;
    }

    @Override
    public void show() {
        super.show();
        if(width > 0  ){
            params.width = this.width;
        }
        if(height > 0){
            params.height = height;
        }
        this.getWindow().setAttributes(params);
    }

}
