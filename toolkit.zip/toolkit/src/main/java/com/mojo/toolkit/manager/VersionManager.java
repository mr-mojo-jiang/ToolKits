package com.mojo.toolkit.manager;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import com.google.gson.Gson;
import com.mojo.toolkit.R;
import com.mojo.toolkit.base.MyApplication;
import com.mojo.toolkit.classes.CustomToast;
import com.mojo.toolkit.classes.dialogs.LoadingDialog;
import com.mojo.toolkit.model.VersionInfo;
import com.mojo.toolkit.utils.DecimalUtil;
import com.mojo.toolkit.utils.http.DataRequest;
import com.mojo.toolkit.utils.http.DataRequestListener;
import com.mojo.toolkit.utils.http.FileDownLoadListener;
import com.mojo.toolkit.utils.http.FileRequest;
import com.mojo.toolkit.views.InfoTextView;
import com.mojo.toolkit.views.Progress.HorizontalProgressBar;
import com.qw.soul.permission.SoulPermission;
import com.qw.soul.permission.bean.Permission;
import com.qw.soul.permission.bean.Permissions;
import com.qw.soul.permission.callbcak.CheckRequestPermissionsListener;

import java.io.File;

public class VersionManager {
    private static final String TAG = VersionManager.class.getSimpleName();
    private final Context context;
    private LoadingDialog loadingDialog;
    private HorizontalProgressBar progressBar;
    private InfoTextView infoProgress;
    private boolean isLoad = false;
    private OnResultListener onResultListener;

    private VersionManager(Context context) {
        this.context = context;
    }

    public VersionManager setOnResultListener(OnResultListener onResultListener) {
        this.onResultListener = onResultListener;
        return this;
    }

    public static VersionManager getInstance(Context context) {
        return new VersionManager(context);
    }

    public void checkVersion(String url) {
        SoulPermission.getInstance()
                .checkAndRequestPermissions(Permissions.build(Manifest.permission.READ_EXTERNAL_STORAGE
                        ,Manifest.permission.WRITE_EXTERNAL_STORAGE), new CheckRequestPermissionsListener() {
            @Override
            public void onAllPermissionOk(Permission[] allPermissions) {
                DataRequest.getInstance()
                        .setRequestListener(versionListener)
                        .requestApi(url);
            }
            @Override
            public void onPermissionDenied(Permission[] refusedPermissions) {
                checkVersion(url);
            }
        });
    }

    /**
     * @param versionInfo 最新版本信息
     */
    private void verifyVersionInfo(VersionInfo versionInfo) {
        if (versionInfo.versionCode <= MyApplication.getVersion().versionCode) {
            Log.i(TAG, "已安装最新版本！");
            if(onResultListener!=null){
                onResultListener.onResult(false);
            }
            return;
        }
        LoadingDialog dialog = new LoadingDialog(context, R.layout.view_version_message);
        TextView title = dialog.findViewById(R.id.title);
        String str = "发现新版本  " + versionInfo.versionName;
        title.setText(str);
        TextView content = dialog.findViewById(R.id.tv_content);
        content.setText(versionInfo.updateContent);
        dialog.findViewById(R.id.btn_update).setOnClickListener(view -> {
            isLoad = true;
            dialog.dismiss();
            downloadApk(versionInfo.url,versionInfo.isForced());
        });

        View refuse = dialog.findViewById(R.id.btn_refuse);
        if(versionInfo.isForced()){
            refuse.setVisibility(View.GONE);
            dialog.setCancelable(false);
        }else {
            dialog.findViewById(R.id.btn_refuse).setOnClickListener(view -> {
                dialog.dismiss();
            });
            dialog.setOnDismissListener(dialogInterface -> {
                if (!isLoad)
                    CustomToast.build(context).showMsg("取消更新");
            });
        }
        dialog.show();
    }

    private void downloadApk(String url,boolean forced) {
        FileRequest fileRequest = FileRequest.getInstance(context)
                .setDownLoadListener(fileDownLoadListener);
        fileRequest.requestApi(url);
        loadingDialog = new LoadingDialog(context, R.layout.view_downloading);
        progressBar = loadingDialog.findViewById(R.id.progress_bar);
        infoProgress = loadingDialog.findViewById(R.id.info_progress);

        View cancelView =  loadingDialog.findViewById(R.id.btn_cancel);
        if(forced){
            cancelView.setVisibility(View.GONE);
        }else {
            cancelView.setOnClickListener(view -> {
                CustomToast.build(context).showMsg("取消更新");
                loadingDialog.dismiss();
                fileRequest.cancel();
            });
        }
        loadingDialog.show();
    }


    private void installApk(File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Uri uri;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);
        } else {
            uri = Uri.fromFile(file);
        }

        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 最新版本信息获取
     */
    private final DataRequestListener versionListener = new DataRequestListener() {
        @Override
        public void onFail(String msg) {
            Log.i(TAG, "onFail: "+msg);
        }

        @Override
        public void onSucceed(String result) {
            VersionInfo versionInfo = new Gson().fromJson(result, VersionInfo.class);
            verifyVersionInfo(versionInfo);
        }
    };

    /**
     * 下载进度监听
     */
    private final FileDownLoadListener fileDownLoadListener = new FileDownLoadListener() {
        @Override
        public void onSucceed(File file) {
            loadingDialog.dismiss();
            installApk(file);
        }

        @Override
        public void onFailed(String reason) {
            loadingDialog.dismiss();
            Log.i(TAG, "apk下载失败：" + reason);
        }

        @Override
        public void onLoading(double progress) {
            progressBar.setProcess((int) progress);
            String pro = DecimalUtil.value2String(progress, 1) + "%";
            infoProgress.setInfo(pro);
        }
    };

    public interface OnResultListener{
        void onResult(boolean hasNewVersion);
    }
}
