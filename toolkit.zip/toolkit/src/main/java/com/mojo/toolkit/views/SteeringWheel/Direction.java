package com.mojo.toolkit.views.SteeringWheel;

public class Direction {
    public static String ScaleUp = "放大";
    public static String ScaleDown = "缩小";
    public static String Left = "左";
    public static String Top = "上";
    public static String Right = "右";
    public static String Bottom = "下";
    public static String Null = "";
}
