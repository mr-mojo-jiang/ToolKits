package com.mojo.toolkit.base;

import android.content.Context;

/**
 * 用于对数据的处理分析，解析为View展示所用数据
 *
 * */
public abstract class BasePresenter<V extends BaseView ,M extends BaseModel<?,?>,CONTRACT> {
    public V view;
    public M model;
    public Context mContext;

    public BasePresenter(V view){
        this.view = view;//定义View
        this.model = getModelInstance();//定义Model
        this.mContext = view.getContext();
    }


    public void unBindView(){
        this.view = null;
    }

    public abstract M getModelInstance();
    public abstract CONTRACT getContract();

}
