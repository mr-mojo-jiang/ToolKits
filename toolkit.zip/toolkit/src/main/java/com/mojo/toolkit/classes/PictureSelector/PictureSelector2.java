package com.mojo.toolkit.classes.PictureSelector;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.util.Log;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.luck.picture.lib.basic.PictureSelector;
import com.luck.picture.lib.config.SelectMimeType;
import com.luck.picture.lib.entity.LocalMedia;
import com.luck.picture.lib.interfaces.OnResultCallbackListener;
import com.qw.soul.permission.SoulPermission;
import com.qw.soul.permission.bean.Permission;
import com.qw.soul.permission.callbcak.CheckRequestPermissionListener;

import java.util.ArrayList;
import java.util.List;

public class PictureSelector2 {
    private Activity mActivity;
    private Context mContext;
    private RecyclerView recyclerView;
    private PictureSelector selectionModel;
    private boolean permissionSelect;
    private PictureSelectorImageAdapter selectorAdapter;
    private int TypeOfSelect = SelectMimeType.ofImage();
    private List<LocalMedia> selectedList;
    private OnSelectChangeListener onSelectChangeListener;

    private PictureSelector2(Activity mContext) {
        this.mActivity = mContext;
        this.mContext = mContext;
    }

    public static PictureSelector2 build(Activity mContext) {
        return new PictureSelector2(mContext);
    }


    private PictureSelector2(Fragment mFragment) {
        this.mContext = mFragment.getContext();
        this.mActivity = mFragment.getActivity();
    }

    public static PictureSelector2 build(Fragment mFragment) {
        return new PictureSelector2(mFragment);
    }

    public PictureSelector2 setRecyclerView(RecyclerView recyclerView) {
        this.recyclerView = recyclerView;
        init();
        return this;
    }

    public void setOnSelectListener(OnSelectChangeListener onSelectChangeListener) {
        this.onSelectChangeListener = onSelectChangeListener;
    }

    public PictureSelector2 setTypeOfSelect(int typeOfSelect) {
        TypeOfSelect = typeOfSelect;
        return this;
    }

    public void init(){
        FullyGridLayoutManager manager = new FullyGridLayoutManager(mContext,3);
        recyclerView.setLayoutManager(manager);
        selectorAdapter = new PictureSelectorImageAdapter(mContext,addListener);
        recyclerView.setAdapter(selectorAdapter);
        selectedList = new ArrayList<>();
        requestPermissions();
        selectionModel = PictureSelector.create(mContext);
    }

    private void requestPermissions() {
        SoulPermission.getInstance()
                .checkAndRequestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE
                        , new CheckRequestPermissionListener() {
                            @Override
                            public void onPermissionOk(Permission permission) {
                                permissionSelect = true;
                            }

                            @Override
                            public void onPermissionDenied(Permission permission) {
                                permissionSelect = false;
                            }
                        });
    }

    public void startSelect(){
        Log.e("startSelect",permissionSelect+"...");
        if(permissionSelect){
            selectionModel.openGallery(TypeOfSelect)
                    .setImageEngine(GlideEngine.createGlideEngine())
                    .setOutputAudioDir("")
                    .setOutputAudioFileName("")
                    .setSelectedData(selectedList)
                    .forResult(onResultCallbackListener);
        }else {
            requestPermissions();
        }
    }

    private final OnResultCallbackListener<LocalMedia> onResultCallbackListener = new OnResultCallbackListener<LocalMedia>() {
        @Override
        public void onResult(ArrayList<LocalMedia> result) {
            selectedList = result;
            selectorAdapter.refreshList(selectedList);
            if(onSelectChangeListener !=null){
                onSelectChangeListener.onSelected(result);
            }
        }

        @Override
        public void onCancel() {

        }
    };

    private final PictureSelectorImageAdapter.onAddPicClickListener addListener = new PictureSelectorImageAdapter.onAddPicClickListener() {
        @Override
        public void onAddPicClick() {
            startSelect();
        }

        @Override
        public void onDelete(LocalMedia media) {
            if(onSelectChangeListener!=null)
                onSelectChangeListener.onDeleted(media);
        }
    };

    public List<LocalMedia> getSelectedList() {
        return selectedList;
    }

    public interface OnSelectChangeListener {
        void onSelected(List<LocalMedia> mediaList);
        void onDeleted(LocalMedia media);
    }
}
