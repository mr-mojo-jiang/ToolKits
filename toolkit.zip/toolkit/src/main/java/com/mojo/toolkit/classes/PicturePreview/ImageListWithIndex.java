package com.mojo.toolkit.classes.PicturePreview;

import java.io.Serializable;
import java.util.List;

public class ImageListWithIndex implements Serializable {
    public int index;
    public List<String> list;

    public ImageListWithIndex(int index,List<String> list){
        this.index = index;
        this.list = list;
    }
}
