package com.mojo.toolkit.utils.http;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import com.mojo.toolkit.utils.FileUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.ResponseBody;

public class FileRequest extends BaseRequest {
    private final Context context;
    private FileDownLoadListener fileDownLoadListener;

    private FileRequest(Context context) {
        super(FILE);
        this.context = context;
    }

    public static FileRequest getInstance(Context context) {
        return new FileRequest(context);
    }

    public FileRequest setDownLoadListener(FileDownLoadListener fileDownLoadListener) {
        this.fileDownLoadListener = fileDownLoadListener;
        return this;
    }

    @Override
    public void onFailed(String msg) {
        if (fileDownLoadListener != null) {
            fileDownLoadListener.onFailed(msg);
        }
    }

    @Override
    public void onSucceed(String result) {

    }

    @Override
    public void onSucceed(ResponseBody body) {
        InputStream is = null;
        byte[] buf = new byte[2048];
        FileOutputStream fos = null;
        // 储存下载文件的目录
        String savePath = FileUtil.createFile(context, "apks");
        try {
            if (body == null) return;
            is = body.byteStream();
            long total = body.contentLength();
            String fileName = url.substring(url.lastIndexOf("/") + 1);
            File file = new File(savePath, fileName);
            fos = new FileOutputStream(file);
            long sum = 0;
            int len;
            while (!isCancel && (len = is.read(buf)) != -1) {
                fos.write(buf, 0, len);
                sum += len;
                double progress = (sum * 1.0f / total * 100);
                sendMessage(2,progress);
            }
            fos.flush();
            if (file.exists()) {
                sendMessage(1,file);
            }else {
                sendMessage(0,"未找到文件！"+fos.toString());
            }
        } catch (Exception e) {
            sendMessage(0,e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (is != null)
                    is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (fos != null)
                    fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendMessage(int what,Object obj){
        Message msg = new Message();
        msg.what = what;
        msg.obj = obj;
        handler.sendMessage(msg);
    }

    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            switch (message.what) {
                case 0:
                    String msg = (String) message.obj;
                    if (fileDownLoadListener != null) {
                        fileDownLoadListener.onFailed(msg);
                    }
                    break;
                case 1:
                    File file = (File) message.obj;
                    if (fileDownLoadListener != null) {
                        fileDownLoadListener.onSucceed(file);
                    }
                    break;
                case 2:
                    double progress = (double) message.obj;
                    if (fileDownLoadListener != null) {
                        fileDownLoadListener.onLoading(progress);
                    }
                    break;
            }
            return false;
        }
    });

}
