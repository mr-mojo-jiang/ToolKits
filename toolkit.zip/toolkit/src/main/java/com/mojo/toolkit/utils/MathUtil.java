package com.mojo.toolkit.utils;

import org.opencv.core.Mat;

public class MathUtil {
    public static double sin(double angle) {
        return Math.sin(getRadian(angle));
    }

    public static double cos(double angle) {
        return Math.cos(getRadian(angle));
    }

    public static double tan(double angle) {
        return Math.tan(getRadian(angle));
    }

    static double getRadian(double angle) {
        return angle * 2 * Math.PI / 360;
    }
}
