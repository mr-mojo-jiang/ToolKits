package com.mojo.toolkit.classes;

public interface OnItemClickListener<T> {
    void onItemClick(T item);
}
