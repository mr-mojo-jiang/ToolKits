package com.mojo.toolkit.utils;

import android.graphics.drawable.Drawable;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

public class CompoundImageUtil {
    private final TextView view;
    private int width = 16;
    private int height = 16;
    private int iconPadding =4;
    private Location location = Location.Left;
    private CompoundImageUtil(TextView view) {
        this.view = view;
    }

    public static CompoundImageUtil build(TextView view){
        return new CompoundImageUtil(view);
    }

    public CompoundImageUtil setLocation(Location location) {
        this.location = location;
        return this;
    }

    public CompoundImageUtil setSize(int width,int height) {
        this.width = width;
        this.height = height;
        return this;
    }

    public CompoundImageUtil setIconPadding(int iconPadding) {
        this.iconPadding = iconPadding;
        return this;
    }

    public void setCompoundImage(int resId) {
        Drawable drawable = ContextCompat.getDrawable(view.getContext(), resId);
        int iconW = DensityUtil.dip2px(view.getContext(), width);
        int iconH = DensityUtil.dip2px(view.getContext(), height);
        if (drawable != null) {
            drawable.setBounds(0, 0, iconW, iconH);// 必须设置图片大小，否则不显示
        } else {
            return;
        }
        switch (location) {
            case Left:
                view.setCompoundDrawables(drawable, null, null, null);
                break;
            case Top:
                view.setCompoundDrawables(null, drawable, null, null);
                break;
            case Right:
                view.setCompoundDrawables(null, null, drawable, null);
                break;
            case Bottom:
                view.setCompoundDrawables(null, null, null, drawable);
                break;
        }
        view.setCompoundDrawablePadding(DensityUtil.dip2px(view.getContext(), iconPadding));//设置图片和text之间的间距
    }

    public enum Location {
        Left, Top, Right, Bottom
    }
}
