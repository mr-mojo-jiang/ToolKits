package com.mojo.toolkit.views.LineView;

public class PointLocation {
    private Location x;
    private Location y;

    public PointLocation(Location x, Location y) {
        this.x = x;
        this.y = y;
    }

    public Location getX() {
        return x;
    }

    public void setX(Location x) {
        this.x = x;
    }

    public Location getY() {
        return y;
    }

    public void setY(Location y) {
        this.y = y;
    }
}
