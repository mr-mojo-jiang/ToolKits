package com.mojo.toolkit.views.SteeringWheel;

public interface OnControlListener {
    void onChanged(String direction);
}
