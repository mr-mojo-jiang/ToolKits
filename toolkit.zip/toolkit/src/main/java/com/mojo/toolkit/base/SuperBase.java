package com.mojo.toolkit.base;

/**
 * 最顶层的父类
 * */
public abstract class SuperBase<CONTRACT> {

    public abstract CONTRACT getContact();
}
