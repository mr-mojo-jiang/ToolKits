package com.mojo.toolkit.utils.http;

public class DataRequest extends BaseRequest{
    private DataRequestListener  requestListener;

    public DataRequest() {
        super(DATA);
    }

    public static DataRequest getInstance(){
        return new DataRequest();
    }

    public DataRequest setRequestListener(DataRequestListener requestListener) {
        this.requestListener = requestListener;
        return this;
    }

    @Override
    public void onFailed(String msg) {
        if(requestListener != null){
            requestListener.onFail(msg);
        }
    }

    @Override
    public void onSucceed(String result) {
        if(requestListener != null){
            requestListener.onSucceed(result);
        }
    }

}
