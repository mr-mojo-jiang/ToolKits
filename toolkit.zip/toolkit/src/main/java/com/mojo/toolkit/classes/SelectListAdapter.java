package com.mojo.toolkit.classes;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mojo.toolkit.model.KeyValueItem;
import com.mojo.toolkit.utils.DensityUtil;

import java.util.ArrayList;
import java.util.List;

public class SelectListAdapter<T> extends RecyclerView.Adapter<SelectListAdapter.MyViewHolder> {
    private static final String TAG = SelectListAdapter.class.getSimpleName();
    private final Context mContext;
    private int selectIndex = 0;
    private List<KeyValueItem<T>> mItemList;
    private final int itemHeight;
    private final LinearLayout.LayoutParams params;
    private OnItemClickListener<KeyValueItem<T>> clickListener;

    public SelectListAdapter(Context context) {
        this.mContext = context;
        this.mItemList = new ArrayList<>();
        itemHeight = DensityUtil.dip2px(mContext, 28);
        params = new LinearLayout.LayoutParams(-1, itemHeight);
        params.topMargin = DensityUtil.dip2px(mContext, 4);
        params.bottomMargin = DensityUtil.dip2px(mContext, 4);
    }

    public void setItemList(List<KeyValueItem<T>> itemList) {
        this.mItemList = itemList;
        this.notifyItemRangeChanged(0, itemList.size());
    }


    public int getItemHeight() {
        return itemHeight;
    }

    public void setClickListener(OnItemClickListener<KeyValueItem<T>> clickListener) {
        this.clickListener = clickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        TextView view = new TextView(mContext);
        view.setLayoutParams(params);
        view.setTextSize(13);
        view.setGravity(Gravity.CENTER);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        KeyValueItem<T> item = mItemList.get(position);
        holder.text.setText(item.getKey());
        holder.text.setTextColor(selectIndex == position ? Color.BLACK : Color.GRAY);
        holder.text.setTextSize(selectIndex == position ? 14 : 13);
        holder.itemView.setOnClickListener(v -> {
            int id = selectIndex;
            selectIndex = holder.getAbsoluteAdapterPosition();
            SelectListAdapter.this.notifyItemChanged(id);
            SelectListAdapter.this.notifyItemChanged(selectIndex);
            if(clickListener != null){
                clickListener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public KeyValueItem<T> getSelectItem() {
        return mItemList == null || mItemList.isEmpty() ? null : mItemList.get(selectIndex);
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView text;

        MyViewHolder(View itemView) {
            super(itemView);
            text = (TextView) itemView;
            //initView
        }
    }
}