package com.mojo.toolkit.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class RvDecorationUtil {
    private final Paint mPaint;
    private int dividerColor = 0x0ffEEEEEE;
    //private int dividerColor = 0x0ff000000;
    private int dividerWidth;
    private int dividerHeight;

    private RvDecorationUtil(Context context) {
        dividerWidth = 1;
        dividerHeight = 1;
        mPaint = new Paint();
        mPaint.setColor(dividerColor);
    }

    public  RvDecorationUtil setDividerColor(int dividerColor) {
        this.dividerColor = dividerColor;
        if(dividerColor != 0){
            mPaint.setColor(dividerColor);
        }
        return this;
    }

    public RvDecorationUtil setDividerWidth(int dividerWidth) {
        this.dividerWidth = dividerWidth;
        return this;
    }

    public RvDecorationUtil setDividerHeight(int dividerHeight) {
        this.dividerHeight = dividerHeight;
        return this;
    }

    public static RvDecorationUtil build(Context context) {
        return new RvDecorationUtil(context);
    }

    public void setDividerIntoView(RecyclerView rv) {
        rv.addItemDecoration(new SimpleDividerDecoration());
    }

    class SimpleDividerDecoration extends RecyclerView.ItemDecoration {
        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);
            outRect.bottom = dividerHeight;
            outRect.right = dividerWidth;
        }

        @Override
        public void onDraw(@NonNull Canvas c, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            super.onDraw(c, parent, state);
            if(dividerColor != 0){
                drawDivider(c, parent);
            }
        }
    }

    private void drawDivider(Canvas canvas, RecyclerView parent) {
        RecyclerView.LayoutManager manager = parent.getLayoutManager();
        boolean isGrid = manager instanceof GridLayoutManager;
        boolean isHorizontal = manager instanceof LinearLayoutManager &&
                ((LinearLayoutManager) manager).getOrientation() == LinearLayoutManager.HORIZONTAL;
        int count = isGrid ? parent.getChildCount() : parent.getChildCount() - 1;
        for (int i = 0; i < count; i++) {
            final View child = parent.getChildAt(i);
            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) child.getLayoutParams();

            float vLeft = child.getLeft() - layoutParams.leftMargin;
            float vRight = child.getRight() + layoutParams.rightMargin;
            float vTop = child.getTop() - layoutParams.topMargin;
            float vBottom = child.getBottom() + layoutParams.bottomMargin;

            float top = child.getBottom() + layoutParams.bottomMargin;
            float bottom = top + dividerWidth;
            float left = child.getRight() + layoutParams.rightMargin;
            float right = left + dividerWidth;
            if (mPaint != null) {
                if (isHorizontal) {
                    canvas.drawRect(left, vTop, right, vBottom, mPaint);
                } else {
                    canvas.drawRect(vLeft, top, vRight, bottom, mPaint);
                    if (isGrid) {
                        canvas.drawRect(left, vTop, right, vBottom, mPaint);
                    }
                }
            }
        }
    }
}
