package com.mojo.toolkit.classes.dialogs;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.mojo.toolkit.R;
import com.mojo.toolkit.utils.DensityUtil;

public class WaitDialog {
    private final Context context;
    private AlertDialog alertDialog;
    private boolean isWaiting;
    private TextView tvMsg;
    private boolean cancelable = true;

    private WaitDialog(Context context){
        this.context = context;
        init();
    }

    public static WaitDialog build(Context context){
        return new WaitDialog(context);
    }

    private void init(){
        alertDialog = new AlertDialog.Builder(context).create();
        View view = View.inflate(context, R.layout.view_wait_dialog,null);
        ImageView img = view.findViewById(R.id.iconWait);
        Glide.with(context)
                .load(ContextCompat.getDrawable(context, R.drawable.loading_gif))
                .into(img);
        tvMsg = view.findViewById(R.id.tvWaitMsg);
        //设置Dialog背景
        alertDialog.getWindow().setBackgroundDrawable(ContextCompat.getDrawable(context,R.drawable.bg_toast));
        alertDialog.setView(view);
        alertDialog.setCancelable(cancelable);
        alertDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {

            }
        });
    }

    public void setCancelable(boolean cancelable) {
        this.cancelable = cancelable;
        alertDialog.setCancelable(cancelable);
    }

    public void setOnCancelListener(DialogInterface.OnCancelListener cancelListener){
        this.alertDialog.setOnCancelListener(cancelListener);
    }

    public void start(String msg){
        tvMsg.setText(msg);
        alertDialog.show();
        //设置Dialog宽高
        int wh = DensityUtil.dip2px(context,120);
        alertDialog.getWindow().setLayout(wh,wh);
        isWaiting = true;
    }

    public void stop(){
        isWaiting = false;
        if(alertDialog.isShowing()){
            alertDialog.dismiss();
        }
    }

    public boolean isWaiting() {
        return isWaiting;
    }
}
