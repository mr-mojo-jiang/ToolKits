package com.mojo.toolkit.classes.qrCode;

import android.content.Context;
import android.util.Log;


import com.king.wechat.qrcode.WeChatQRCodeDetector;

import org.opencv.OpenCV;

public class WeChatQrCodeConfig {
    private final Context mContext;
    private OnResultCallback onCallBack;

    private WeChatQrCodeConfig(Context mContext) {
        this.mContext = mContext;
        //初始化OpenCV
        OpenCV.initAsync(mContext);
        //初始化WeChatQRCodeDetector
        WeChatQRCodeDetector.init(mContext);
    }

    public static WeChatQrCodeConfig build(Context mContext) {
        return new WeChatQrCodeConfig(mContext);
    }

    public WeChatQrCodeConfig setOnResultCallBack(OnResultCallback onCallBack){
        Log.e("ConfigCallBack: ",onCallBack+"...." );
        this.onCallBack = onCallBack;
        return this;
    }

    public void startScan(){
        WeChartQrCodeActivity.startActivity(mContext,onCallBack);
    }

}
