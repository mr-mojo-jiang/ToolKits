package com.mojo.toolkit.views.check;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;


import com.mojo.toolkit.R;

import java.util.ArrayList;
import java.util.List;

public class CheckGroup extends LinearLayout {
    private List<CheckItem> checkItems = new ArrayList<>();
    //private int selectedId =-1;
    private final List<CheckBox> boxes = new ArrayList<>();
    private OnCheckedChangeListener changeListener;
    private boolean isSimple = true;//默认单选
    private List<String> multipleSelectResult;//多选结果
    private CheckBox checkedBox = null;

    public CheckGroup(Context context) {
        super(context);
    }

    public CheckGroup(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CheckGroup(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    /*  添加选项  */
    public void addStringItems(final List<String> strings){
        this.checkItems = new ArrayList<>();
        for(final String str:strings){
            final CheckBox box = (CheckBox) View.inflate(getContext(), R.layout.view_check_box,null);
            box.setText(str);
            if(strings.indexOf(str) != strings.size())
                box.setPadding(0,0,16,0);
            boxes.add(box);
            checkItems.add(new CheckItem(str));
            addView(box);

            box.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if(isSimple)
                    simpleCheckChanged(isChecked,box);

            });
        }
    }

    /*  添加选项  */
    public void addCheckItems(final List<CheckItem> items){
        this.checkItems = new ArrayList<>();
        this.checkItems.addAll(items);
        removeAllViews();
        for(int i = 0 ; i < checkItems.size() ; i++){//for(final CheckItem item: checkItems)
            final CheckItem item = checkItems.get(i);
            final CheckBox box = (CheckBox) View.inflate(getContext(), R.layout.view_check_box,null);
            box.setText(item.str);
            box.setId(i);
            box.setChecked(item.isChecked);
            if(item.isChecked)
                checkedBox = box;
            if(checkItems.indexOf(item) != checkItems.size())
                box.setPadding(0,0,16,0);
            boxes.add(box);
            addView(box);

            box.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isSimple )
                        simpleCheckChanged(isChecked, box);
                    //Log.e("Onclick",selectedId+"_"+finalI);
                }
            });
        }
    }
/*  添加选项  */
    public void addCheckItems(final List<CheckItem> items,boolean forbidChange){
        this.checkItems = new ArrayList<>();
        this.checkItems.addAll(items);
        removeAllViews();
        for(int i = 0 ; i < checkItems.size() ; i++){//for(final CheckItem item: checkItems)
            final CheckItem item = checkItems.get(i);
            final CheckBox box = (CheckBox) View.inflate(getContext(), R.layout.view_check_box,null);
            box.setText(item.str);
            box.setId(i);
            box.setChecked(item.isChecked);
            if(item.isChecked)
                checkedBox = box;
            if(checkItems.indexOf(item) != checkItems.size())
                box.setPadding(0,0,16,0);
            if(forbidChange)
                box.setEnabled(false);
            boxes.add(box);
            addView(box);

            box.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if( isSimple )
                        simpleCheckChanged(isChecked, box);
                }
            });
        }
    }

    /* 单选时需要对选择唯一性进行处理 */
    void simpleCheckChanged(boolean isChecked, CheckBox box){
        if(isChecked && checkedBox != box){
            if(checkedBox != null)
                checkedBox.setChecked(false);//取消之前选中项的选中状态
            checkedBox = box;
            checkedBox.setChecked(true);//设置新选中项的选中状态
        }
        if(changeListener != null){
            boolean hasChecked = false;//选项中有选中的项目
            for(CheckBox b:boxes){
                if(b.isChecked()){
                    hasChecked = true;
                            break;
                }
            }
            if(hasChecked)
                changeListener.onCheckedChanged(checkedBox.getText().toString());
            else
                changeListener.onCheckedChanged("未提交");
        }
    }

    public void enableMultipleCheck(){
        this.isSimple = false;
    }

    public interface OnCheckedChangeListener {
        void onCheckedChanged(String checkStr);
    }

    public void setOnChangeListener(OnCheckedChangeListener onChangeListener){
        this.changeListener = onChangeListener;
    }

    /* 获取单选选择结果 */
    public String getSimpleCheckResult(){
        if(isSimple){
            String str = null;
            for(CheckBox box:boxes){
                if (box.isChecked()){
                    str = box.getText().toString();
                }
            }
            return str;
        }else
            return null;
    }

    /* 获取多选选择结果 */
    public List<String> getMultipleCheckResult(){
        if(isSimple){
            return null;
        }else {
            List<String> multipleSelectResult = new ArrayList<>();
            for(CheckBox box:boxes){
                if (box.isChecked()){
                    multipleSelectResult.add( box.getText().toString());
                }
            }
            return multipleSelectResult;
        }
    }


    public static class CheckItem{
        public boolean isChecked;
        public String str;
        public CheckItem(boolean isChecked, String str){
            this.isChecked = isChecked;
            this.str = str;
        }
        public CheckItem( String str){
            this.isChecked = false;
            this.str = str;
        }
    }

}
