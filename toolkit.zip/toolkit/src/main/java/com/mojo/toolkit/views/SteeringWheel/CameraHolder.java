package com.mojo.toolkit.views.SteeringWheel;

import static android.graphics.BitmapFactory.decodeResource;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import com.mojo.toolkit.R;
import com.mojo.toolkit.utils.DensityUtil;

/**
 * 方向盘控制View
 */
public class CameraHolder extends ControlView {
    private Paint arrowPaint;
    private int center;
    private int pressIndex = 0;
    private float arrowW;
    private float arrowH;
    private Rect bgRect;

    public CameraHolder(Context context) {
        super(context);
    }

    public CameraHolder(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public CameraHolder(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    void initView() {
        arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arrowPaint.setStyle(Paint.Style.STROKE);
        arrowPaint.setStrokeCap(Paint.Cap.ROUND);
        arrowPaint.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                measurePressIndex(event.getX(), event.getY());
                if (onControlListener != null) {
                    disposeListener();
                }
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pressIndex = 0;
                if (onControlListener != null) {
                    onControlListener.onChanged(Direction.Null);
                }
                invalidate();
                performClick();
                break;
        }
        return true;
    }

    private void disposeListener() {
        String direction;
        switch (pressIndex) {
            case 1:
                direction = Direction.Left;
                break;
            case 2:
                direction = Direction.Top;
                break;
            case 3:
                direction = Direction.Right;
                break;
            case 4:
                direction = Direction.Bottom;
                break;
            default:
                direction = Direction.Null;
                break;
        }
        onControlListener.onChanged(direction);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    private void measurePressIndex(float ex, float ey) {
        float x = ex - center;
        float y = ey - center;
        if ((x * x + y * y) < center * center / 4f) {
            pressIndex = 0;
        } else if (x > 0 && y > 0) {
            pressIndex = x > y ? 3 : 4;
        } else if (x < 0 && y > 0) {
            pressIndex = Math.abs(x) > y ? 1 : 4;
        } else if (x < 0 && y < 0) {
            pressIndex = Math.abs(x) > Math.abs(y) ? 1 : 2;
        } else {
            pressIndex = x > Math.abs(y) ? 3 : 2;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Bitmap bg = decodeResource(getResources(), R.drawable.icon_camera_holder);
        canvas.drawBitmap(bg, null, bgRect, null);
        for (int i = 1; i < 5; i++) {
            drawArrowKey(canvas, i);
        }
    }

    float arrowDisToCenter;

    /**
     * 绘制按钮中的小三角
     */
    private void drawArrowKey(Canvas canvas, int index) {
        //双数：上下时
        boolean b = index % 2 == 0;
        //左上时为-
        int i = b ? index < 3 ? -1 : 1 : index < 2 ? -1 : 1;
        float[] p1 = new float[]{center + i * (b ? arrowW / 2 : arrowDisToCenter), center + i * (b ? arrowDisToCenter : arrowW / 2)};
        float[] p2 = new float[]{b ? center : p1[0] + i * arrowH, b ? p1[1] + i * arrowH : center};
        float[] p3 = new float[]{b ? center - i * arrowW / 2 : p1[0], b ? p1[1] : center - i * arrowW / 2};

        Path path = new Path();
        path.reset();
        LinearGradient shader = new LinearGradient(p2[0], p2[1], (p1[0] + p3[0]) / 2, (p1[1] + p3[1]) / 2
                , Color.parseColor(index == pressIndex ? "#1c439d" : "#92B4C8"), Color.parseColor(index == pressIndex ? "#00a1f4" : "#92B4C8"), Shader.TileMode.CLAMP);
        arrowPaint.setShader(shader);

        path.moveTo(p1[0], p1[1]);
        path.lineTo(p2[0], p2[1]);
        path.lineTo(p3[0], p3[1]);
        canvas.drawPath(path, arrowPaint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int wSize = MeasureSpec.getSize(widthMeasureSpec);
        int wMode = MeasureSpec.getMode(widthMeasureSpec);

        int hSize = MeasureSpec.getSize(widthMeasureSpec);
        int hMode = MeasureSpec.getMode(widthMeasureSpec);
        int size;
        if (wMode == MeasureSpec.AT_MOST && hMode == MeasureSpec.AT_MOST) {
            size = DensityUtil.dip2px(getContext(), 140);
        } else {
            size = Math.min(wSize, hSize);
        }
        setMeasuredDimension(size, size);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w == h) {
            center = w / 2;
        }
        arrowW = center / 5f;
        arrowH = center / 10f;
        arrowDisToCenter = center / 1.5f;
        bgRect = new Rect(0, 0, w, h);
        arrowPaint.setStrokeWidth(arrowH / 2);

    }

}
