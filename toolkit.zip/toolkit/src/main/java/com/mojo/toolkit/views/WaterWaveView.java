package com.mojo.toolkit.views;

import static android.graphics.BitmapFactory.decodeResource;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

import com.mojo.toolkit.R;

import java.util.ArrayList;
import java.util.List;

public class WaterWaveView extends androidx.appcompat.widget.AppCompatImageView {
    private Paint wavePaint;
    private Path path;
    private List<Point> points;
    private int waterLevel;
    private final int waveCount = 2;
    private ValueAnimator valueAnimator;
    private int waveLength;
    private int mOffset;

    public WaterWaveView(Context context) {
        this(context, null, 0);
    }

    public WaterWaveView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public WaterWaveView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        points = new ArrayList<>();
        wavePaint = new Paint();
        wavePaint.setStyle(Paint.Style.FILL);
        wavePaint.setColor(Color.BLUE);
        wavePaint.setAntiAlias(true);
        path = new Path();
    }

    public int getWaterLevel() {
        return waterLevel;
    }

    public void setWaterLevel(int waterLevel) {
        this.waterLevel = waterLevel;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        path.reset();
        path.moveTo(points.get(0).x + mOffset, points.get(0).y);
        for (int i = 0; i < waveCount; i++) {
            path.quadTo(points.get(i * 4 + 1).x + mOffset, points.get(i * 4 + 1).y, points.get(i * 4 + 2).x + mOffset, points.get(i * 4 + 2).y);
            path.quadTo(points.get(i * 4 + 3).x + mOffset, points.get(i * 4 + 3).y, points.get(i * 4 + 4).x + mOffset, points.get(i * 4 + 4).y);
        }
        path.lineTo(getWidth(),getHeight());
        path.lineTo(0,getHeight());
        path.lineTo(points.get(0).x + mOffset, points.get(0).y);
        canvas.drawPath(path, wavePaint);
        Bitmap normalFrameBitmap = decodeResource(getResources(), R.drawable.icon_water);
        dst.left = 0;
        dst.top = 0;
        dst.right = getWidth();
        dst.bottom = getHeight();
        canvas.drawBitmap(normalFrameBitmap, null, dst, null);
        super.onDraw(canvas);
    }

    Rect dst = new Rect();
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        waterLevel = h / 4;
        int amplitude = 6;
        //左侧多一个波，用于连续
        waveLength = w;
        points.add(new Point(-waveLength, waterLevel));
        for (int i = 0; i < waveCount; i++) {
            //上方控制点
            points.add(new Point(-waveLength * 3 / 4 + i * waveLength, waterLevel - amplitude * 2));
            //第一个结束点
            points.add(new Point(-waveLength / 2 + i * waveLength, waterLevel));
            //下方控制点
            points.add(new Point(-waveLength / 4 + i * waveLength, waterLevel + amplitude * 2));
            //第二个结束点
            points.add(new Point(i * waveLength, waterLevel));
        }
        LinearGradient linearGradient = new LinearGradient(w/2f, waterLevel, w/2f, h, 0x0ff96d9ff, 0x0ff48aaff, Shader.TileMode.MIRROR);
        wavePaint.setShader(linearGradient);
        startAnimation();
    }


    /**
     *波形动画
     */
    private void initAnimation() {
        valueAnimator = ValueAnimator.ofInt(0, waveLength);
        valueAnimator.setDuration(2000);
        valueAnimator.setStartDelay(300);
        valueAnimator.setRepeatCount(ValueAnimator.INFINITE);
        valueAnimator.setInterpolator(new LinearInterpolator());
        valueAnimator.addUpdateListener(animation -> {
            mOffset = (int) animation.getAnimatedValue();
            invalidate();
        });
        valueAnimator.start();
    }

    public void startAnimation() {
        initAnimation();
    }

    public void stopAnimation() {
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
    }

    public void pauseAnimation() {
        if (valueAnimator != null) {
            valueAnimator.pause();
        }
    }

    public void resumeAnimation() {
        if (valueAnimator != null) {
            valueAnimator.resume();
        }
    }

}
