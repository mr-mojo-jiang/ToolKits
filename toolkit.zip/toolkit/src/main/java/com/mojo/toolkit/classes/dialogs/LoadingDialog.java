package com.mojo.toolkit.classes.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.WindowManager;

import androidx.annotation.NonNull;

import com.mojo.toolkit.R;

public class LoadingDialog extends Dialog {
    private WindowManager.LayoutParams params;
    public LoadingDialog(@NonNull Context context) {
        super(context);
    }

    public LoadingDialog(@NonNull Context context, int layoutId) {
        this(context);
        this.setContentView(layoutId);
        this.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
    }

    @Override
    public void show() {
        super.show();
    }

    public void cancel(){

    }
}
