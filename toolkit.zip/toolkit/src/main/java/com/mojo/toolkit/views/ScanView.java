package com.mojo.toolkit.views;

import static android.graphics.BitmapFactory.decodeResource;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mojo.toolkit.utils.DensityUtil;

import java.util.Timer;
import java.util.TimerTask;

public class ScanView extends View {
    private int viewWidth, viewHeight;
    private int location = 0;
    private Rect dst;
    private int scanBeltWidth;
    private Bitmap bitmap;
    private Timer timer;
    private boolean scanning;

    public ScanView(Context context) {
        this(context, null);
    }

    public ScanView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    private void initView() {
        Paint paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setStrokeWidth(10);
        dst = new Rect();
        scanBeltWidth = DensityUtil.dip2px(getContext(), 80);
        bitmap = decodeResource(getResources(), com.mojo.toolkit.R.drawable.icon_scan_image);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        dst.left = 0;
        dst.top = location;
        dst.right = scanning? viewWidth:0;
        dst.bottom = location + scanBeltWidth;
        canvas.drawBitmap(bitmap, null, dst, null);
    }

    Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            if (location < viewHeight) {
                location += 8;
            } else {
                location = 0;
            }
            invalidate();
            return false;
        }
    });

    public void startScan() {
        scanning = true;
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.sendEmptyMessage(0);
            }
        }, 0, 10);
    }

    public void stopScan() {
        scanning = false;
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        viewWidth = w;
        viewHeight = h;
        startScan();
    }
}
