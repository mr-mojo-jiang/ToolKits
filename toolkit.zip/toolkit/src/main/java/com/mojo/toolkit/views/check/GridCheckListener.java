package com.mojo.toolkit.views.check;

import android.widget.CheckBox;

public interface GridCheckListener {
    void onChecked(CheckBox cb);
}
