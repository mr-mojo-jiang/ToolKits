package com.mojo.toolkit.views;

import android.content.Context;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.mojo.toolkit.classes.Pop.OnItemClickListener;
import com.mojo.toolkit.classes.Pop.PopSpinner;
import com.mojo.toolkit.model.KeyValueItem;

import java.util.List;

public class PopSpinnerView<T> extends StateTextView implements View.OnClickListener {
    private PopSpinner<T> popSpinner;
    private final Context context;
    private boolean enableSelect = true;
    private OnItemSelectListener<T> onSelectListener;
    private OnItemDeleteListener<T> onDeleteListener;
    private List<KeyValueItem<T>> mItemList;

    public PopSpinnerView(Context context) {
        this(context, null, 0);
    }

    public PopSpinnerView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PopSpinnerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        initView();
    }

    private void initView() {
        popSpinner = PopSpinner.build(context);
        popSpinner.setOnDismissListener(() -> {
            setState(false);
        });
        popSpinner.setOnItemClickListener(new OnItemClickListener<T>() {
            @Override
            public void onItemClick(KeyValueItem<T> item) {
                setText(item.getKey());
                if(onSelectListener!=null){
                    onSelectListener.onSelected(item);
                }
            }

            @Override
            public void onDelete(KeyValueItem<T> item) {
                if(onDeleteListener!=null){
                    onDeleteListener.onSelected(item);
                }
            }
        });
        this.setOnClickListener(this);
    }

    public boolean isEnableSelect() {
        return enableSelect;
    }

    public void setEnableSelect(boolean enableSelect) {
        this.enableSelect = enableSelect;
        enableImageChange(enableSelect);
    }

    public void setOnSelectListener(OnItemSelectListener<T> onSelectListener) {
        this.onSelectListener = onSelectListener;
    }

    public void setOnDeleteListener(OnItemDeleteListener<T> onDeleteListener) {
        this.onDeleteListener = onDeleteListener;
        popSpinner.setEnableDelete(true);
    }

    public void setItems(List<KeyValueItem<T>> itemList){
        if (itemList == null) return;
        this.mItemList = itemList;
        initViewWidth();
        this.setText(mItemList.isEmpty() ? "":mItemList.get(0).getKey());
        popSpinner.setItems(itemList);
        enableImageChange(enableSelect);
    }

    private void initViewWidth() {
        Paint paint = new Paint();
        paint.setTextSize(getTextSize());
        int mWidth = 0;
        for (KeyValueItem<T> item : mItemList) {
            mWidth = (int) Math.max(getSpace()+paint.measureText(item.getKey()), mWidth);
        }
        setWidth(mWidth);
    }

    public void setSelectValue(T value){
        if (mItemList == null ) return;
        for (KeyValueItem<T> item : mItemList) {
            if(item.getValue().equals(value)){
                popSpinner.setSelectItem(item);
                setText(item.getKey());
                break;
            }
        }
    }

    public void setSelectKey(String key){
        if (mItemList == null ) return;
        for (KeyValueItem<T> item : mItemList) {
            if(item.getKey().equals(key)){
                popSpinner.setSelectItem(item);
                setText(item.getKey());
                break;
            }
        }
    }

    public PopSpinner<T> getPopSpinner() {
        return popSpinner;
    }

    @Override
    public void onClick(View v) {
        if(enableSelect){
            if(getState()){
                popSpinner.openPop(this);
            }else {
                popSpinner.dismiss();
            }
        }
    }

    public KeyValueItem<T> getSelectItem() {
        return popSpinner.getSelectItem();
    }

    public interface OnItemSelectListener<T> {
        void onSelected(KeyValueItem<T> item);
    }

    public interface OnItemDeleteListener<T> {
        void onSelected(KeyValueItem<T> item);
    }
}
