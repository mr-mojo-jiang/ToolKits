package com.mojo.toolkit.classes.PicturePreview;

import android.content.Context;
import android.widget.Toast;

import com.luck.picture.lib.entity.LocalMedia;

import java.util.ArrayList;
import java.util.List;

public class PicturePreviewConfig {
    static String PREVIEW = "PreviewImages";

    public static void previewImageOfPath(Context context, List<String> imgStr){
        if(imgStr == null || imgStr.size() == 0){
            Toast.makeText(context,"暂无照片",Toast.LENGTH_SHORT).show();
            return;
        }
        PreviewActivity.start(context,new ImageListWithIndex(0,imgStr));
    }

    public static void previewInternetImages(Context context, List<String> imgStr,String baseUri){
        if(imgStr == null || imgStr.size() == 0){
            Toast.makeText(context,"暂无照片",Toast.LENGTH_SHORT).show();
            return;
        }
        List<String> mediaUrlList = new ArrayList<>();
        for(String str:imgStr){
            mediaUrlList.add(baseUri+str);
        }
        PreviewActivity.start(context,new ImageListWithIndex(0,mediaUrlList));
    }

    public static void previewImageOfPath(Context context, List<String> imgStr, int index){
        if(imgStr == null || imgStr.size() == 0){
            Toast.makeText(context,"暂无照片",Toast.LENGTH_SHORT).show();
            return;
        }
        PreviewActivity.start(context,new ImageListWithIndex(index,imgStr));
    }

    public static void previewImageOfMedia(Context context, List<LocalMedia> mediaList, int index){
        if(mediaList == null || mediaList.size() == 0){
            Toast.makeText(context,"暂无照片",Toast.LENGTH_SHORT).show();
            return;
        }
        List<String> pathList = new ArrayList<>();
        for (LocalMedia media : mediaList) {
            pathList.add(media.getPath());
        }
        ImageListWithIndex imageListWithIndex = new ImageListWithIndex(index,pathList);
        PreviewActivity.start(context,new ImageListWithIndex(index,pathList));
    }


}
