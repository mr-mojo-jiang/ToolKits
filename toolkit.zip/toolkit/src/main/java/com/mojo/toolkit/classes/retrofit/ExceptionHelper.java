package com.mojo.toolkit.classes.retrofit;

import android.util.Log;
import com.mojo.toolkit.base.MyApplication;

import java.net.ConnectException;
import java.net.SocketTimeoutException;


/*
 * 项目名:    Pigeon
 * 包名       cn.hjtech.directory.common.retroft
 * 文件名:    ExceptionHelper
 * 创建者:    ZJB
 * 创建时间:  2017/5/19 on 20:45
 * 描述:     TODO 异常抛出帮助类
 */
public class ExceptionHelper {

    public static String handleException(Throwable e) {
        e.printStackTrace();
        String error;
        if (e instanceof SocketTimeoutException) {//网络超时
            Log.e("TAG", "网络连接异常: " + e.getMessage());
            error = "网络连接异常";
            MyApplication.setResultToToast("网络连接异常，请检查网络状态和网络访问权限");
        } else if (e instanceof ConnectException) { //均视为网络错误
            Log.e("TAG", "网络连接异常: " + e.getMessage());
            MyApplication.setResultToToast("网络连接异常，请检查网络状态和网络访问权限");
            error = "网络连接异常";
        } else {  //均视为解析错误
            Log.e("TAG", "数据解析异常: " + e.getMessage());
            MyApplication.setResultToToast("数据解析异常");
            error = "数据解析异常";
        }
        return error;
    }

}