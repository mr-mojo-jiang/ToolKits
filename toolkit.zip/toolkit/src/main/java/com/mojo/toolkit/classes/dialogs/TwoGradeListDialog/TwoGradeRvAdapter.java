package com.mojo.toolkit.classes.dialogs.TwoGradeListDialog;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.mojo.toolkit.utils.DensityUtil;

import java.util.ArrayList;
import java.util.List;

public class TwoGradeRvAdapter extends RecyclerView.Adapter<TwoGradeRvAdapter.ViewHolder> {
    private final Context mContext;
    private final List<GradeItem> mItemList;
    private OnItemClickListener onItemClickListener;
    private final int ps1 = 20,ps2=40,pt = 14,pr = 14,pb = 14;

    public TwoGradeRvAdapter(Context mContext) {
        this.mContext = mContext;
        mItemList = new ArrayList<>();
    }

    public void setItemList(List<GradeItem> itemList) {
        this.mItemList.clear();
        this.mItemList.addAll(itemList) ;
        this.notifyItemRangeChanged(0,mItemList.size());
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public int getRvHeight(){
        int itemHeight = DensityUtil.dip2px(mContext,16+14*2);
        return Math.min(mItemList.size(),10)*itemHeight;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        TextView tvItem = new TextView(mContext);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(-1,-2);
        tvItem.setLayoutParams(params);
        tvItem.setTextSize(16);
        return new ViewHolder(tvItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        GradeItem item = mItemList.get(position);
        holder.tvItem.setText(item.getValue());
        if(item.isChild()){
            holder.tvItem.setPadding(ps2,pt,pr,pb);
            holder.tvItem.setTextColor(0x0ff262A2D);
        }else {
            holder.tvItem.setPadding(ps1,pt,pr,pb);
            holder.tvItem.setTextColor(0x0ff61686E);
        }
        holder.itemView.setOnClickListener(view -> {
            if(item.isChild() && onItemClickListener!=null){
                onItemClickListener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvItem;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItem = (TextView) itemView;
        }
    }

    public static interface OnItemClickListener {
        void onItemClick(GradeItem item);
    }
}
