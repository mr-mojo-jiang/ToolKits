package com.mojo.toolkit.views.LineView;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PathEffect;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.mojo.toolkit.utils.DensityUtil;


public class LineView extends LinearLayout {
    private String TAG = "LineView1";
    private final Context mContext;
    private final int dotRadius = 4;
    private Paint linePaint, framePaint;
    private Point stPoint, endPoint;
    private Point stRawPoint, endRawPoint;
    private PointLocation stPointLocation, endPointLocation;
    private boolean showFrame;

    public LineView(Context context) {
        this(context, null);
    }

    public LineView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public LineView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        initView();
    }

    private void initView() {
        linePaint = new Paint();
        linePaint.setAntiAlias(true);
        linePaint.setStrokeWidth(2);
        linePaint.setColor(Color.BLACK);

        framePaint = new Paint();
        framePaint.setAntiAlias(true);
        framePaint.setStrokeWidth(2);
        framePaint.setStyle(Paint.Style.STROKE);
        framePaint.setColor(Color.BLACK);
        PathEffect effect = new DashPathEffect(new float[]{1, 1}, 1);
        framePaint.setPathEffect(effect);
        stPoint = new Point();
        endPoint = new Point();
        stRawPoint = new Point();
        endRawPoint = new Point();
        ///setOnTouchListener(this);
        setBackgroundColor(0x000DDDDDD);
        stPointLocation = new PointLocation(Location.Left, Location.Top);
        endPointLocation = new PointLocation(Location.Right, Location.Bottom);
    }

    private Point touchPoint;
    private long downTime;
    private MarginLayoutParams params;
    private float stX, stY;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downTime = System.currentTimeMillis();
                setRawLocation();
                touchPoint = findTouchPoint(event.getX(), event.getY());
                stX = event.getRawX();
                stY = event.getRawY();
                params = (MarginLayoutParams) getLayoutParams();
                break;
            case MotionEvent.ACTION_MOVE:
                float offX = event.getRawX() - stX;
                float offY = event.getRawY() - stY;
                if (touchPoint != null) {
                    touchPoint.x += event.getRawX() - stX;
                    touchPoint.y += event.getRawY() - stY;
                    refreshLayout();
                } else {
                    params.leftMargin += offX;
                    params.topMargin += offY;
                    setLayoutParams(params);
                }
                stX = event.getRawX();
                stY = event.getRawY();
                break;
            case MotionEvent.ACTION_UP:
                setLayoutParams(params);
                if (System.currentTimeMillis() - downTime < 300) {
                    showFrame = !showFrame;
                    invalidate();
                }
                break;
        }
        performClick();
        return true;
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    private void refreshLayout() {
        int left, right, top, bottom;
        boolean b1 = stRawPoint.x <= endRawPoint.x;
        left = (b1 ? stRawPoint.x : endRawPoint.x) - dotRadius;
        right = (b1 ? endRawPoint.x : stRawPoint.x) + dotRadius;
        setLeft(left);
        setRight(right);
        stPointLocation.setX(b1 ? Location.Left : Location.Right);
        endPointLocation.setX(b1 ? Location.Right : Location.Left);

        boolean b2 = stRawPoint.y <= endRawPoint.y;
        top = (b2 ? stRawPoint.y : endRawPoint.y) - dotRadius;
        bottom = (b2 ? endRawPoint.y : stRawPoint.y) + dotRadius;
        stPointLocation.setY(b2 ? Location.Top : Location.Bottom);
        endPointLocation.setY(b2 ? Location.Bottom : Location.Top);
        setTop(top);
        setBottom(bottom);

        params.leftMargin = left;
        params.topMargin = top;
        params.width = right - left;
        params.height = getBottom() - getTop();
    }

    private void setRawLocation() {
        stRawPoint.x = getLocation(stPointLocation.getX());
        stRawPoint.y = getLocation(stPointLocation.getY());

        endRawPoint.x = getLocation(endPointLocation.getX());
        endRawPoint.y = getLocation(endPointLocation.getY());
    }

    private int getLocation(Location location) {
        switch (location) {
            case Left:
                return (int) (getLeft() + dotRadius / 2);
            case Right:
                return (int) (getRight() - dotRadius / 2);
            case Top:
                return (int) (getTop() + dotRadius / 2);
            default:
                return (int) (getBottom() + dotRadius / 2);
        }
    }

    private Point findTouchPoint(float x, float y) {
        float range = 50;
        if (range > Math.abs(x - endPoint.x) && range > Math.abs(y - endPoint.y)) {
            return endRawPoint;
        } else if (range > Math.abs(x - stPoint.x) && range > Math.abs(y - stPoint.y)) {
            return stRawPoint;
        }
        return null;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        initPoint();
        canvas.drawLine(stPoint.x, stPoint.y, endPoint.x, endPoint.y, linePaint);
        //画边框
        if (showFrame) {
            canvas.drawRect(0, 0, getWidth(), getHeight(), framePaint);
            canvas.drawCircle(stPoint.x, stPoint.y, dotRadius, linePaint);
            canvas.drawCircle(endPoint.x, endPoint.y, dotRadius, linePaint);
        }

    }

    private void initPoint() {
        stPoint.x = getBaseLocation(stPointLocation.getX());
        stPoint.y = getBaseLocation(stPointLocation.getY());
        endPoint.x = getBaseLocation(endPointLocation.getX());
        endPoint.y = getBaseLocation(endPointLocation.getY());
    }

    private int getBaseLocation(Location location) {
        switch (location) {
            case Left:
            case Top:
                return (int) dotRadius;
            case Right:
                return (int) (getWidth() - dotRadius);
            default:
                return (int) (getHeight() - dotRadius);
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        int defW = widthMode != MeasureSpec.AT_MOST ? width : DensityUtil.dip2px(mContext, 200);
        int defH = heightMode != MeasureSpec.AT_MOST ? height : DensityUtil.dip2px(mContext, 4);

        setMeasuredDimension(defW, defH);
    }

    public String getFinalSvgStr() {
        String s = "<line  id=\"svg_1\" y2=\"" + (params.leftMargin + getWidth()) + "\" x2=\"" + (params.topMargin + getHeight()) + "\"" +
                " y1=\"" + params.topMargin + "\" x1=\"" + params.leftMargin + "\" stroke=\"#00335588\"/>";
        return "<line  id=\"svg_1\" y2=\"" + (getTop() + endPoint.y) + "\" x2=\"" + (getLeft() + endPoint.x) + "\"" +
                " y1=\"" + (getTop() + stPoint.y) + "\" x1=\"" + (getLeft() + stPoint.x) + "\" stroke=\"#00335588\"/>";
    }
}
