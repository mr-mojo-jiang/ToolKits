package com.mojo.toolkit.views.MultiListView;

import android.app.Activity;
import android.view.ViewGroup;

import com.mojo.toolkit.classes.Pop.BottomPop;
import com.mojo.toolkit.classes.CustomToast;
import com.mojo.toolkit.utils.DensityUtil;

import java.util.List;

public class MultiListPop extends BottomPop {
    private MultiListView listView;
    private MultiItem searchItem;
    private OnConfirmListener onConfirmListener;
    private OnResetListener onResetListener;

    public MultiListPop(Activity mContext) {
        super(mContext);
    }

    @Override
    public void initView() {
        listView = new MultiListView(mContext);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(-1, DensityUtil.dip2px(mContext,360));
        listView.setLayoutParams(params);
        listView.setOnItemSelectListener(item -> {
            searchItem = item;
        });
        this.setView(listView);
    }

    public MultiListPop setListData(List<MultiItem> multiItems){
        listView.setData(multiItems);
        return this;
    }

    public void setOnConfirmListener(OnConfirmListener onConfirmListener) {
        this.onConfirmListener = onConfirmListener;
    }

    public void setOnResetListener(OnResetListener onResetListener) {
        this.onResetListener = onResetListener;
    }

    @Override
    public void onCancel() {
        if(onResetListener != null){
            onResetListener.onReset();
            dismiss();
        }
    }

    @Override
    public void onConfirm() {
        if(searchItem == null || !searchItem.isSearchable()){
            CustomToast.build(mContext).showMsg("请选择具体查询的设备");
            return;
        }
        if(onConfirmListener != null){
            onConfirmListener.onConfirm(searchItem);
            dismiss();
        }
    }

    public interface OnConfirmListener{
        void onConfirm(MultiItem item);
    }

    public interface OnResetListener{
        void onReset();
    }
}
