package com.mojo.toolkit.views.PercentChart;

import java.util.List;

public class BarChartItem {
    private String tag;
    private List<BarEntry> valueList;

    public BarChartItem() {
    }

    public BarChartItem(String tag, List<BarEntry> valueList) {
        this.tag = tag;
        this.valueList = valueList;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public List<BarEntry> getValueList() {
        return valueList;
    }

    public void setValueList(List<BarEntry> valueList) {
        this.valueList = valueList;
    }

    public float getSumValue() {
        float sum = 0;
        for (BarEntry entry : valueList) {
            sum += entry.value;
        }
        return sum;
    }
}
