package com.mojo.toolkit.datetime;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.haibin.calendarview.Calendar;
import com.haibin.calendarview.CalendarView;
import com.mojo.toolkit.R;
/**
 * 自定义日期选择组件，调用时需要引用原有库，否则会报错，找不到xml的attrs
 *引入：implementation 'com.haibin:calendarview:3.7.1'
 */
public class DatePickDialog extends Dialog {
    private final Context context;
    private int mYear, mMonth, mDay;
    private OnDateSelectListener onDateSelectListener;
    private OnDateSelectListener2 onDateSelectListener2;
    private CalendarView calendarView;

    public DatePickDialog(@NonNull Context context) {
        super(context);
        this.context = context;
        initView();
    }

    public static DatePickDialog build(Context context) {
        return new DatePickDialog(context);
    }

    private void initView() {
        View rootView = View.inflate(context, R.layout.view_date_picker, null);

        TextView tvMonth;
        tvMonth = rootView.findViewById(R.id.tv_month);
        calendarView = rootView.findViewById(R.id.calendarView);
        calendarView.setRange(2000, 1, 1, 2030, 12, 31);
        calendarView.scrollToCurrent();
        calendarView.setSelectDefaultMode();
        calendarView.setOnMonthChangeListener((year, month) -> {
            mYear = year;
            mMonth = month;
            String date = year + "年" + month + "月";
            tvMonth.setText(date);
        });
        calendarView.setOnCalendarSelectListener(new CalendarView.OnCalendarSelectListener() {
            @Override
            public void onCalendarOutOfRange(Calendar calendar) {

            }

            @Override
            public void onCalendarSelect(Calendar calendar, boolean isClick) {
                if (isClick) {
                    calendarView.clearSchemeDate();
                    calendarView.addSchemeDate(calendar);
                    mYear = calendar.getYear();
                    mMonth = calendar.getMonth();
                    mDay = calendar.getDay();
                    if (onDateSelectListener != null) {
                        onDateSelectListener.onSelected(CalendarDateUtil.getDate(calendar));
                        new Handler().postDelayed(() -> dismiss(), 100);
                    }
                    if (onDateSelectListener2 != null) {
                        onDateSelectListener2.onSelected(CalendarDateUtil.getDateStr(calendar));
                        new Handler().postDelayed(() -> dismiss(), 100);
                    }
                }
            }
        });
        mYear = calendarView.getCurYear();
        mMonth = calendarView.getCurMonth();
        mDay = calendarView.getCurDay();

        ImageView pre = rootView.findViewById(R.id.btn_pre);
        pre.setOnClickListener(view -> {
            if (mMonth == 1) {
                mYear -= 1;
            }
            mMonth = mMonth == 1 ? mMonth = 12 : mMonth - 1;
            calendarView.scrollToCalendar(mYear, mMonth, mDay, true);
        });

        ImageView next = rootView.findViewById(R.id.btn_next);
        next.setOnClickListener(view -> {
            if (mMonth == 12) {
                mYear += 1;
            }
            mMonth = mMonth == 12 ? mMonth = 1 : mMonth + 1;
            calendarView.scrollToCalendar(mYear, mMonth, mDay, true);
        });
        String date = mYear + "年" + mMonth + "月";
        tvMonth.setText(date);

        this.addContentView(rootView, new ViewGroup.LayoutParams(-1, -1));
        this.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
    }

    public DatePickDialog setOnDateSelectListener(OnDateSelectListener onDateSelectListener) {
        this.onDateSelectListener = onDateSelectListener;
        return this;
    }

    public DatePickDialog setOnDateSelectListener2(OnDateSelectListener2 onDateSelectListener2) {
        this.onDateSelectListener2 = onDateSelectListener2;
        return this;
    }
}
