package com.mojo.toolkit.datetime;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.Log;

import com.haibin.calendarview.Calendar;
import com.haibin.calendarview.RangeMonthView;

public class CustomRangeView extends RangeMonthView {
    private int mRadius;
    private boolean isStart, isEnd;

    public CustomRangeView(Context context) {
        super(context);
    }

    @Override
    protected void onPreviewHook() {
        mRadius = Math.min(mItemWidth, mItemHeight) / 2;
        mCurDayTextPaint.setColor(0x0ff1670FA);
        mSelectedPaint.setColor(0x0ff1670FA);
        mSelectTextPaint.setFakeBoldText(false);
        mCurMonthTextPaint.setFakeBoldText(false);
        mCurDayTextPaint.setFakeBoldText(false);
        mOtherMonthTextPaint.setFakeBoldText(false);
    }

    @Override
    protected boolean onDrawSelected(Canvas canvas, Calendar calendar, int x, int y, boolean hasScheme, boolean isSelectedPre, boolean isSelectedNext) {
        int cx = x + mItemWidth / 2;
        int cy = y + mItemHeight / 2;
        isStart = !isSelectedPre;
        isEnd = isSelectedPre && !isSelectedNext;
        if (isSelectedPre) {
            if (isSelectedNext) {//中间日期
                mSelectedPaint.setColor(0x0661670FA);
                canvas.drawRect(x, cy - mRadius, x + mItemWidth, cy + mRadius, mSelectedPaint);
            } else {//最后一个，the last
                mSelectedPaint.setColor(0x0661670FA);
                canvas.drawRect(x, cy - mRadius, cx, cy + mRadius, mSelectedPaint);
                mSelectedPaint.setColor(0x0ff1670FA);
                canvas.drawCircle(cx, cy, mRadius, mSelectedPaint);
                //canvas.drawText();
            }
        } else {//开始日期
            if (isSelectedNext) {
                mSelectedPaint.setColor(0x0661670FA);
                canvas.drawRect(cx, cy - mRadius, x + mItemWidth, cy + mRadius, mSelectedPaint);
            }
            mSelectedPaint.setColor(0x0ff1670FA);
            canvas.drawCircle(cx, cy, mRadius, mSelectedPaint);
        }
        return true;
    }

    @Override
    protected void onDrawScheme(Canvas canvas, Calendar calendar, int x, int y, boolean isSelected) {

    }

    @Override
    protected void onDrawText(Canvas canvas, Calendar calendar, int x, int y, boolean hasScheme, boolean isSelected) {
        float baselineY = mTextBaseLine + y;
        int cx = x + mItemWidth / 2;

        boolean isInRange = isInRange(calendar);
        boolean isEnable = !onCalendarIntercept(calendar);


        if (isSelected) {
            String s = String.valueOf(calendar.getDay());
            Paint tPaint = new Paint(mSelectTextPaint);
            if (isStart) {//stX == x && stY == y
                s = "开始";
                tPaint.setTextSize(mSelectTextPaint.getTextSize() - 8);
                baselineY -= 4;
            }
            if (isEnd) {//enX == x && enY == y
                s = "结束";
                tPaint.setTextSize(mSelectTextPaint.getTextSize() - 8);
                baselineY -= 4;
            }
            canvas.drawText(s, cx, baselineY, tPaint);
        }  else {
            Paint paint = calendar.isCurrentDay() ? mCurDayTextPaint :
                    calendar.isCurrentMonth() && isInRange && isEnable ? mCurMonthTextPaint : mOtherMonthTextPaint;
            canvas.drawText(String.valueOf(calendar.getDay()), cx, baselineY,paint );
        }
    }
}
