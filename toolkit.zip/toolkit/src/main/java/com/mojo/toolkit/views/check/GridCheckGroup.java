package com.mojo.toolkit.views.check;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.GridLayout;

import java.util.ArrayList;
import java.util.List;

public class GridCheckGroup extends GridLayout {
    private GridCheckListener checkListener;
    private final List<CheckBox> checkBoxList;
    private boolean isMulti;//是否多选
    private int selectIndex = 0;//默认选中第一个

    public GridCheckGroup(Context context) {
        this(context,null,0);
    }

    public GridCheckGroup(Context context, AttributeSet attrs) {
        this(context,attrs,0);
    }

    public GridCheckGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        checkBoxList = new ArrayList<>();

    }

    public void setCheckListener(GridCheckListener checkListener) {
        this.checkListener = checkListener;
        invalidate();
    }

    public void setMulti(boolean multi) {
        isMulti = multi;
        invalidate();
    }

    public void setSelectIndex(int selectIndex) {
        this.selectIndex = selectIndex;
        invalidate();
    }

    @Override
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        if (child instanceof CheckBox) {
            CheckBox cb = (CheckBox) child;
            if(index == 0)cb.setChecked(true);
            checkBoxList.add(cb);
            cb.setOnCheckedChangeListener((v, b) -> {
                disposeCheck((CheckBox) v,b);

            });
        }
        super.addView(child, index, params);
    }

    private void disposeCheck(CheckBox cb,boolean checked){
        if(isMulti)return;//多选就不做处理
        int index = checkBoxList.indexOf(cb);
        if(checked && selectIndex != index){
            int id = selectIndex;
            selectIndex = index;
            checkBoxList.get(id).setChecked(false);
        }else if(selectIndex == index) {
            checkBoxList.get(selectIndex).setChecked(true);
        }
        if(checkListener != null){
            checkListener.onChecked(checkBoxList.get(selectIndex));
        }
    }
}
