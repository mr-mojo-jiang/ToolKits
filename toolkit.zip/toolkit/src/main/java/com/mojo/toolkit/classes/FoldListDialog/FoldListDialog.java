package com.mojo.toolkit.classes.FoldListDialog;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.gson.Gson;
import com.mojo.toolkit.R;
import com.mojo.toolkit.base.BaseDialog;
import com.mojo.toolkit.classes.OnItemClickListener;
import com.mojo.toolkit.classes.dialogs.CustomDialog;
import com.mojo.toolkit.model.FoldItem;
import com.mojo.toolkit.utils.RvDecorationUtil;
import com.mojo.toolkit.utils.ScreenSizeUtils;

import java.util.List;

public class FoldListDialog<T> extends BaseDialog {
    private OnItemClickListener<FoldItem<T>> onSelectListener;
    private FoldListAdapter<T> rvAdapter;
    private int width;

    public FoldListDialog(@NonNull Context context) {
        super(context);
    }

    @Override
    public View getView() {
        RecyclerView recyclerView = new RecyclerView(context);
        recyclerView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        rvAdapter = new FoldListAdapter<>(context);
        recyclerView.setAdapter(rvAdapter);
        recyclerView.setBackgroundResource(R.color.white_bg);
        RvDecorationUtil.build(context).setDividerIntoView(recyclerView);
        width = (int) (ScreenSizeUtils.getInstance(this.context).getScreenWidth() * 0.8);
        return recyclerView;
    }

    public void setGradeItemList(List<FoldItem<T>> gradeItemList) {
        rvAdapter.setOnItemClickListener(onItemClickListener);
        rvAdapter.setItemList(gradeItemList);
    }

    public void setOnItemSelectedListener(OnItemClickListener<FoldItem<T>> onSelectListener) {
        this.onSelectListener = onSelectListener;
    }

    public int getSelectSum() {
        return rvAdapter.getItemCount();
    }

    private final FoldListAdapter.OnItemClickListener<T> onItemClickListener = new FoldListAdapter.OnItemClickListener<T>() {
        @Override
        public void onItemClick(FoldItem<T> item) {
            if (onSelectListener != null) {
                onSelectListener.onItemClick(item);
            }
            dismiss();
        }

        @Override
        public void onExpand() {
            refreshLayout();
        }
    };

    public FoldListDialog<T> setPercentWidth(float percent) {
        width = (int) (ScreenSizeUtils.getInstance(this.context).getScreenWidth() * percent);
        return this;
    }

    @Override
    public void show() {
        refreshLayout();
        super.show();
    }

    private void refreshLayout() {
        this.setWidth(width);
        int height = rvAdapter.getRvHeight();
        this.setHeight(height);
    }
}
