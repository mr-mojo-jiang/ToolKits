package com.mojo.toolkit.manager;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;

import com.mojo.toolkit.utils.DecorViewUtil;

public class InputManager {

    /**
     * 获取软键盘
     */
    public static InputMethodManager getImm(Context context){
        return (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    /**
     * 隐藏软键盘
     */
    public static void hindKeyboard(Context context){
        if(isShow(context)) {
            InputMethodManager imm = getImm(context);
            imm.hideSoftInputFromWindow(DecorViewUtil.getDecorView(context).getWindowToken(), 0);
        }
    }

    /**
     * @return 软键盘是否弹出
     */
    public static boolean isShow(Context context){
        Rect rect = new Rect();
        DecorViewUtil.getDecorView(context).getWindowVisibleDisplayFrame(rect);
        return DecorViewUtil.getDecorView(context).getHeight() - rect.bottom > 0;
    }


}
