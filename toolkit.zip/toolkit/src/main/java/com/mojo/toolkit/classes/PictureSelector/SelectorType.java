package com.mojo.toolkit.classes.PictureSelector;

public class SelectorType {
    public final static int TYPE_ALL = 0;
    public final static int TYPE_IMAGE = 1;
    public final static int TYPE_VIDEO = 2;
    public final static int TYPE_AUDIO = 3;
}
