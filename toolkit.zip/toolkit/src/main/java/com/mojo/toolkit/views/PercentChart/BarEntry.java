package com.mojo.toolkit.views.PercentChart;

public class BarEntry {
    public String tag;
    public float value;

    public BarEntry(String tag, float value) {
        this.tag = tag;
        this.value = value;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public float  getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }
}
