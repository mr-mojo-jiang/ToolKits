package com.mojo.toolkit.classes;

import android.content.Context;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;

import com.google.gson.Gson;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StaticMethod {

    public static <T> List<T> getList(Class<T[]> clazz, final String json){
        final T[] jsonToObject = new Gson().fromJson(json,clazz);
        return Arrays.asList(jsonToObject);
    }

    public static List<String> strSplit(String targetStr, String baseStr){
        List<String> list = new ArrayList<>();
        if(targetStr != null){
            if(targetStr.contains(baseStr)){
                String[] normalOptions = targetStr.split(baseStr);
                list = Arrays.asList(normalOptions);
            }else {
                list.add(targetStr);
            }
        }
        return list;
    }


    /**
     * 将数据保存两位小数
     * @param valueStr
     * @return
     */
    public static String ValueofTwoBit(String valueStr) {
        DecimalFormat df = new DecimalFormat( "0.00");
        return df.format(Double.parseDouble(valueStr));
    }

    /*
    将数据保存四位小数
     */
    public static String ValueofFourBit(String valueStr) {
        DecimalFormat df = new DecimalFormat( "0.0000");
        return df.format(Double.parseDouble(valueStr));
    }
    /**
     *
     */

    public static int dptoint(Context context, int dp){
        int result  = ((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,context.getResources().getDisplayMetrics()));
        return result;
    }

    public static Double strToFourBitDouble(String valueStr){
        DecimalFormat df = new DecimalFormat( "0.0000");
        String doublestr =  df.format(Double.parseDouble(valueStr));
        return Double.parseDouble(doublestr);
    }

    public static String CutoutStr(String str){
        String keyword = "#";
        int k = str.indexOf(keyword);
        if(k != -1 )
            str = str.substring(k+1);
        //Log.e("截取结果",str);
        return str;
    }

    public static String escapeExprSpecialWord(String keyword) {
        if (!TextUtils.isEmpty(keyword)) {
            String[] fbsArr = { "\\", "$", "(", ")", "*", "+", ".", "[", "]", "?", "^", "{", "}", "|" };
            for (String key : fbsArr) {
                if (keyword.contains(key)) {
                    keyword = keyword.replace(key, "\\" + key);
                }
            }
        }
        return keyword;
    }

    /**
     * 取消软键盘，传入参数，1.上下文context，2.空白layout
     *
     * @param context
     * @param layout
     */

    public static void exitSoftKeyboard(final Context context, final LinearLayout layout){
        //点击界面空白处收起输入栏
        layout.setFocusable(true);
        layout.setFocusableInTouchMode(true);
        layout.requestFocus();
        layout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                InputMethodManager imm = (InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(layout.getWindowToken(), 0);
                return false;
            }
        });
    }

}
