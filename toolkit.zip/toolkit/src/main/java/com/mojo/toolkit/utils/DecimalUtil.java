package com.mojo.toolkit.utils;

import android.util.Log;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.regex.Pattern;

public class DecimalUtil {
    private static final String TAG = "DecimalUtil";
    public static String format1(double value){
        BigDecimal bd = new BigDecimal(value);//创建一个bd对象，将要转换的值value传入构造函数
        bd = bd.setScale(2, RoundingMode.HALF_UP);//调用setScale方法进行数据格式化，保留两位小数，采用四舍五入规则
        return bd.toString(); //返回bd对象的值（转化为string形式）
    }

    /**
     * @param value 需要转换的值
     * @param number 小数点后数量
     * @return 返回String类型
     */
    public static String value2String(double value,int number) {
        StringBuilder format = new StringBuilder("0.");
        for (int i = 0; i < number; i++) {
            format.append("0");
        }
        DecimalFormat df = new DecimalFormat(format.toString());//创建一个df对象，传入0.00表示构造一个保留小数点后两位的df对象
        df.setRoundingMode(RoundingMode.HALF_UP);//设置规则，这里采用的也是四舍五入规则
        return df.format(value);//返回value（在返回之前使用df对象的格式化方法将数据格式化）
    }

    /**
     * @param value 需要转换的值
     * @param number 小数点后数量
     * @return 返回String类型
     */
    public static double value2Value(double value,int number) {
        return Double.parseDouble(value2String(value,number)) ;//返回value（在返回之前使用df对象的格式化方法将数据格式化）
    }

    /**
     * @param value 需要转换的值
     * @param number 小数点后数量
     * @return 返回String类型
     */
    public static double splitDouble(double value,int number) {
        StringBuilder format = new StringBuilder("0.");
        for (int i = 0; i < number; i++) {
            format.append("0");
        }
        DecimalFormat df = new DecimalFormat(format.toString());//创建一个df对象，传入0.00表示构造一个保留小数点后两位的df对象
        df.setRoundingMode(RoundingMode.HALF_UP);//设置规则，这里采用的也是四舍五入规则
        return Double.parseDouble(df.format(value));//返回value（在返回之前使用df对象的格式化方法将数据格式化）
    }

    public static String string2String(String valueStr,int number) {
        if(isNumber(valueStr)){
            if(valueStr.contains(".")){
                int index = valueStr.indexOf(".");
                if(valueStr.length() - index <number){
                    return valueStr;
                }
                double value = Double.parseDouble(valueStr);
                return value2String(value,number);
            }
        }else {
            Log.d(TAG, "格式错误，传入String无法转换为double！");
        }
        return valueStr;
    }

    /**
     * 判断字符串是否支持转换为数字
     * 正则表达式
     * @param string 字符串
     * @return true = 是数字
     */
    public static boolean isNumber(String string) {
        if (string == null)
            return false;
        Pattern pattern = Pattern.compile("^-?\\d+(\\.\\d+)?$");
        return pattern.matcher(string).matches();
    }
}
