package com.mojo.toolkit.utils.http;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public abstract class BaseRequest {
    public String url;
    public static int FILE = 0;
    public static int DATA = 1;
    private final int type;
    private Call call;
    public boolean isCancel;
    Response response;
    private Thread thread;

    public BaseRequest(int requestType) {
        this.type = requestType;
    }

    public void requestApi(String url) {
        this.url = url;
        OkHttpClient okHttpClient = new OkHttpClient.Builder().build();
        Request request = new Request.Builder().url(url).build();

        thread = new Thread(() -> {
            call = okHttpClient.newCall(request);

            call.enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    // 下载失败
                    e.printStackTrace();
                    Message message = new Message();
                    message.what = 0;
                    message.obj = e.getMessage();
                    handler.sendMessage(message);
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) {
                    BaseRequest.this.response = response;
                    ResponseBody body = response.body();
                    if (body == null) return;
                    if (type == 0) {
                        onSucceed(body);
                    } else {
                        try {
                            Message message = new Message();
                            message.what = 1;
                            message.obj = body.string();
                            handler.sendMessage(message);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        });
        thread.start();

    }

    /**
     * 取消请求
     */
    public void cancel() {
        call.cancel();
        this.isCancel = true;
    }

    /**
     * 请求失败回调，无需使用Handler处理
     *
     * @param msg 失败原因
     */
    public abstract void onFailed(String msg);

    /**
     * 请求成功回调，更新UI时需要使用Handler处理
     *
     * @param result 返回json
     */
    protected void onSucceed(String result) {
    }

    /**
     * 请求成功回调，更新UI时无需使用Handler处理
     *
     * @param body 返回body
     */
    protected void onSucceed(ResponseBody body) {
    }


    Handler handler = new Handler(message -> {
        String msg = (String) message.obj;
        if (message.what == 0 || msg.contains("html")) {
            msg = msg.contains("html") ? msg.substring(msg.indexOf("<h1>") + 4, msg.indexOf("</h1>")) : msg;
            onFailed(msg);
        } else {
            onSucceed(msg);
        }
        return false;
    });

}
