package com.mojo.toolkit.classes.qrCode;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.king.mlkit.vision.camera.AnalyzeResult;
import com.king.wechat.qrcode.WeChatQRCodeDetector;
import com.king.wechat.qrcode.scanning.WeChatCameraScanActivity;
import com.luck.picture.lib.basic.PictureSelector;
import com.luck.picture.lib.config.SelectMimeType;
import com.luck.picture.lib.entity.LocalMedia;
import com.luck.picture.lib.interfaces.OnResultCallbackListener;
import com.mojo.toolkit.R;
import com.mojo.toolkit.classes.PictureSelector.GlideEngine;
import com.mojo.toolkit.classes.StaticMethod;
import com.mojo.toolkit.classes.dialogs.WaitDialog;
import com.mojo.toolkit.utils.CompoundImageUtil;
import com.mojo.toolkit.utils.StatusBarUtils;
import com.mojo.toolkit.views.ScanView;
import com.qw.soul.permission.SoulPermission;
import com.qw.soul.permission.bean.Permission;
import com.qw.soul.permission.bean.Permissions;
import com.qw.soul.permission.callbcak.CheckRequestPermissionsListener;

import java.util.ArrayList;
import java.util.List;

public class WeChartQrCodeActivity extends WeChatCameraScanActivity {
    private static OnResultCallback mOnCallBack;
    private Context context;
    private boolean light = false;
    private ScanView scanView;
    private WaitDialog waitDialog;

    static void startActivity(Context context, OnResultCallback onCallBack) {
        mOnCallBack = onCallBack;
        context.startActivity(new Intent(context, WeChartQrCodeActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StatusBarUtils.with(this).init();
        context = this;
        findViewById(R.id.btn_back).setOnClickListener(view -> {
            this.finish();
        });

        initView();
    }

    private void initView() {
        scanView = findViewById(R.id.scan_view);

        TextView torchControl = findViewById(R.id.torch_control);
        torchControl.setText(light ? "轻触关闭" : "轻触打开");
        CompoundImageUtil imageUtil = CompoundImageUtil.build(torchControl)
                .setSize(40, 66)
                .setLocation(CompoundImageUtil.Location.Top);
        imageUtil.setCompoundImage(R.drawable.icon_torch_off);
        torchControl.setOnClickListener(view -> {
            light = !light;
            getCameraScan().enableTorch(light);
            imageUtil.setCompoundImage(light ? R.drawable.icon_torch_on : R.drawable.icon_torch_off);
            torchControl.setText(light ? "轻触关闭" : "轻触打开");
        });

        TextView pictureSelector = findViewById(R.id.picture_select);
        CompoundImageUtil.build(pictureSelector)
                .setSize(26, 20)
                .setLocation(CompoundImageUtil.Location.Top)
                .setCompoundImage(R.drawable.icon_album);
        pictureSelector.setOnClickListener(view -> pictureSelect());
    }

    private void pictureSelect() {
        if (waitDialog == null) waitDialog = WaitDialog.build(context);
        getCameraScan().setAnalyzeImage(false);
        scanView.stopScan();
        PictureSelector.create(this)
                .openGallery(SelectMimeType.ofImage())
                .setImageEngine(GlideEngine.createGlideEngine())
                .setMaxSelectNum(1)
                .forResult(new OnResultCallbackListener<LocalMedia>() {
                    @Override
                    public void onResult(ArrayList<LocalMedia> result) {
                        if (result.isEmpty()) return;
                        waitDialog.start("正在识别...");
                        new Thread(() -> {
                            Bitmap bitmap = BitmapFactory.decodeFile(result.get(0).getPath());
                            List<String> results = WeChatQRCodeDetector.detectAndDecode(bitmap);
                            String json = new Gson().toJson(results);
                            Message message = new Message();
                            message.obj = json;
                            handler.sendMessage(message);
                        }).start();
                        getCameraScan().setAnalyzeImage(true);
                    }

                    @Override
                    public void onCancel() {
                        getCameraScan().setAnalyzeImage(true);
                    }
                });
    }

    private final Handler handler = new Handler(message -> {
        waitDialog.stop();
        scanView.startScan();
        String json = (String) message.obj;
        List<String> list = StaticMethod.getList(String[].class, json);
        if (mOnCallBack != null)
            mOnCallBack.onScanResults(list, true, this);
        return false;
    });

    @Override
    public int getLayoutId() {
        return R.layout.activity_qr_code;
    }

    @Override
    public void onScanResultCallback(@NonNull AnalyzeResult<List<String>> result) {
        if (!result.getResult().isEmpty()) {
            if (mOnCallBack != null)
                mOnCallBack.onScanResults(result.getResult(), false, this);
        }
    }

    @Override
    public void finish() {
        getCameraScan().setAnalyzeImage(false);
        super.finish();
    }

}