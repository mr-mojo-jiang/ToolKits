package com.mojo.toolkit.classes.Pop;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mojo.toolkit.R;
import com.mojo.toolkit.model.KeyValueItem;
import com.mojo.toolkit.utils.DensityUtil;

import java.util.ArrayList;
import java.util.List;

public class SpinnerAdapter<T> extends RecyclerView.Adapter<SpinnerAdapter.ViewHolder> {
    private final LayoutInflater inflater;
    private final List<KeyValueItem<T>> mItems;
    private boolean enableDelete = false;
    private int textSize = 14;
    private int selectIndex = -1;
    private int selectColor = 0x0ff1e6eff;
    private int normalColor = 0x0ff222222;
    private OnItemClickListener<T> onItemClickListener;

    public SpinnerAdapter(Context context) {
        this.mItems = new ArrayList<>();
        inflater = LayoutInflater.from(context);
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setItems(List<KeyValueItem<T>> items) {
        this.mItems.clear();
        if (items == null || items.isEmpty()) {
            selectIndex = -1;
        } else {
            this.mItems.addAll(items);
            selectIndex = 0;
        }
        this.notifyDataSetChanged();
    }

    public void setEnableDelete(boolean enableDelete) {
        this.enableDelete = enableDelete;
        this.notifyItemRangeChanged(0, mItems.size());
    }

    public void setTextSize(int textSize) {
        this.textSize = textSize;
        this.notifyItemRangeChanged(0, mItems.size());
    }

    public void setSelectIndex(int selectIndex) {
        this.selectIndex = selectIndex;
        this.notifyItemRangeChanged(0, mItems.size());
    }

    public void setOnItemClickListener(OnItemClickListener<T> onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
        this.notifyItemRangeChanged(0, mItems.size());
    }

    public void setSelectColor(int selectColor) {
        this.selectColor = selectColor;
    }

    public void setNormalColor(int normalColor) {
        this.normalColor = normalColor;
    }

    @NonNull
    @Override
    public SpinnerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.view_pop_spinner_item, parent, false);
        return new SpinnerAdapter.ViewHolder(view, enableDelete);
    }

    @Override
    public void onBindViewHolder(@NonNull SpinnerAdapter.ViewHolder holder, int position) {
        KeyValueItem<T> item = mItems.get(position);
        holder.tvName.setText(item.getKey());
        holder.tvName.setTextSize(textSize);
        holder.tvName.setTextColor(position == selectIndex ? selectColor : normalColor);
        final int id = position;
        holder.itemView.setOnClickListener(view -> {
            int index1 = selectIndex;
            selectIndex = id;
            this.notifyItemChanged(index1);
            this.notifyItemChanged(selectIndex);
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(item);
            }
        });
        if (item.getValue() instanceof String && item.getValue().equals("")) {
            holder.delete.setVisibility(View.INVISIBLE);
        }

        holder.delete.setOnClickListener(view -> {
            if (onItemClickListener != null) {
                onItemClickListener.onDelete(item);
            }
        });
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }

    public List<KeyValueItem<T>> getItems() {
        return mItems;
    }

    public KeyValueItem<T> getSelectItem() {
        return selectIndex < 0 ? null : mItems.get(selectIndex);
    }

    public void setSelectItem(KeyValueItem<T> item) {
        if (selectIndex != -1)
            this.notifyItemChanged(selectIndex);
        this.selectIndex = mItems.indexOf(item);
        this.notifyItemChanged(selectIndex);
    }

    public int getItemHeight() {
        return DensityUtil.dip2px(inflater.getContext(), 48);
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        ImageView delete;

        public ViewHolder(@NonNull View itemView, boolean enableDelete) {
            super(itemView);
            tvName = (TextView) itemView.findViewById(R.id.tv_item);
            delete = itemView.findViewById(R.id.btn_delete);
            if (enableDelete) {
                delete.setVisibility(View.VISIBLE);
            } else {
                delete.setVisibility(View.INVISIBLE);
            }
        }
    }
}

