package com.mojo.toolkit.views.MultiListView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.mojo.toolkit.utils.DensityUtil;

import java.util.ArrayList;
import java.util.List;

public class MultiAdapter extends RecyclerView.Adapter<MultiAdapter.MyViewHolder> {
    private final Context mContext;
    private final int tier;
    private List<MultiItem> mItemList;
    private OnItemClickListener mOnItemClickListener;
    private int selectIndex;

    public MultiAdapter(Context context, int tier) {
        this.mContext = context;
        this.tier = tier;
        this.mItemList = new ArrayList<>();
    }

    public int getTier() {
        return tier;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setItemList(List<MultiItem> itemList) {
        this.mItemList = itemList;
        this.selectIndex = -1;
        this.notifyDataSetChanged();
    }

    public void setOnItemClickListener(OnItemClickListener mOnItemClickListener) {
        this.mOnItemClickListener = mOnItemClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        TextView view = new TextView(mContext);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = DensityUtil.dip2px(mContext, 4);
        params.bottomMargin = DensityUtil.dip2px(mContext, 4);
        view.setLayoutParams(params);
        int pse = DensityUtil.dip2px(mContext, 16);
        int ptb = DensityUtil.dip2px(mContext, 8);
        view.setPadding(pse, ptb, pse, ptb);
        view.setTextSize(14);
        return new MyViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        if (mItemList.isEmpty()) return;
        MultiItem item = mItemList.get(position);
        holder.tv.setText(item.getTag());
        holder.tv.setTextColor(position == selectIndex ? 0x0ff1670FA : 0x0ff262A2D);
        holder.tv.setBackgroundColor(position == selectIndex ? 0x0ffFAFAFA : 0x0fff);
        holder.itemView.setOnClickListener(v -> {
            int id = selectIndex;
            selectIndex = holder.getAbsoluteAdapterPosition();
            notifyItemChanged(id);
            notifyItemChanged(selectIndex);
            if (mOnItemClickListener != null) {
                mOnItemClickListener.onItemClick(item, tier);
            }
        });
    }

    /*static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv;

        MyViewHolder(View itemView) {
            super(itemView);
            tv = (TextView) itemView;
        }
    }*/

    public interface OnItemClickListener {
        void onItemClick(MultiItem item, int tier);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv;

        MyViewHolder(View itemView) {
            super(itemView);
            tv = (TextView) itemView;
        }
    }
}