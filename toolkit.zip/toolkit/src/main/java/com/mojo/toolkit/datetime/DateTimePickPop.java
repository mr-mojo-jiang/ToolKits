package com.mojo.toolkit.datetime;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.NumberPicker;
import android.widget.PopupWindow;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.haibin.calendarview.Calendar;
import com.haibin.calendarview.CalendarView;
import com.mojo.toolkit.R;
import com.mojo.toolkit.utils.DateTimeUtil;
import com.mojo.toolkit.utils.TabLayoutUtil;

import java.lang.reflect.Field;

public class DateTimePickPop extends PopupWindow implements View.OnClickListener {
    public final Activity mContext;
    private View view;
    private WindowManager.LayoutParams params;
    private TabLayout tabLayout;
    private TabLayout.Tab dateTab, timeTab;
    private ViewPager2 pager2;
    private OnDateSelectListener2 onDateSelectListener;
    private String dateStr, timeStr;

    public DateTimePickPop(Activity mContext) {
        this.mContext = mContext;
        init();
    }

    @SuppressLint("InflateParams")
    private void init() {
        dateStr = DateTimeUtil.getFormatDate("yyyy-MM-dd");
        timeStr = DateTimeUtil.getFormatDate("HH:mm");

        view = LayoutInflater.from(mContext).inflate(R.layout.view_date_time_pick, null, false);
        tabLayout = view.findViewById(R.id.tabLayout);
        dateTab = tabLayout.newTab();
        dateTab.setText(DateTimeUtil.getFormatDate("yyyy年MM月dd日"));
        tabLayout.addTab(dateTab);

        timeTab = tabLayout.newTab();
        timeTab.setText(timeStr);
        tabLayout.addTab(timeTab);

        pager2 = view.findViewById(R.id.view_pager);
        pager2.setUserInputEnabled(false);
        pager2.setAdapter(new PagerAdapter());
        TabLayoutUtil.build(tabLayout).setOnSelectedListener(tabStr -> {
            int index = tabStr.contains("年") ? 0 : 1;
            pager2.setCurrentItem(index);
        });

        (view.findViewById(R.id.btn_confirm)).setOnClickListener(this);
        this.setContentView(view);
        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);// 设置弹出窗口的宽
        this.setFocusable(true);// 设置可弹出窗口
        this.setAnimationStyle(R.style.my_pop_anim_style);// 设置动画
        params = mContext.getWindow().getAttributes();
    }

    public DateTimePickPop setOnDateSelectListener(OnDateSelectListener2 onDateSelectListener) {
        this.onDateSelectListener = onDateSelectListener;
        return this;
    }

    public void setBackGround(Drawable resourceId) {
        view.setBackground(resourceId);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn_confirm) {
            if (onDateSelectListener != null) {
                String date = dateStr + " " + timeStr + ":00";
                onDateSelectListener.onSelected(date);
            }
            dismiss();
        }
    }

    public void openPop() {
        this.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);// 设置弹出窗口的高
        params.alpha = 0.3f;
        mContext.getWindow().setAttributes(params);
        this.showAtLocation(view, Gravity.BOTTOM, 0, 0);
    }

    @Override
    public void dismiss() {
        params.alpha = 1.0f;
        mContext.getWindow().setAttributes(params);
        super.dismiss();
    }

    class PagerAdapter extends RecyclerView.Adapter<ViewHolder> {

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            FrameLayout v = new FrameLayout(mContext);
            v.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            if (position == 0) {
                holder.fl.addView(getCalendarView());
            } else {
                holder.fl.addView(getTimePicker());
            }
        }

        @Override
        public int getItemCount() {
            return 2;
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        FrameLayout fl;

        public ViewHolder(@NonNull FrameLayout itemView) {
            super(itemView);
            fl = itemView;
        }
    }

    private CalendarView getCalendarView() {
        CalendarView calendarView = new CalendarView(mContext);
        calendarView.setMonthView(CustomDateView.class);
        calendarView.setRange(2000, 1, 1, 2030, 12, 31);
        calendarView.scrollToCurrent();
        calendarView.setSelectDefaultMode();
        calendarView.setSelectedColor(Color.WHITE, Color.WHITE, Color.WHITE);
        calendarView.setOnCalendarSelectListener(new CalendarView.OnCalendarSelectListener() {
            @Override
            public void onCalendarOutOfRange(Calendar calendar) {

            }

            @Override
            public void onCalendarSelect(Calendar calendar, boolean isClick) {
                if (isClick) {
                    calendarView.clearSchemeDate();
                    calendarView.addSchemeDate(calendar);
                    dateStr = calendar.getYear() + "-" + getString(calendar.getMonth()) + "-" + getString(calendar.getDay());
                    String date = calendar.getYear() + "年" + getString(calendar.getMonth()) + "月" + getString(calendar.getDay()) + "日";
                    dateTab.setText(date);
                    pager2.setCurrentItem(1);
                    tabLayout.selectTab(timeTab);
                }
            }
        });
        return calendarView;
    }

    private TimePicker getTimePicker() {
        TimePicker timePicker = (TimePicker) View.inflate(mContext, R.layout.view_time_picker, null);
        timePicker.setForegroundGravity(Gravity.CENTER);
        timePicker.setIs24HourView(true);
        timePicker.setOnTimeChangedListener((timePicker1, h, m) -> {
            timeStr = getString(h) + ":" + getString(m);
            timeTab.setText(timeStr);
        });
        set_timepicker_text_colour(timePicker);

        return timePicker;
    }

    private void set_timepicker_text_colour(TimePicker time_picker) {
        Resources system = Resources.getSystem();
        int hourId = system.getIdentifier("hour", "id", "android");
        int minuteId = system.getIdentifier("minute", "id", "android");
        NumberPicker hourNP = (NumberPicker) time_picker.findViewById(hourId);
        NumberPicker minuteNP = (NumberPicker) time_picker.findViewById(minuteId);
        setNumberPickerDivider(minuteNP);
        setNumberPickerDivider(hourNP);
    }

    //设置分割线颜色
    private void setNumberPickerDivider(NumberPicker numberPicker) {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                @SuppressLint("DiscouragedPrivateApi")
                Field dividerField = numberPicker.getClass().getDeclaredField("mSelectionDivider");
                dividerField.setAccessible(true);
                ColorDrawable colorDrawable = new ColorDrawable(
                        ContextCompat.getColor(mContext, R.color.color_lucid));
                dividerField.set(numberPicker, colorDrawable);
                numberPicker.invalidate();
            } else {
                numberPicker.setSelectionDividerHeight(0);
            }
        } catch (NoSuchFieldException | IllegalAccessException | IllegalArgumentException e) {
            Log.w("NumberPickerSetting", e.getMessage());
        }
    }

    private String getString(int value) {
        return value < 10 ? "0" + value : "" + value;
    }
}
