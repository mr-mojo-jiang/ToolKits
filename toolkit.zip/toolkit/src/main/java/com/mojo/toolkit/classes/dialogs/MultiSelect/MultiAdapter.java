package com.mojo.toolkit.classes.dialogs.MultiSelect;

import android.content.Context;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mojo.toolkit.R;
import com.mojo.toolkit.classes.OnItemClickListener;
import com.mojo.toolkit.model.KeyValueItem;
import com.mojo.toolkit.utils.CompoundImageUtil;

public class MultiAdapter<T> extends RecyclerView.Adapter<MultiAdapter.MyViewHolder> {
    private static final String TAG = MultiAdapter.class.getSimpleName();
    private final Context mContext;
    private List<KeyValueItem<T>> mItemList;
    private OnItemClickListener<KeyValueItem<T>> mOnItemClickListener;
    private boolean showIcon;
    private CompoundImageUtil.Location iconLocation;

    public MultiAdapter(Context context) {
        this.mContext = context;
        this.mItemList = new ArrayList<>();
        this.iconLocation = CompoundImageUtil.Location.Left;
    }

    public void setItemList(List<KeyValueItem<T>> itemList) {
        this.mItemList = itemList;
        this.notifyItemRangeChanged(0,itemList.size());
    }

    public void setOnItemClickListener(OnItemClickListener<KeyValueItem<T>> mListener) {
        this.mOnItemClickListener = mListener;
    }

    public void setShowIcon(boolean showIcon) {
        this.showIcon = showIcon;
    }

    public void setIconLocation(CompoundImageUtil.Location iconLocation) {
        this.iconLocation = iconLocation;
        this.notifyItemRangeChanged(0,mItemList.size());
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        TextView view = new TextView(mContext);
        view.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
        int pd = 25;
        view.setPadding(pd, pd, pd, pd);
        view.setTextColor(0x0ff222222);
        view.setGravity(Gravity.CENTER);
        view.setBackgroundResource(R.drawable.bg_click_borderless);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        KeyValueItem<T> item = mItemList.get(position);
        holder.text.setText(item.getKey());
        if(item.getValue() instanceof Integer && showIcon){
            CompoundImageUtil.build(holder.text)
                    .setLocation(iconLocation)
                    .setSize(20,20)
                    .setIconPadding(12)
                    .setCompoundImage((int)item.getValue());
        }
        holder.itemView.setOnClickListener(v -> {
            Log.e(TAG, "onBindViewHolder: "+item.getKey()+(mOnItemClickListener != null) );
            if (mOnItemClickListener != null) {
                mOnItemClickListener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView text;
        MyViewHolder(View itemView) {
            super(itemView);
            //initView
            text = (TextView) itemView;
        }
    }
}