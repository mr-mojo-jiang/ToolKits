package com.mojo.toolkit.datetime;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;

import com.haibin.calendarview.Calendar;
import com.haibin.calendarview.MonthView;

public class CustomDateView extends MonthView {
    private int mRadius;
    private boolean isStart, isEnd;

    public CustomDateView(Context context) {
        super(context);
    }

    @Override
    protected void onPreviewHook() {
        mRadius = Math.min(mItemWidth, mItemHeight) / 2;
        mCurDayTextPaint.setColor(0x0ff1670FA);
        mSelectedPaint.setColor(0x0ff1670FA);
        mSelectTextPaint.setFakeBoldText(false);
        mCurMonthTextPaint.setFakeBoldText(false);
        mCurDayTextPaint.setFakeBoldText(false);
        mOtherMonthTextPaint.setFakeBoldText(false);
    }

    @Override
    protected boolean onDrawSelected(Canvas canvas, Calendar calendar, int x, int y, boolean hasScheme) {
        return true;
    }

    @Override
    protected void onDrawScheme(Canvas canvas, Calendar calendar, int x, int y) {
        int cx = x + mItemWidth / 2;
        int cy = y + mItemHeight / 2;
        canvas.drawCircle(cx, cy, mRadius, mSelectedPaint);
    }

    @Override
    protected void onDrawText(Canvas canvas, Calendar calendar, int x, int y, boolean hasScheme, boolean isSelected) {
        float baselineY = mTextBaseLine + y;
        int cx = x + mItemWidth / 2;

        boolean isInRange = isInRange(calendar);
        boolean isEnable = !onCalendarIntercept(calendar);

        if (hasScheme) {
            String s = String.valueOf(calendar.getDay());
            canvas.drawText(s, cx, baselineY, mSelectTextPaint);
        }  else {
            Paint paint = calendar.isCurrentDay() ? mCurDayTextPaint :
                    calendar.isCurrentMonth() && isInRange && isEnable ? mCurMonthTextPaint : mOtherMonthTextPaint;
            canvas.drawText(String.valueOf(calendar.getDay()), cx, baselineY,paint );
        }
    }

}
