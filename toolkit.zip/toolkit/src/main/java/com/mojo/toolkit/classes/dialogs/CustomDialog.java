package com.mojo.toolkit.classes.dialogs;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mojo.toolkit.R;
import com.mojo.toolkit.base.BaseDialog;
import com.mojo.toolkit.utils.ScreenSizeUtils;


/**
 * 该Dialog有多种显示方式
 */
public class CustomDialog extends BaseDialog {
    private LinearLayout lyTitle;//用于显示或隐藏标题
    private TextView tvTitle;//标题
    private TextView tvContent;//通知内容
    private TextView cancelBtn;//取消按钮
    private TextView confirmBtn;//确认按钮
    private LinearLayout dialogLayout;//显示框架，用于添加传入的View
    private LinearLayout buttonContainer;//确认取消按钮layout
    private LinearLayout divider;//确认取消按钮之间的分割线
    private boolean autoDismiss = true; //点击确认、取消时，是否自动关闭Dialog
    private boolean  isShowCancel = true;

    public CustomDialog(@NonNull Context context) {
        super(context);
        //init();
    }

    public static CustomDialog build(Context context) {
        return new CustomDialog(context);
    }


    private void init() {
        View view = View.inflate(context, R.layout.view_show_dialog, null);
        lyTitle = view.findViewById(R.id.ly_title);
        tvTitle = view.findViewById(R.id.notice_title);
        tvContent = view.findViewById(R.id.dialog_content);
        dialogLayout = view.findViewById(R.id.dialog_layout);

        buttonContainer = view.findViewById(R.id.ly_buttons);
        divider = view.findViewById(R.id.dialog_btn_line);
        cancelBtn = view.findViewById(R.id.versionchecklib_version_dialog_cancel);
        confirmBtn = view.findViewById(R.id.btn_update);
        this.setView(view);
        this.setOnDismissListener(dialog -> {
            if (dialogLayout.getChildCount() != 0)
                dialogLayout.removeAllViews();
        });
        this.setPositiveBtn(null);
        this.setNegativeBtn(null);
    }

    @Override
    public View getView() {
        View view = View.inflate(context, R.layout.view_show_dialog, null);
        lyTitle = view.findViewById(R.id.ly_title);
        tvTitle = view.findViewById(R.id.notice_title);
        tvContent = view.findViewById(R.id.dialog_content);
        dialogLayout = view.findViewById(R.id.dialog_layout);

        buttonContainer = view.findViewById(R.id.ly_buttons);
        divider = view.findViewById(R.id.dialog_btn_line);
        cancelBtn = view.findViewById(R.id.versionchecklib_version_dialog_cancel);
        confirmBtn = view.findViewById(R.id.btn_update);
        this.setOnDismissListener(dialog -> {
            if (dialogLayout.getChildCount() != 0)
                dialogLayout.removeAllViews();
        });
        this.setPositiveBtn(null);
        this.setNegativeBtn(null);
        return view;
    }

    /**
     * 添加标题
     *
     * @param title 标题
     * @return dialog
     */
    public CustomDialog setTitle(String title) {
        lyTitle.setVisibility(View.VISIBLE);
        tvTitle.setText(title);
        return this;
    }

    /**
     * 添加Message
     *
     * @param message 内容
     * @return dialog
     */
    public CustomDialog setMessage(String message) {
        tvContent.setVisibility(View.VISIBLE);
        tvContent.setText(message);
        return this;
    }

    /**
     * @return 取消自动取消，可以在监听中主动取消
     */
    public CustomDialog cancelAutoDismiss() {
        autoDismiss = false;
        return this;
    }

    /**
     * 添加自定义View
     *
     * @param customView 自定义View
     * @return dialog
     */
    //添加自动义View
    public CustomDialog setCustomView(View customView) {
        dialogLayout.setVisibility(View.VISIBLE);
        dialogLayout.addView(customView);
        return this;
    }

    /**
     * 边距自定义
     *
     * @param left   左边距
     * @param top    上边距
     * @param right  右边距
     * @param bottom 下边距
     * @return
     */
    public CustomDialog setLayoutPadding(int left, int top, int right, int bottom) {
        dialogLayout.setPadding(left, top, right, bottom);
        return this;
    }


    /**
     * 确认按钮设置
     *
     * @param bntStr          文字
     * @param textColor       颜色
     * @param confirmListener 确认监听
     * @return dialog
     */
    public CustomDialog setPositiveBtn(String bntStr, int textColor, final OnConfirmListener confirmListener) {
        confirmBtn.setTextColor(textColor);
        return this.setPositiveBtn(bntStr, confirmListener);
    }

    /**
     * 确认按钮设置
     *
     * @param bntStr          确认按钮文字
     * @param confirmListener 确认监听
     * @return dialog
     */
    public CustomDialog setPositiveBtn(String bntStr, final OnConfirmListener confirmListener) {
        confirmBtn.setText(bntStr);
        return setPositiveBtn(confirmListener);
    }

    /**
     * 确认按钮设置
     *
     * @param confirmListener 确认监听
     * @return dialog
     */
    public CustomDialog setPositiveBtn(final OnConfirmListener confirmListener) {
        if (buttonContainer.getVisibility() != View.VISIBLE) {
            buttonContainer.setVisibility(View.VISIBLE);
        }
        confirmBtn.setVisibility(View.VISIBLE);
        confirmBtn.setOnClickListener(v -> {
            if (confirmListener != null) {
                if (autoDismiss) {
                    dismiss();
                }
                confirmListener.onConfirm(CustomDialog.this);
            } else {
                dismiss();
            }
        });
        return this;
    }

    /**
     * 不显示取消按钮
     */
    public CustomDialog hindNegativeButton() {
        isShowCancel = false;
        return this;
    }

    /**
     * 取消按钮设置
     * @param bntStr         文字
     * @param textColor      颜色
     * @param cancelListener 监听器
     * @return dialog
     */
    public CustomDialog setNegativeBtn(String bntStr, int textColor, final OnCancelListener cancelListener) {
        cancelBtn.setTextColor(textColor);
        return setNegativeBtn(bntStr, cancelListener);
    }

    /**
     * 取消按钮设置
     *
     * @param bntStr         文字
     * @param cancelListener 监听器
     * @return dialog
     */
    public CustomDialog setNegativeBtn(String bntStr, final OnCancelListener cancelListener) {
        cancelBtn.setText(bntStr);
        return setNegativeBtn(cancelListener);
    }

    /**
     * 取消按钮设置
     *
     * @param cancelListener 监听器
     * @return dialog
     */
    public CustomDialog setNegativeBtn(final OnCancelListener cancelListener) {
        if (buttonContainer.getVisibility() != View.VISIBLE) {
            buttonContainer.setVisibility(View.VISIBLE);
        }
        cancelBtn.setVisibility(View.VISIBLE);
        cancelBtn.setOnClickListener(v -> {
            if (cancelListener != null) {
                if (autoDismiss) dismiss();
                cancelListener.onCancel(CustomDialog.this);
            } else dismiss();
        });
        return this;
    }

    @Override
    public void dismiss() {
        super.dismiss();
        dialogLayout.removeAllViews();
    }

    @Override
    public void show() {
        int visible = isShowCancel ? View.VISIBLE : View.GONE;
        cancelBtn.setVisibility(visible);
        divider.setVisibility(visible);
        super.show();
    }

    public CustomDialog setPercentWidth(float v) {
        setWidth((int) (ScreenSizeUtils.getInstance(context).getScreenWidth()*v));
        return this;
    }

    public interface OnConfirmListener {
        void onConfirm(CustomDialog dialog);
    }

    public interface OnCancelListener {
        void onCancel(CustomDialog dialog);
    }

}
