package com.mojo.toolkit.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mojo.toolkit.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class CustomDateCut extends LinearLayout implements View.OnClickListener {
    private static final String MODE_MONTH = "月";
    private static final String MODE_DAY = "日";
    /*private static final SimpleDateFormat FORMAT_MONTH = new SimpleDateFormat("yyyy.MM", Locale.CHINA);
    private static final SimpleDateFormat FORMAT_DAY = new SimpleDateFormat("yyyy.MM.dd", Locale.CHINA);*/
    private SimpleDateFormat dateFormat ;
    private final Context mContext;
    private TextView tvDate;
    private String mode = MODE_MONTH;
    private String currentDate;
    private OnDateChangeListener onDateChangeListener;

    public CustomDateCut(@NonNull Context context) {
        this(context,null,0);
    }

    public CustomDateCut(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context,attrs,0);
    }

    public CustomDateCut(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        initView();
    }

    public static CustomDateCut build(Context context){
        return new CustomDateCut(context);
    }

    private void initView(){
        View v  = View.inflate(mContext, R.layout.view_date_cut,null);
        this.addView(v);
        tvDate = v.findViewById(R.id.tv_date);
        initDate();
        (v.findViewById(R.id.btn_front)).setOnClickListener(this);
        (v.findViewById(R.id.btn_back)).setOnClickListener(this);
    }

    private void initDate(){
        currentDate = getDate();
        tvDate.setText(currentDate);
    }

    public void setOnDateChangeListener(OnDateChangeListener onDateChangeListener) {
        this.onDateChangeListener = onDateChangeListener;
    }

    public void setMode(String mode) {
        this.mode = mode;
        initDate();
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btn_front ){
            tvDate.setText(getBefore());
        }else {
            tvDate.setText(getNext());
        }
        currentDate = tvDate.getText().toString();
        if(onDateChangeListener!=null){
            onDateChangeListener.onChanged(currentDate);
        }
    }

    private String getDate(){
        String pattern = "yyyy.MM";
        if(mode.equals(MODE_DAY)){
            pattern = "yyyy.MM.dd";
        }
        dateFormat = new SimpleDateFormat(pattern, Locale.CHINA);
        return dateFormat.format(Calendar.getInstance().getTime());
    }


    private String  getBefore(){
        Date date ;
        Calendar c = Calendar.getInstance();
        try {
            date = dateFormat.parse(currentDate);
            assert date != null;
            c.setTime(date);
            c.add(mode.equals(MODE_MONTH)? Calendar.MONTH:Calendar.DAY_OF_MONTH, -1);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateFormat.format(c.getTime());
    }


    private String  getNext(){
        Date date ;
        Calendar c = Calendar.getInstance();
        try {
            date = dateFormat.parse(currentDate);
            assert date != null;
            c.setTime(date);
            c.add(mode.equals(MODE_MONTH)? Calendar.MONTH:Calendar.DAY_OF_MONTH, 1);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateFormat.format(c.getTime());
    }

    public interface OnDateChangeListener{
        void onChanged(String cutDate);
    }
}
