package com.mojo.toolkit.views;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;

import androidx.annotation.Nullable;

import com.mojo.toolkit.R;
import com.mojo.toolkit.utils.CompoundImageUtil;
import com.mojo.toolkit.utils.DensityUtil;

import java.util.Timer;
import java.util.TimerTask;


public class StateTextView extends androidx.appcompat.widget.AppCompatTextView {
    private static final String TAG = "StateTextView";
    private int unSelectId = R.drawable.icon_down;
    private int selectId = R.drawable.icon_up;
    private int finishId = R.drawable.bg_finished;
    private boolean isSelected;
    private int iconW = 24;
    private int iconH = 24;
    private boolean enableImageChange;//是否允许图片自动点击
    private boolean isFinish;
    private CharSequence hint;
    //是否通过灰色setText显示Hint
    private boolean showHint = false;
    private int deColor, hinColor = 0;

    public StateTextView(Context context) {
        this(context, null, 0);
    }

    public StateTextView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public StateTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    void init() {
        this.setGravity(Gravity.END);
        this.setTextImage(unSelectId);
        int pd = DensityUtil.dip2px(getContext(), 8);
        this.setPadding(pd, 0, pd, 0);
        hint = this.getHint() == null ? "" : this.getHint();
        this.setHint(null);
        if (this.getText().length() == 0 && hint.length() != 0) {
            this.setText(hint);
        }
    }

    /**
     * 解决当有hint时，弹出弹窗会影响hint的Gravity
     */
    @Override
    public void setText(CharSequence text, BufferType type) {
        if (deColor == 0) {
            deColor = getTextColors().getColorForState(getDrawableState(), Color.BLACK);
        }
        if (hinColor == 0) {
            hinColor = getHintTextColors().getColorForState(getDrawableState(), Color.GRAY);
        }
        showHint = text == null || text.length() == 0 || text.equals(hint);
        super.setText(showHint ? hint : text, type);
        this.setTextColor(showHint ? hinColor : deColor);
    }

    @Override
    public CharSequence getText() {
        return showHint ? "" : super.getText();
    }

    /*设置图片自动变化*/
    public void enableImageChange(boolean enable) {
        enableImageChange = enable;
    }

    /**
     * 设置右侧图片
     *
     * @param resId 图片资源Id
     */
    /*设置右侧图片*/
    private void setTextImage(int resId) {
        CompoundImageUtil.build(this)
                .setLocation(CompoundImageUtil.Location.Right)
                .setSize(iconW, iconH)
                .setCompoundImage(resId);
    }

    public int getSpace() {
        return DensityUtil.dip2px(getContext(), 52);
    }

    /**
     * 修改选中状态图片
     *
     * @param selectId 图片资源Id
     */
    public void setSelectImgId(int selectId) {
        this.selectId = selectId;
        invalidate();
    }

    /**
     * 修改选中状态图片
     *
     * @param dpWith   图标宽度
     * @param dpHeight 图片高度
     */
    public void refreshImgSize(int dpWith, int dpHeight) {
        this.iconW = dpWith;
        this.iconH = dpHeight;
        invalidate();
    }

    /**
     * 修改未选中状态图片
     *
     * @param unSelectId 未选中状态图片Id
     */
    public void setUnSelectImgId(int unSelectId) {
        this.unSelectId = unSelectId;
        invalidate();
        setTextImage(unSelectId);
    }

    /**
     * @param finishId 设置已完成状态图标Id
     */
    public void setFinishId(int finishId) {
        this.finishId = finishId;
        invalidate();
    }

    /**
     * @return 获取选中状态
     */
    public boolean getState() {
        return isSelected;
    }


    /**
     * @param isSelected 主动更改状态
     */
    public void setState(boolean isSelected) {
        this.isSelected = isSelected;
        if (isSelected) {
            setTextImage(selectId);
        } else {
            setTextImage(unSelectId);
        }
    }

    public void setFinished(boolean isFinish) {
        setTextImage(isFinish ? finishId : unSelectId);
    }

    @Override
    public boolean performClick() {
        if (enableImageChange) {
            isSelected = !isSelected;
            setTextImage(isSelected ? selectId : unSelectId);
        }
        return super.performClick();
    }

    @Override
    public void setGravity(int gravity) {
        super.setGravity(gravity | Gravity.CENTER_VERTICAL);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        //解决hint不居中问题
        this.setText(getText());
    }
}
