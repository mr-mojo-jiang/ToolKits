package com.mojo.toolkit.views;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

import com.mojo.toolkit.model.KeyValueItem;
import com.mojo.toolkit.utils.DensityUtil;
import com.mojo.toolkit.utils.PaintUtil;

import java.util.ArrayList;
import java.util.List;

public class PickScrollView<T> extends View {
    String TAG = "PickScrollerView";
    private final Context context;
    private Paint textPaint;
    private int centerX, centerY;
    private int selectedTextSize;
    private int unselectedTextSize;
    private List<KeyValueItem<T>> itemList;
    private final float itemSpacing = 30;//文字间隔
    private float startY;
    private int selectIndex;
    private float offsetY;
    private int offsetShowNum = 2;
    private Rect limitRect;

    public PickScrollView(Context context) {
        this(context, null);
    }

    public PickScrollView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        initView();
    }

    private void initView() {
        textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setStyle(Paint.Style.FILL_AND_STROKE);

        selectedTextSize = DensityUtil.dip2px(context, 16);
        unselectedTextSize = DensityUtil.dip2px(context, 14);

        this.itemList = new ArrayList<>();
        limitRect = new Rect();
    }

    public void setItems(List<KeyValueItem<T>> list) {
        if (list == null) return;
        this.itemList = list;
        selectIndex = 0;
        invalidate();
    }

    /**
     * @param offsetShowNum 上侧和下侧最大显示数量
     */
    public void setOffsetShowNum(int offsetShowNum) {
        this.offsetShowNum = offsetShowNum;
    }

    public KeyValueItem<T> getSelectItem() {
        return itemList.get(selectIndex);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.clipRect(limitRect);
        canvas.save();

        for (int i = 0; i < itemList.size(); i++) {
            int offset = i - selectIndex;
            if (offset < -(offsetShowNum + 1)) {
                continue;
            } else if (offset > (offsetShowNum + 1)) {
                break;
            }
            textPaint.setAlpha(255 - 60 * Math.abs(offset));
            textPaint.setTextSize(offset == 0 ? selectedTextSize : unselectedTextSize);
            float cy = centerY + offset * ((unselectedTextSize + selectedTextSize) / 2f + itemSpacing);
            textPaint.setStrokeWidth(offset == 0 ? 0.5f : 0.2f);
            canvas.drawText(itemList.get(i).getKey(), centerX, cy + PaintUtil.getTop2Center(textPaint) + offsetY, textPaint);
        }
        canvas.restore();
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startY = event.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                offsetY += event.getY() - startY;
                disposeDown();
                invalidate();
                startY = event.getY();
                break;
            case MotionEvent.ACTION_UP:
                if (Math.abs(offsetY) < 10) {
                    clickOption(event.getY());
                } else {
                    setAnimation(offsetY);
                }
                performClick();
                break;
        }
        return true;
    }

    private void clickOption(float y) {
        float symbol = y > centerY ? 1 : -1;
        int offset = (int) ((y - centerY + symbol * (selectedTextSize + itemSpacing) / 2f)
                / ((unselectedTextSize + selectedTextSize) / 2f + itemSpacing));
        float offsetY = symbol * selectedTextSize / 2f + offset * selectedTextSize / 2f + itemSpacing * offset;
        if (selectIndex + offset >= 0 && selectIndex + offset < itemList.size()) {
            selectIndex += offset;
            setAnimation(offsetY);
        } else {
            setAnimation(this.offsetY);
        }
    }

    /**
     * 对移动进行处理
     */
    private void disposeDown() {
        if (Math.abs(offsetY) > ((unselectedTextSize + selectedTextSize) / 2f + itemSpacing) / 2f) {
            int newIndex = selectIndex - (int) (offsetY / Math.abs(offsetY) * 1);
            if (newIndex >= 0 && newIndex < itemList.size()) {
                selectIndex = newIndex;
                offsetY -= offsetY / Math.abs(offsetY) * ((unselectedTextSize + selectedTextSize) / 2f + itemSpacing);
            } else if (Math.abs(offsetY) > ((unselectedTextSize + selectedTextSize) / 2f + itemSpacing)) {
                offsetY = offsetY / Math.abs(offsetY) * ((unselectedTextSize + selectedTextSize) / 2f + itemSpacing);
            }
        }
    }


    /**
     * 回弹效果实现
     **/
    private void setAnimation(float offset) {
        ValueAnimator valueAnimator = ValueAnimator.ofFloat(0, offset);
        valueAnimator.setDuration(200);
        valueAnimator.setStartDelay(0);
        valueAnimator.setInterpolator(new LinearInterpolator());
        valueAnimator.addUpdateListener(animation -> {
            offsetY = offset - (float) valueAnimator.getAnimatedValue();
            invalidate();
        });
        valueAnimator.start();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int w = MeasureSpec.getSize(widthMeasureSpec);
        int wm = MeasureSpec.getMode(widthMeasureSpec);

        int h = MeasureSpec.getSize(heightMeasureSpec);
        int hm = MeasureSpec.getMode(heightMeasureSpec);

        if (hm == MeasureSpec.AT_MOST) {
            h = (int) (selectedTextSize + unselectedTextSize * 2 * offsetShowNum + (offsetShowNum + 1) * 2 * itemSpacing);
        }
        if (wm == MeasureSpec.AT_MOST) {
            w = 0;
            textPaint.setTextSize(selectedTextSize);
            for (KeyValueItem<T> item : itemList) {
                w = (int) Math.max(w, textPaint.measureText(item.getKey()));
            }
        }
        this.setMeasuredDimension(w, h);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.centerX = w / 2;
        this.centerY = h / 2;
        float off = selectedTextSize / 2f + unselectedTextSize * offsetShowNum + itemSpacing * (offsetShowNum + 1);
        limitRect.left = 0;
        limitRect.top = (int) (centerY - off);
        limitRect.right = w;
        limitRect.bottom = (int) (centerY + off);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}

