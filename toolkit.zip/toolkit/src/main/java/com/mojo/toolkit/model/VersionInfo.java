package com.mojo.toolkit.model;

public class VersionInfo {
    public int id;
    public int versionCode;
    public String versionName;
    public String url;
    public String updateContent;
    //是否强制
    public int forced = 1;

    public boolean isForced() {
        return forced == 1;
    }
}
