package com.mojo.toolkit.base;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.mojo.toolkit.manager.ProgressManager;

public abstract class BaseFragment<M extends BaseModel<?,?>,P extends BasePresenter<?,?,?>,CONTRACT> extends Fragment {
    public Context context;
    public P presenter;
    public M model;
    public ProgressBar pb;
    private boolean isLoaded = false;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        presenter = initPresenter(getContract());
        model = initModel(presenter,getContract());
        context = getContext();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(getViewId(),container,false);
        initView(view);

        pb = ProgressManager.createProgressBar((Activity) context);
        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
        if(!isLoaded ){
            initData();
            isLoaded = true;
            initListener();
        }
    }

    public abstract int getViewId();
    public abstract void initView(View view);
    public abstract void initData();
    public abstract void initListener();
    public abstract CONTRACT getContract();
    public abstract P initPresenter(CONTRACT v);
    public abstract M initModel(P p,CONTRACT contract);

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if(!isLoaded && !hidden){
            initData();
            isLoaded = true;
        }
    }

}
