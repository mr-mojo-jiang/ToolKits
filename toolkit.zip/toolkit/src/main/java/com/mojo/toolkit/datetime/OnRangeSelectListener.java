package com.mojo.toolkit.datetime;

import java.util.Date;

public interface OnRangeSelectListener {
    void onSelected(Date stDate,Date endDate);
}
