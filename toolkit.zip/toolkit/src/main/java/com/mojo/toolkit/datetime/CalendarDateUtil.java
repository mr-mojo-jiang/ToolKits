package com.mojo.toolkit.datetime;

import com.haibin.calendarview.Calendar;
import com.mojo.toolkit.utils.DateTimeUtil;

import java.util.Date;

public class CalendarDateUtil {

    public static Date getDate(Calendar calendar) {
        String month = calendar.getMonth() < 10 ? "0" + calendar.getMonth() : String.valueOf(calendar.getMonth());
        String day = calendar.getDay() < 10 ? "0" + calendar.getDay() : String.valueOf(calendar.getDay());
        String date = calendar.getYear() + "-" + month + "-" + day;
        return DateTimeUtil.str2Date(date, "yyyy-MM-dd");
    }

    public static String getDateStr(Calendar calendar) {
        String month = calendar.getMonth() < 10 ? "0" + calendar.getMonth() : String.valueOf(calendar.getMonth());
        String day = calendar.getDay() < 10 ? "0" + calendar.getDay() : String.valueOf(calendar.getDay());
        return calendar.getYear() + "-" + month + "-" + day;
    }

}
