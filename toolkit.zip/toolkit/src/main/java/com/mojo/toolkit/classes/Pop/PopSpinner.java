package com.mojo.toolkit.classes.Pop;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mojo.toolkit.R;
import com.mojo.toolkit.base.DropDownPopupWindow;
import com.mojo.toolkit.model.KeyValueItem;
import com.mojo.toolkit.utils.RvDecorationUtil;

import java.util.List;

public class PopSpinner<T> extends DropDownPopupWindow {
    private SpinnerAdapter<T> itemsAdapter;
    private RecyclerView recyclerView;
    private int showNum = 0;

    public static <T> PopSpinner<T> build(Context context) {
        return new PopSpinner<>(context);
    }

    private PopSpinner(Context context) {
        super(context);
        init();
    }

    private void init() {
        recyclerView = new RecyclerView(mContext);
        recyclerView.setLayoutParams(new ViewGroup.LayoutParams(-1,-2));
        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        itemsAdapter = new SpinnerAdapter<T>(mContext);
        recyclerView.setBackgroundColor(Color.WHITE);

        recyclerView.setAdapter(itemsAdapter);
        RvDecorationUtil.build(mContext).setDividerIntoView(recyclerView);
        this.setView(recyclerView);
    }

    @Override
    public void setFillHeight(boolean fillHeight) {
        super.setFillHeight(fillHeight);
        if(!fillHeight){
            recyclerView.setBackgroundResource(R.drawable.bg_radius);
        }else {
            recyclerView.setBackgroundColor(Color.WHITE);
        }
    }

    public void setShowNum(int showNum) {
        this.showNum = Math.max(showNum,0);
    }

    private void refreshViewHeight(){
        this.showNum = Math.min(itemsAdapter.getItemCount(),showNum) ;
        if(showNum > 0 ){
            this.setPopHeight(showNum*itemsAdapter.getItemHeight());
        }
    }

    /**
     * @param items 设置选择项目
     */
    public void setItems(List<KeyValueItem<T>> items) {
        itemsAdapter.setItems(items);
    }

    /**
     * @param enableDelete 是否允许删除
     */
    public void setEnableDelete(boolean enableDelete) {
        itemsAdapter.setEnableDelete(enableDelete);
    }

    public void setTextSize(int textSize) {
        itemsAdapter.setTextSize(textSize);
    }

    @Override
    public void openPop(View view) {
        refreshViewHeight();
        super.openPop(view);
    }

    public void setOnItemClickListener(OnItemClickListener<T> onItemClickListener) {
        itemsAdapter.setOnItemClickListener(new OnItemClickListener<T>() {
            @Override
            public void onItemClick(KeyValueItem<T> item) {
                onItemClickListener.onItemClick(item);
                PopSpinner.this.dismiss();
            }

            @Override
            public void onDelete(KeyValueItem<T> item) {
                onItemClickListener.onDelete(item);
                PopSpinner.this.dismiss();
            }
        });
    }

    public void setSelectItem(KeyValueItem<T> item) {
        itemsAdapter.setSelectItem(item);
    }

    public KeyValueItem<T> getSelectItem() {
        return itemsAdapter.getSelectItem();
    }

    public KeyValueItem<T> getItemByKey(T selectKey) {
        for (KeyValueItem<T> mItem : itemsAdapter.getItems()) {
            if (mItem.getValue().equals(selectKey)) {
                return mItem;
            }
        }
        return null;
    }

}
