package com.mojo.toolkit.base;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.Toast;

import com.mojo.toolkit.manager.SessionManager;

/**
 * Created by hu on 2018/2/7.
 */
//全局app类，定义全局session、toast、初始化极光推送
public class MyApplication extends Application {

    //
    private static MyApplication mInstance;
    private static Context context;
    private static Toast toast;
    private static SessionManager session;


    public SessionManager getSession()
    {
        if(session==null)
        {
            session=new SessionManager(context);
        }
        return session;
    }


    public static MyApplication getInstance(){
        if(mInstance == null){
            mInstance = new MyApplication();
        }
        return mInstance;
    }

    public Context getContext()
    {
        return getApplicationContext();
    }

    @SuppressLint("ShowToast")
    public static void setResultToToast(final String string) {
        if (toast == null) {
            toast = Toast.makeText(context, string, Toast.LENGTH_SHORT);
        } else {
            toast.setText(string);
        }
        toast.show();
    }

    @Override
    public void onCreate()
    {
        super.onCreate();

        context = getApplicationContext();
        session = new SessionManager(context);
        Log.e("onCreate","...");
    }

    public static PackageInfo getVersion(){
        PackageManager packageManager = context.getPackageManager();
        PackageInfo packInfo = null;
        try {
            packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return packInfo;
    }

    @Override
    public void onTerminate() {
        mInstance = null;
        context = null;
        super.onTerminate();
    }
}
