package com.mojo.toolkit.views;

import android.content.Context;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class TabLayout2 extends TabLayout {

    public TabLayout2(@NonNull Context context) {
        super(context);
    }

    public TabLayout2(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public void setupWithViewPager2(ViewPager2 viewPager,boolean smoothScroll){
        List<Tab> tabs = new ArrayList<>();
        int i = -1;
        while (this.getTabAt(++i) != null){
            tabs.add(this.getTabAt(i));
        }
        this.addOnTabSelectedListener(new OnTabSelectedListener() {
            @Override
            public void onTabSelected(Tab tab) {
                viewPager.setCurrentItem(tabs.indexOf(tab),smoothScroll);
            }

            @Override
            public void onTabUnselected(Tab tab) {

            }

            @Override
            public void onTabReselected(Tab tab) {

            }
        });
    }

}
