package com.mojo.toolkit.classes.PicturePreview;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.mojo.toolkit.R;

import java.util.ArrayList;
import java.util.List;

public class PreviewActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private final ArrayList<View> aList = new ArrayList<>();
    private List<String> list;
    private TextView imgIndex;

    static void start(Context context,ImageListWithIndex imageListWithIndex ){
        Intent intent = new Intent(context,PreviewActivity.class);
        Bundle bundle = new Bundle();
        Log.e("init_data: ", new Gson().toJson(imageListWithIndex));
        bundle.putSerializable(PicturePreviewConfig.PREVIEW,imageListWithIndex);
        intent.putExtras(bundle);
        context.startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);//设置透明状态栏
        setContentView(R.layout.activity_preview);

        //隐藏标题栏
        //StatusBarUtils.with(this).init();
        viewPager = findViewById(R.id.view_pager);
        imgIndex = findViewById(R.id.image_index);
        init_data();
        findViewById(R.id.back_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void init_data() {
        ImageListWithIndex data = (ImageListWithIndex) getIntent().getSerializableExtra(PicturePreviewConfig.PREVIEW);
        Log.e("init_data: ", new Gson().toJson(data));
        if(data != null){
            list = data.list;
            String text = data.index+1+"/"+list.size();
            imgIndex.setText(text);
            for(int  i = 0 ; i < list.size() ; i++){
                View  view = View.inflate(this,R.layout.view_image_viewpager,null);
                ImageView imageView = view.findViewById(R.id.preview_image);
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        finish();
                    }
                });
                Log.e("Image","......"+list.get(i));
                Glide.with(this)
                        .load(list.get(i))
                        .into(imageView);
                aList.add(view);
            }
            ImagePagerAdapter mAdapter = new ImagePagerAdapter(aList);
            viewPager.setAdapter(mAdapter);
            viewPager.setCurrentItem(data.index);
            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }
                @Override
                public void onPageSelected(int position) {
                    String text = position+1+"/"+list.size();
                    imgIndex.setText(text);
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });
        }

    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.activity_alpha_in, R.anim.activity_alpha_out);
    }
}
