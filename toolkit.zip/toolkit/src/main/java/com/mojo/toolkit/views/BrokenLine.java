package com.mojo.toolkit.views;

import static com.king.mlkit.vision.camera.util.LogUtils.TAG;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PathEffect;
import android.graphics.Point;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.mojo.toolkit.utils.DensityUtil;
/**
 * 自定义虚线
 * */
public class BrokenLine extends androidx.appcompat.widget.AppCompatTextView {
    private Paint linePaint;
    private int lineWidth = DensityUtil.dip2px(getContext(), 1);
    private Point stPoint, endPoint;

    public BrokenLine(Context context) {
        this(context, null, 0);
    }

    public BrokenLine(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BrokenLine(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView() {
        linePaint = new Paint();
        linePaint.setAntiAlias(true);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setColor(getCurrentTextColor());
        PathEffect effect = new DashPathEffect(new float[]{5, 5}, 1);
        linePaint.setPathEffect(effect);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        linePaint.setStrokeWidth(lineWidth);
        canvas.drawLine(stPoint.x, stPoint.y, endPoint.x, endPoint.y, linePaint);
        super.onDraw(canvas);
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);

        int heightSize = MeasureSpec.getSize(heightMeasureSpec);

        if (stPoint == null) {
            stPoint = new Point();
        }
        if (endPoint == null) {
            endPoint = new Point();
        }
        lineWidth = Math.min(widthSize, heightSize);

        boolean isVertical = heightSize > widthSize;
        stPoint.x = isVertical ? lineWidth / 2 : 0;
        stPoint.y = isVertical ? 0 : lineWidth / 2;
        endPoint.x = isVertical ? lineWidth / 2 : widthSize;
        endPoint.y = isVertical ? heightSize : lineWidth / 2;

        setMeasuredDimension(widthSize, heightSize);
    }
}
