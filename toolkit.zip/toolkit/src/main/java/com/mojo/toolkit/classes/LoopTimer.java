package com.mojo.toolkit.classes;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import com.mojo.toolkit.classes.dialogs.WaitDialog;

import java.util.Timer;
import java.util.TimerTask;

/***
 * 自定义定时器，可实现循环执行任务
 *
 * ***/


public class LoopTimer {
    private Timer timer;
    private long delay = 0;
    private long loopFre = 1000;
    private long loopLimit = 10000;
    private long loopTimes = 0;
    private OnLoopListener onLoopListener;
    private final WaitDialog waitDialog;
    private boolean hindDialog = false;

    public LoopTimer(Context context) {
        waitDialog = WaitDialog.build(context);
    }

    private final Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message message) {
            if (message.arg1 == 0){
                if(onLoopListener!=null){
                    onLoopListener.onStop(loopTimes*loopFre);
                }
                stopLoop();
            }else {
                if(onLoopListener!=null){
                    onLoopListener.onLooped(loopTimes);
                }
            }
            return false;
        }
    });

    public void hindDialog(){
        this.hindDialog = true;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    public void setLoopFre(long loopFre) {
        this.loopFre = loopFre;
    }

    public void setLoopLimit(long millions) {
        this.loopLimit = millions;
    }

    public void setOnLoopListener(OnLoopListener onLoopListener) {
        if(this.onLoopListener != null)  this.onLoopListener = null;
        this.onLoopListener = onLoopListener;
    }

    public void startLoop(){
        if(timer != null){
            timer = null;
        }
        timer = new Timer();
        loopTimes = 0;
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                loopTimes++;
                Message message = new Message();
                message.arg1 = loopTimes*loopFre > loopLimit?0:1;
                handler.sendMessage(message);
            }
        };
        timer.schedule(timerTask,delay,loopFre);
        if(!waitDialog.isWaiting() && !hindDialog){
            waitDialog.start("操作中...");
        }
    }

    public void stopLoop(){
        if(timer != null){
            timer.cancel();
            timer = null;
        }
        if(waitDialog.isWaiting()){
            waitDialog.stop();
        }
    }

    public interface OnLoopListener{
        void onLooped(long spend);
        void onStop(long spend);
    }
}
