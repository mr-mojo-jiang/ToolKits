package com.mojo.toolkit.manager;

import android.content.Context;
import android.content.SharedPreferences;


/**
 * Created by hu on 2018/2/7.
 */

//全局session，用来保存各种缓存信息
public class SessionManager {
    // Shared Preferences 共享内存
    private SharedPreferences pref;
    // Editor for Shared preferences 编辑共享内存的编辑器
    private SharedPreferences.Editor editor;
    // Context 上下文
    private final Context _context;
    // Shared pref mode 共享模式 0代表私有
    private final int PRIVATE_MODE = 0;
    // Sharedpref file name 文件名
    private static final String PREF_NAME = "AndroidHivePref";

    // Constructor
    public SessionManager(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
        editor.apply();
    }
    //保存数据
    public void saveData(String value, String key){
        if(pref == null) {
            pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        }
        if (editor == null) {
            editor = pref.edit();
        }
        editor.putString(key,value);//存入数据
        editor.apply();
    }

    //读取数据
    public String getData(String key) {
        if(pref==null) {
            pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        }

        if (editor==null) {
            editor = pref.edit();
        }
        editor.apply();
        return pref.getString(key,"");
    }

    //删除数据
    public void deleteData(String key) {
        if(pref == null) {
            pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        }

        if (editor == null) {
            editor = pref.edit();
        }
        editor.remove(key);
        editor.apply();
    }

    public SharedPreferences.Editor getEditor(){
        if (this.editor==null)
        {
            editor = pref.edit();
        }
        return editor;
    }

}
