package com.mojo.toolkit.utils;

import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PathEffect;

public class PaintUtil {

    public static Paint getFramePaint() {
        Paint framePaint = new Paint();
        framePaint.setAntiAlias(true);
        framePaint.setStrokeWidth(2);
        framePaint.setStyle(Paint.Style.STROKE);
        framePaint.setColor(Color.BLACK);
        PathEffect effect = new DashPathEffect(new float[]{5.0F, 5.0F}, 1.0F);
        framePaint.setPathEffect(effect);
        return framePaint;
    }

    public static Paint getTextPaint() {
        Paint textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setColor(Color.BLACK);
        textPaint.setTextAlign(Paint.Align.CENTER);
        return textPaint;
    }

    public static Paint getLinePaint() {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStrokeWidth(2);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);
        return paint;
    }

    public static Paint getFillPaint() {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.BLACK);
        return paint;
    }

    /**
     * 获取需要绘制文字的基线（baseline）到中轴线（y/2）的距离
     */
    public static float getBaseline(Paint paint) {
        return getTop2Center(paint) + getTextHeight(paint) / 2;
    }

    /**
     * 根据paint和文字所在位置的Top值获取Baseline值
     */
    public static float getBaselineByTop(Paint paint, float top) {
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return top - fontMetrics.top;
    }

    /**
     * 根据paint和文字所在位置的Bottom值获取Baseline值
     */
    public static float getBaselineByBottom(Paint paint, float bottom) {
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return bottom - fontMetrics.bottom;
    }

    /**
     * 根据paint和文字所在位置的centerY值获取Baseline值
     */
    public static float getBaselineByCenterY(Paint paint, float centerY) {
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return centerY - (fontMetrics.top + fontMetrics.bottom) / 2;
    }

    /**
     * 获取需要绘制文字的基线（baseline）到中轴线（y/2）的距离
     */
    public static float getBaseline(int textSize) {
        Paint paint = new Paint();
        paint.setTextSize(textSize);
        return getTop2Center(paint) + getTextHeight(textSize) / 2;
    }

    /**
     * 获取需要绘制文字的基线（baseline）到中轴线（y/2）的距离
     */
    public static float getTop2Center(Paint paint) {
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return (fontMetrics.descent - fontMetrics.ascent) / 2 - fontMetrics.descent;
    }

    public static float getTextHeight(Paint paint) {
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return fontMetrics.bottom - fontMetrics.top;
    }

    public static float getTextHeight(int size) {
        Paint paint = new Paint();
        paint.setTextSize(size);
        return getTextHeight(paint);
    }

}
