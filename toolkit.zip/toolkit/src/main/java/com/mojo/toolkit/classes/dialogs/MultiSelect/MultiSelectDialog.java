package com.mojo.toolkit.classes.dialogs.MultiSelect;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mojo.toolkit.classes.OnItemClickListener;
import com.mojo.toolkit.model.KeyValueItem;
import com.mojo.toolkit.base.BaseDialog;
import com.mojo.toolkit.utils.CompoundImageUtil;
import com.mojo.toolkit.utils.ScreenSizeUtils;

import java.util.List;

/**
 * 多选弹窗
 * T为KeyValueItem中的类型
 * 若T为int类型，切设置showIcon为true，则会将该int作为资源Id，获取图片，作为选项的图标
 */
public class MultiSelectDialog<T> extends BaseDialog {
    private RecyclerView recyclerView;

    private GridLayoutManager manager;
    private MultiAdapter<T> multiAdapter;
    private OnItemClickListener<KeyValueItem<T>> onItemClickListener;

    public MultiSelectDialog(@NonNull Context context) {
        super(context);
        initView();
    }

    @Override
    public View getView() {
        recyclerView = new RecyclerView(context);
        manager = new GridLayoutManager(context, 2);
        manager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(manager);
        multiAdapter = new MultiAdapter<>(context);
        recyclerView.setAdapter(multiAdapter);
        this.setPadding(20,20,20,20);
        this.setWidth((int) (ScreenSizeUtils.getInstance(context).getScreenWidth()*0.5f));
        return recyclerView;
    }

    private void initView() {
        multiAdapter.setOnItemClickListener(onClick);
    }

    /**
     * @param orientation 设置List方向
     */
    public void setOrientation(int orientation) {
        manager.setOrientation(orientation);
    }

    /**
     * @param items 选择列表
     */
    public void setItems(List<KeyValueItem<T>> items) {
        multiAdapter.setItemList(items);
    }

    /**
     * @param l 左边距
     * @param t 上边距
     * @param r 右边距
     * @param b 下边距
     */
    public void setPadding(int l, int t, int r, int b) {
        recyclerView.setPadding(l, t, r, b);
    }

    /**
     * @param isShowIcon 是否将项目中带的int类型作为显示图标
     */
    public void setShowIcon(boolean isShowIcon) {
        multiAdapter.setShowIcon(isShowIcon);
    }

    /**
     * @param location 设置选择项中icon的位置
     */
    public void setItemIconLocation(CompoundImageUtil.Location location) {
        multiAdapter.setIconLocation(location);
    }

    public void setOnItemClickListener(OnItemClickListener<KeyValueItem<T>> onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    private final OnItemClickListener<KeyValueItem<T>> onClick = item -> {
        new Handler().postDelayed(this::dismiss,50);
        if(onItemClickListener != null){
            onItemClickListener.onItemClick(item);
        }
    };

}
