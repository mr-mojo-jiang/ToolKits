package com.mojo.toolkit.classes.Pop;

import com.mojo.toolkit.model.KeyValueItem;

public interface OnItemClickListener<T> {
    void onItemClick(KeyValueItem<T> item);
    void onDelete(KeyValueItem<T> item);
}
