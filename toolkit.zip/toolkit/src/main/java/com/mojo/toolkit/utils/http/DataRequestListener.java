package com.mojo.toolkit.utils.http;

public interface DataRequestListener {
    void onFail(String msg);
    void onSucceed(String result);
}
