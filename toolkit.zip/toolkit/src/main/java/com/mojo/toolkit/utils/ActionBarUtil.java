package com.mojo.toolkit.utils;

import android.app.Activity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.mojo.toolkit.R;

public class ActionBarUtil {
    public static void showActionBar(Activity context,String title){
        ImageView backIcon = context.findViewById(R.id.backIcon);
        backIcon.setVisibility(View.INVISIBLE);
        TextView tvTitle = context.findViewById(R.id.tvTitle);
        tvTitle.setText(title);
    }
    public static void showActionBar(View rootView ,String title){
        ImageView backIcon = rootView.findViewById(R.id.backIcon);
        backIcon.setVisibility(View.INVISIBLE);
        TextView tvTitle = rootView.findViewById(R.id.tvTitle);
        tvTitle.setText(title);
    }

    public static void showLeftViewActionBar(Activity mActivity, String title){
        ImageView backIcon = mActivity.findViewById(R.id.backIcon);
        backIcon.setVisibility(View.VISIBLE);
        backIcon.setOnClickListener(view -> mActivity.finish());

        TextView tvTitle = mActivity.findViewById(R.id.tvTitle);
        tvTitle.setText(title);
    }

    public static void showLeftViewActionBar(View rootView, Activity context, String title){
        ImageView backIcon = rootView.findViewById(R.id.backIcon);
        backIcon.setVisibility(View.VISIBLE);
        backIcon.setOnClickListener(view -> context.finish());

        TextView tvTitle = rootView.findViewById(R.id.tvTitle);
        tvTitle.setText(title);
    }

    public static void showRightViewActionBar(View rootView, Activity context, String title,String rightStr){
        TextView tvRight = rootView.findViewById(R.id.tvRight);
        tvRight.setVisibility(View.VISIBLE);
        tvRight.setText(rightStr);

        TextView tvTitle = rootView.findViewById(R.id.tvTitle);
        tvTitle.setText(title);
    }

    public static void showAllViewActionBar(View rootView, Activity context, String title ,String rightStr){
        TextView tvTitle = rootView.findViewById(R.id.tvTitle);
        tvTitle.setText(title);

        ImageView backIcon = rootView.findViewById(R.id.backIcon);
        backIcon.setVisibility(View.VISIBLE);
        backIcon.setOnClickListener(view -> context.finish());

        TextView tvRight = rootView.findViewById(R.id.tvRight);
        tvRight.setVisibility(View.VISIBLE);
        tvRight.setText(rightStr);
    }

    public static void showAllViewActionBar(Activity context, String title ,String rightStr,View.OnClickListener rightClickListener){
        TextView tvTitle = context.findViewById(R.id.tvTitle);
        tvTitle.setText(title);

        ImageView backIcon = context.findViewById(R.id.backIcon);
        backIcon.setVisibility(View.VISIBLE);
        backIcon.setOnClickListener(view -> context.finish());

        TextView tvRight = context.findViewById(R.id.tvRight);
        tvRight.setVisibility(View.VISIBLE);
        tvRight.setText(rightStr);
        tvRight.setOnClickListener(rightClickListener);
    }
}
