package com.mojo.toolkit.views.Progress;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.mojo.toolkit.utils.DensityUtil;


/**
 * 自定义ProgressBar,使用时设置进度条的宽，高。
 */
public class CustomProgressBar extends View {
    private final Context mContext;
    private Paint sumPaint,progressPaint,textPaint;
    private float utilLength;
    private int max = 100;
    private int mProcess = 50;
    private RectF sumRec,proRec;
    private float radius;
    private String percent = "0%";
    private float textPointX,textPointY;

    public CustomProgressBar(Context context) {
        this(context,null);
    }

    public CustomProgressBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        init();
    }

    void init(){
        sumPaint = new Paint();
        sumPaint.setColor(0x0FFEBEEF5);
        sumPaint.setStyle(Paint.Style.FILL);
        sumPaint.setAntiAlias(true);

        textPaint = new Paint();
        textPaint.setColor(0x0FF4094F7);
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setAntiAlias(true);

        progressPaint = new Paint();
        progressPaint.setColor(0x0FF4094F7);
        progressPaint.setStyle(Paint.Style.FILL);
        progressPaint.setAntiAlias(true);


        sumRec = new RectF(0,0,0, 0);
        proRec = new RectF(0,0,0, 0);
    }

    public void setProcess(int process){
        this.mProcess = Math.min(max, process);
        this.percent = mProcess*100/max+"%";
        invalidate();
    }

    public void setMax(int max) {
        this.max = max;
        this.percent = mProcess*100/max+"%";
        invalidate();
    }

    public int getProgress(){
        return mProcess;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawRoundRect(sumRec,radius,radius,sumPaint);
        proRec.right = utilLength * mProcess;
        canvas.drawRoundRect(proRec,radius,radius,progressPaint);
        canvas.drawText(percent,textPointX,textPointY,textPaint);

    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        // 获取宽-测量规则的模式和大小
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        // 获取高-测量规则的模式和大小
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);

        // 设置默认宽高
        int mWidth = DensityUtil.dip2px(getContext(),200);
        int mHeight = DensityUtil.dip2px(getContext(),14);
        // 当模式是AT_MOST（即wrap_content）时设置默认值
        if (widthMode == MeasureSpec.AT_MOST && heightMode == MeasureSpec.AT_MOST) {
            widthSize = mWidth;
            heightSize = mHeight;
            setMeasuredDimension(mWidth, mHeight);
        } else if (widthMode == MeasureSpec.AT_MOST) {
            widthSize = mWidth;
        } else if (heightMode == MeasureSpec.AT_MOST) {
            heightSize = mHeight;
        }
        setMeasuredDimension(widthSize, heightSize);
        initViewSize(widthSize, heightSize);
    }

    private void initViewSize(int widthSize, int heightSize) {
        textPaint.setTextSize(heightSize);
        textPointX = widthSize - textPaint.measureText("100%");
        textPointY = heightSize/2f + getBaseline(textPaint);
        sumRec.right = textPointX - 10;
        utilLength = sumRec.right /max;
        float barWidth = heightSize/2f;
        float pad = (heightSize-barWidth)/2;
        sumRec.top = proRec.top = pad;
        proRec.bottom = sumRec.bottom = heightSize-pad;
        radius = heightSize;
    }

    /**
     * 计算绘制文字时的基线到中轴线的距离
     * @param p
     * @return 基线和centerY的距离
     */
    public float getBaseline(Paint p) {
        Paint.FontMetrics fontMetrics = p.getFontMetrics();
        return (fontMetrics.descent - fontMetrics.ascent) / 2 -fontMetrics.descent;
    }
}
