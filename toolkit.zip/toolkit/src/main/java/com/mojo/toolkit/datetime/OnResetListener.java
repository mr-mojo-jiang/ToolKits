package com.mojo.toolkit.datetime;

public interface OnResetListener {
    void reset();
}
