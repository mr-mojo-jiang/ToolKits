package com.mojo.toolkit.model;

public class KeyValueItem<T> {
    private T value;
    private String key;

    public KeyValueItem() {
    }

    public KeyValueItem(T value, String key) {
        this.value = value;
        this.key = key;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
