package com.mojo.toolkit.classes.dialogs.TwoGradeListDialog;

public interface OnSelectListener {
    void onSelected(GradeItem item);
}
