package com.mojo.toolkit.views.refreshLayout;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.Toast;

import com.mojo.toolkit.classes.CustomToast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;

public class MySmartRefreshLayout extends SmartRefreshLayout {
    private final Context context;
    private int delay = 500;

    public MySmartRefreshLayout(Context context) {
        this(context,null);
    }

    public MySmartRefreshLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        initView();
    }

    private void initView(){
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        HeaderView mHeaderView = new HeaderView(context);
        mHeaderView.setLayoutParams(layoutParams);
        addView(mHeaderView);

    }

    public MySmartRefreshLayout setDelay(int delay){
        this.delay = delay;
        return this;
    }

    public void finishLoad(int size) {
        if(size == 0) {
            Toast.makeText(context,"没有更多数据了",Toast.LENGTH_SHORT).show();
        }
        finishLoadMore(delay);
    }

    public void finishRefreshData(int size) {
        if(size == 0){
            Toast.makeText(context,"已经是最新数据了",Toast.LENGTH_SHORT).show();
        }
        finishRefresh(delay);
    }
}
