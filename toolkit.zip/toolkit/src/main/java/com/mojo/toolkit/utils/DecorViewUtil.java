package com.mojo.toolkit.utils;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * DecorView为Activity最根部的View
 * 一个活动包含关系：Window->DecorView->FrameLayout->包含：1.开发者定义的View，setContentView，2.ActionBar
 */
public class DecorViewUtil {

    /**
     * @param context （Activity的Context）上下文
     * @return DecorView
     */
    public static View getDecorView(Context context) {
        return ((Activity) context).getWindow().getDecorView();
    }

    /**
     * @param context （Activity的Context）上下文
     * @return 屏幕高度
     */
    public static int getScreenHeight(Context context) {
        return getDecorView(context).getHeight();
    }

    /**
     * @param context （Activity的Context）上下文
     * @return 屏幕宽度
     */
    public static int getScreenWidth(Context context) {
        return getDecorView(context).getWidth();
    }

    /**
     * @param context activity的Content
     * @return 获取该activity所有view
     */
    public static List<View> getAllChildViews(Context context) {
        return getAllChildViews(getDecorView(context));
    }

    /**
     * @param view 控件
     * @return 返回该控件下的所有子View
     */
    private static List<View> getAllChildViews(View view) {
        List<View> allChildren = new ArrayList<>();
        if (view instanceof ViewGroup) {
            ViewGroup vp = (ViewGroup) view;
            for (int i = 0; i < vp.getChildCount(); i++) {
                View child = vp.getChildAt(i);
                allChildren.add(child);
                allChildren.addAll(getAllChildViews(child));
            }
        }
        return allChildren;
    }

}
