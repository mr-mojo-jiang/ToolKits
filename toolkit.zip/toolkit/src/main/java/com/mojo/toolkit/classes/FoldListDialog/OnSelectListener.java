package com.mojo.toolkit.classes.FoldListDialog;

import com.mojo.toolkit.model.FoldItem;

public interface OnSelectListener<T> {
    void onSelected(FoldItem<T> item);
}
