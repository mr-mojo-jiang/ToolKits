package com.mojo.toolkit.views.PercentChart;

public interface OnMarkClickListener {
    void onClick(BarChartItem barChartItem);
}
