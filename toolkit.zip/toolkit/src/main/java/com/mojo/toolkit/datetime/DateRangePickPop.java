package com.mojo.toolkit.datetime;

import android.app.Activity;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.haibin.calendarview.Calendar;
import com.haibin.calendarview.CalendarView;
import com.mojo.toolkit.R;
import com.mojo.toolkit.base.DropDownPopupWindow;

import java.util.Date;
/**
 * 自定义日期范围选择组件，调用时需要引用原有库，否则会报错，找不到xml的attrs
 *引入：implementation 'com.haibin:calendarview:3.7.1'
 */
public class DateRangePickPop extends DropDownPopupWindow implements View.OnClickListener {
    private final Activity context;
    private OnRangeSelectListener onRangeSelectListener;
    private OnResetListener onResetListener;
    private Calendar startCalendar;
    private Calendar endCalendar;
    private View shadowView;
    private int mYear, mMonth, mDay;
    private CalendarView calendarView;

    public DateRangePickPop(Activity context){
        super(context);
        this.context = context;
        init();
    }

    public static DateRangePickPop build(Activity context){
        return new DateRangePickPop(context);
    }

    private void  init(){
        View rootView = View.inflate(context, R.layout.view_date_range,null);

        TextView tvMonth;
        tvMonth = rootView.findViewById(R.id.tv_month);
        calendarView = rootView.findViewById(R.id.calendarView);
        calendarView.setRange(2000,1,1,2030,12,31);
        calendarView.scrollToCurrent();
        if(startCalendar != null && endCalendar != null){
            calendarView.setSelectCalendarRange(startCalendar,endCalendar);
        }
        calendarView.setOnMonthChangeListener((year, month) -> {
            mYear = year;
            mMonth = month;
            String date = year+"年"+month+"月";
            tvMonth.setText(date);
        });
        calendarView.setOnCalendarRangeSelectListener(rangeSelectListener);
        mYear = calendarView.getCurYear();
        mMonth = calendarView.getCurMonth();
        mDay = calendarView.getCurDay();

        ImageView pre = rootView.findViewById(R.id.btn_pre);
        pre.setOnClickListener(view -> {
            if(mMonth == 1){
                mYear -= 1;
            }
            mMonth = mMonth == 1 ? mMonth = 12: mMonth -1;
            calendarView.scrollToCalendar(mYear, mMonth, mDay,true);
        });

        ImageView next = rootView.findViewById(R.id.btn_next);
        next.setOnClickListener(view -> {
            if(mMonth == 12){
                mYear += 1;
            }
            mMonth = mMonth == 12 ? mMonth = 1: mMonth +1;
            calendarView.scrollToCalendar(mYear, mMonth, mDay,true);
        });
        String date = mYear+"年"+mMonth+"月";
        tvMonth.setText(date);

        (rootView.findViewById(R.id.btnConfirm)).setOnClickListener(this);
        (rootView.findViewById(R.id.btnReset)).setOnClickListener(this);
        this.setView(rootView);
    }

    public DateRangePickPop setOnRangeSelectListener(OnRangeSelectListener onRangeSelectListener) {
        this.onRangeSelectListener = onRangeSelectListener;
        return this;
    }

    public DateRangePickPop setOnResetListener(OnResetListener onResetListener) {
        this.onResetListener = onResetListener;
        return this;
    }

    public void showAsViewDropDown(View anchor) {
        this.openPop(anchor);
    }



    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnConfirm){
            if(this.onRangeSelectListener!= null){
                if(startCalendar == null || endCalendar == null){
                    onResetListener.reset();
                }else {
                    Date startDate = CalendarDateUtil.getDate(startCalendar);
                    Date endDate = CalendarDateUtil.getDate(endCalendar);
                    onRangeSelectListener.onSelected(startDate,endDate);
                }
                new Handler().postDelayed(this::dismiss,100);
            }
        }else {
            startCalendar = null;
            endCalendar = null;
            calendarView.clearSelectRange();
            if(onResetListener != null){
                onResetListener.reset();
            }
            dismiss();
        }
    }

    private final CalendarView.OnCalendarRangeSelectListener rangeSelectListener = new CalendarView.OnCalendarRangeSelectListener() {
        @Override
        public void onCalendarSelectOutOfRange(Calendar calendar) {

        }

        @Override
        public void onSelectOutOfRange(Calendar calendar, boolean isOutOfMinRange) {

        }

        @Override
        public void onCalendarRangeSelect(Calendar calendar, boolean isEnd) {
            if(isEnd) {
                endCalendar = calendar;
            } else {
                startCalendar = calendar;
                endCalendar = null;
            }
        }
    };

}
