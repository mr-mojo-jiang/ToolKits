package com.mojo.toolkit.views.SteeringWheel;

import static android.graphics.BitmapFactory.decodeResource;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import com.mojo.toolkit.R;
import com.mojo.toolkit.utils.DensityUtil;

/**
 * 方向盘控制View
 */
public class ScaleView extends ControlView {
    private Paint paint;
    private int centerX, centerY;
    private int pressIndex = 0;
    private Rect bgRect;
    private float radius;//加号减号长度的一半
    private float offset;//加号减号中心距View中心的距离

    public ScaleView(Context context) {
        super(context);
    }

    public ScaleView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public ScaleView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    void initView() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.STROKE);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                measurePressIndex(event.getX());
                if (onControlListener != null) {
                    disposeListener();
                }
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pressIndex = 0;
                if (onControlListener != null) {
                    onControlListener.onChanged(Direction.Null);
                }
                invalidate();
                performClick();
                break;
        }
        return true;
    }

    private void disposeListener() {
        String direction;
        switch (pressIndex) {
            case 1:
                direction = Direction.ScaleUp;
                break;
            case 2:
                direction = Direction.ScaleDown;
                break;
            default:
                direction = Direction.Null;
                break;
        }
        onControlListener.onChanged(direction);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    private void measurePressIndex(float ex) {
        if (ex < centerX) {
            pressIndex = 1;
        } else if (ex > centerX) {
            pressIndex = 2;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Bitmap bg = decodeResource(getResources(), R.drawable.icon_scale);
        canvas.drawBitmap(bg, null, bgRect, null);
        //加号
        paint.setColor(pressIndex == 1 ? Color.parseColor("#0D71FD") : Color.parseColor("#92B4C8"));
        canvas.drawLine(centerX - offset - radius, centerY, centerX - offset + radius, centerY, paint);
        canvas.drawLine(centerX - offset, centerY - radius, centerX - offset, centerY + radius, paint);
        //减号
        paint.setColor(pressIndex == 2 ? Color.parseColor("#0D71FD") : Color.parseColor("#92B4C8"));
        canvas.drawLine(centerX + offset - radius, centerY, centerX + offset + radius, centerY, paint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int wSize = MeasureSpec.getSize(widthMeasureSpec);
        int wMode = MeasureSpec.getMode(widthMeasureSpec);

        int hSize = MeasureSpec.getSize(widthMeasureSpec);
        int hMode = MeasureSpec.getMode(widthMeasureSpec);
        if (wMode == MeasureSpec.AT_MOST && hMode == MeasureSpec.AT_MOST) {
            hSize = DensityUtil.dip2px(getContext(), 40);
            wSize = (int) (hSize * 2.5f);
        } else if (wMode == MeasureSpec.AT_MOST) {
            hSize = (int) (wSize / 2.5f);
        } else if (hMode == MeasureSpec.AT_MOST) {
            wSize = (int) (hSize * 2.5f);
        }
        setMeasuredDimension(wSize, hSize);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        centerX = w / 2;
        centerY = h / 2;
        radius = h / 5f;
        offset = centerX / 2.5f;
        bgRect = new Rect(0, 0, w, h);
        paint.setStrokeWidth(h / 12f);
    }

}
