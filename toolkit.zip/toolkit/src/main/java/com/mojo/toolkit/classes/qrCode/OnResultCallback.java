package com.mojo.toolkit.classes.qrCode;

import android.app.Activity;

import java.util.List;

public interface OnResultCallback {
    void onScanResults(List<String> results, boolean isAlbum, Activity activity);
}
