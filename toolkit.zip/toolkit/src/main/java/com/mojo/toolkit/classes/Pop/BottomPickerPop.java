package com.mojo.toolkit.classes.Pop;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.mojo.toolkit.R;
import com.mojo.toolkit.classes.OnItemClickListener;
import com.mojo.toolkit.model.KeyValueItem;
import com.mojo.toolkit.utils.DensityUtil;
import com.mojo.toolkit.utils.RvDecorationUtil;
import com.mojo.toolkit.views.PickScrollView;

import java.util.List;

public class BottomPickerPop<T> extends BottomPop {
    private View view;
    private OnItemClickListener<KeyValueItem<T>> mOnItemClickListener;
    private PickScrollView<T> picker;

    public BottomPickerPop(Activity mContext) {
        super(mContext);
    }

    @Override
    public void initView() {
        view = View.inflate(mContext, R.layout.view_picker, null);
        picker = view.findViewById(R.id.picker);
        setView(view);
    }

    public void setSelectItemList(List<KeyValueItem<T>> list) {
        picker.setItems(list);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1,-2);
        view.setLayoutParams(params);
    }

    public void setOnItemClickListener(OnItemClickListener<KeyValueItem<T>> mOnItemClickListener) {
        this.mOnItemClickListener = mOnItemClickListener;
    }

    @Override
    public void onCancel() {

    }

    @Override
    public void onConfirm() {
        if (mOnItemClickListener != null) {
            mOnItemClickListener.onItemClick(picker.getSelectItem());;
        }
        dismiss();
    }

}
