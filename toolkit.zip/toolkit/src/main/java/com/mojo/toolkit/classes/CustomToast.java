package com.mojo.toolkit.classes;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mojo.toolkit.R;


public class CustomToast extends Toast {
    private final Context mContext;
    private TextView tvToast;
    private ImageView imageView;
    private State state = null;
    private int duration = Toast.LENGTH_SHORT;

    public CustomToast(Context context) {
        super(context);
        this.mContext = context;
        initView();
    }

    public static CustomToast build(Context context){
        return new CustomToast(context);
    }

    void initView(){
        this.setGravity(Gravity.CENTER,0,100);
        //设置显示时间
        this.setDuration(Toast.LENGTH_SHORT);
        View view = View.inflate(mContext, R.layout.view_toast,null);
        imageView = view.findViewById(R.id.toastIcon);
        tvToast = view.findViewById(R.id.tvShowMsg);
        this.setView(view);
    }

    public CustomToast setDelay(int duration) {
        this.duration = duration;
        this.setDuration(2);
        return this;
    }

    public CustomToast setState(boolean succeed){
        this.state = succeed? State.SUCCEED: State.FAILED;
        int drawId = R.drawable.icon_fail;
        if(succeed){
            drawId = R.drawable.icon_succeed;
        }
        imageView.setBackgroundResource(drawId);
        imageView.setVisibility(View.VISIBLE);
        return this;
    }

    public void showMsg(String msg){
        tvToast.setText(msg);
        if(state != null){
            int drawId = state == State.SUCCEED ? R.drawable.icon_succeed: R.drawable.icon_fail;
            imageView.setBackgroundResource(drawId);
            imageView.setVisibility(View.VISIBLE);
        }else {
            imageView.setVisibility(View.GONE);
        }
        this.show();
    }

    enum State{
        SUCCEED,FAILED
    }
}
