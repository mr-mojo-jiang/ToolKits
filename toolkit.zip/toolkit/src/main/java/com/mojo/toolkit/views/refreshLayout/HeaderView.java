package com.mojo.toolkit.views.refreshLayout;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mojo.toolkit.R;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.constant.RefreshState;
import com.scwang.smartrefresh.layout.internal.InternalAbstract;

public class HeaderView extends InternalAbstract implements RefreshHeader {
    public String REFRESH_HEADER_PULLING = "下拉可以刷新";//"下拉可以刷新";
    public String REFRESH_HEADER_LOADING = "刷新中...";//"正在加载...";
    public String REFRESH_HEADER_RELEASE = "释放立即刷新";
    public String REFRESH_HEADER_FINISH = "刷新成功!";//"刷新完成";
    public String REFRESH_HEADER_FAILED = "刷新失败!";//"刷新失败";
    private TextView mTitleText;

    public HeaderView(Context context) {
        this(context, null,0);
    }

    public HeaderView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }


    protected HeaderView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    private void initView(){
        View headerView = View.inflate(getContext(), R.layout.view_header, null);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        headerView.setLayoutParams(params);
        //View headerView = LayoutInflater.from(getContext()).inflate( R.layout.refresh_layout_header, null);
        mTitleText = headerView.findViewById(R.id.refresh_state);
        //Log.e("MyRefreshHeader","initView"+mTitleText.getId());
        addView(headerView);
        //invalidate();
    }

    @Override
    public int onFinish(@NonNull RefreshLayout layout, boolean success) {
        if (success) {
            mTitleText.setText(REFRESH_HEADER_FINISH);
        } else {
            mTitleText.setText(REFRESH_HEADER_FAILED);
        }
        super.onFinish(layout, success);
        return 500; //延迟500毫秒之后再弹回
    }

    @Override
    public void onStateChanged(@NonNull RefreshLayout refreshLayout, @NonNull RefreshState oldState, @NonNull RefreshState newState) {
        switch (newState) {
            case PullDownToRefresh: //下拉过程
                mTitleText.setText(REFRESH_HEADER_PULLING);
                break;
            case ReleaseToRefresh: //松开刷新
                mTitleText.setText(REFRESH_HEADER_RELEASE);
                break;
            case Refreshing: //loading中
                mTitleText.setText(REFRESH_HEADER_LOADING);
                break;
        }
    }
}
