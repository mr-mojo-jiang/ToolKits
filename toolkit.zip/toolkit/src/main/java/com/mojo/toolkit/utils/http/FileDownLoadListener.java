package com.mojo.toolkit.utils.http;

import java.io.File;

public interface FileDownLoadListener {
    void onSucceed(File file);
    void onFailed(String reason);
    void onLoading(double progress);
}
