package com.mojo.toolkit.base;

import android.content.Context;

public interface BaseView {
    Context getContext();
    void startWait();
    void stopWait();

}
