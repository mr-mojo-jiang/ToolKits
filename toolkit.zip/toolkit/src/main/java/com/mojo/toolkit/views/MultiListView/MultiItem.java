package com.mojo.toolkit.views.MultiListView;

import java.util.ArrayList;
import java.util.List;

public class MultiItem {
    /**
     * 用于显示，如名称
     */
    private String tag;
    /**
     * 用于比较，比如Id
     */
    private String key;
    /**
     * 类别，最顶层类别
     */
    private String type;
    /**
     * 是否可以查询
     */
    private boolean searchable;
    /**
     * 下级数据，可多级迭代
     */
    private List<MultiItem> values;

    public MultiItem() {
    }

    public MultiItem(String tag, String key) {
        this.tag = tag;
        this.key = key;
        this.values = new ArrayList<>();
    }

    public MultiItem(String tag, String key,String type, boolean searchable) {
        this.tag = tag;
        this.key = key;
        this.type = type;
        this.searchable = searchable;
    }

    public MultiItem(String tag, String key, List<MultiItem> values) {
        this.tag = tag;
        this.key = key;
        this.values = values;
    }



    public MultiItem(String tag, String key, boolean searchable, List<MultiItem> values) {
        this.tag = tag;
        this.key = key;
        this.searchable = searchable;
        this.values = values;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isSearchable() {
        return searchable;
    }

    public void setSearchable(boolean searchable) {
        this.searchable = searchable;
    }

    public List<MultiItem> getValues() {
        return values == null ? new ArrayList<>():values;
    }

    public void setValues(List<MultiItem> values) {
        this.values = values;
    }
}
