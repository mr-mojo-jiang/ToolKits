package com.mojo.toolkit.views.SteeringWheel;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public abstract class ControlView extends View {
    OnControlListener onControlListener;
    public ControlView(Context context) {
        this(context, null);
    }

    public ControlView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ControlView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    abstract void initView();

    public void setOnControlListener(OnControlListener onControlListener){
        this.onControlListener = onControlListener;
    }
}
