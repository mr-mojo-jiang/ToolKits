package com.mojo.toolkit.classes.dialogs.TwoGradeListDialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.mojo.toolkit.R;
import com.mojo.toolkit.utils.DensityUtil;
import com.mojo.toolkit.utils.RvDecorationUtil;

import java.util.List;

public class TwoGradeListDialog {
    private final Context mContext;
    private OnSelectListener onSelectListener;
    private Dialog dialog;
    private TwoGradeRvAdapter rvAdapter;

    public TwoGradeListDialog(Context mContext) {
        this.mContext = mContext;
        initView();
    }

    private void initView(){
        RecyclerView recyclerView = new RecyclerView(mContext);

        recyclerView.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        LinearLayoutManager layoutManager = new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        rvAdapter = new TwoGradeRvAdapter(mContext);
        rvAdapter.setOnItemClickListener(item -> {
            if(onSelectListener!=null){
                onSelectListener.onSelected(item);
            }
            dialog.dismiss();
        });
        recyclerView.setAdapter(rvAdapter);
        RvDecorationUtil.build(mContext).setDividerIntoView(recyclerView);
        int paddingSE = DensityUtil.dip2px(mContext,20);
        int paddingTB = DensityUtil.dip2px(mContext,12);
        recyclerView.setPadding(paddingSE,paddingTB,paddingSE,paddingTB);

        dialog = new AlertDialog.Builder(mContext).setView(recyclerView).create();
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
    }

    public void setGradeItemList(List<GradeItem> gradeItemList) {
        rvAdapter.setItemList(gradeItemList);
    }

    public void setOnItemSelectedListener(OnSelectListener onSelectListener) {
        this.onSelectListener = onSelectListener;
    }

    public void show(){
        dialog.show();
        int width =  dialog.getWindow().getAttributes().width;
        int height = DensityUtil.dip2px(mContext,40) + rvAdapter.getRvHeight();
        dialog.getWindow().setLayout(width, height);
    }


    public int getSelectSum() {
        return rvAdapter.getItemCount();
    }
}
