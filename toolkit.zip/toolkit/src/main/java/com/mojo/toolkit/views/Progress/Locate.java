package com.mojo.toolkit.views.Progress;

public enum Locate {
    START,
    TOP,
    END,
    BOTTOM
}
