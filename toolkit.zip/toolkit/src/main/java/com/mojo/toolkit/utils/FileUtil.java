package com.mojo.toolkit.utils;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import java.io.File;

public class FileUtil {
    private static String TAG = "FileUtil";

    public static String createFile(Context context, String fileName) {
        File directory = new File(getRootPath(context) + File.separator + fileName);
        // 目录不存在就创建
        if (!directory.exists()) directory.mkdirs();
        Log.e(TAG, "buildPath: " + directory.getPath());
        return directory.getPath();
    }

    public static String getRootPath(Context context) {
        File sdDir;
        boolean sdCardExist = Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);// 判断sd卡是否存在
        if (sdCardExist) {
            if (Build.VERSION.SDK_INT >= 29) {
                //Android10之后
                sdDir = context.getExternalFilesDir(null);
            } else {
                sdDir = Environment.getExternalStorageDirectory();// 获取SD卡根目录
            }
        } else {
            sdDir = Environment.getRootDirectory();// 获取跟目录
        }
        return sdDir.toString();
    }
}
