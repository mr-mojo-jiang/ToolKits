package com.mojo.toolkit.datetime;

public interface OnDateSelectListener2 {
    void onSelected(String dateStr);
}
