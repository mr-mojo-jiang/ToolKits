package com.mojo.toolkit.views.SteeringWheel;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import com.mojo.toolkit.utils.DensityUtil;

/**
 * 方向盘控制View
 */
public class SteeringWheelView extends View {
    //抬起的Paint
    private Paint upliftPaint;
    //按下的Paint
    private Paint pressPaint;
    //按下的Paint
    private Paint circleInsidePaint;
    //按下的Paint
    private Paint circleOutsidePaint;
    private Paint arrowPaint;
    private int pressColor = 0x0FF1670FA;
    private int center;
    private RectF shadowRect;
    private final float shadowSize = 6;
    private int pressIndex = 0;
    private float arrowW;
    private float arrowH;
    private OnControlListener directionChangeListener;

    public SteeringWheelView(Context context) {
        this(context, null);
    }

    public SteeringWheelView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SteeringWheelView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        shadowRect = new RectF(shadowSize / 2, shadowSize / 2, 0, 0);

        upliftPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        upliftPaint.setStyle(Paint.Style.FILL);
        upliftPaint.setStrokeWidth(shadowSize);
        upliftPaint.setColor(Color.WHITE);
        upliftPaint.setShadowLayer(shadowSize, 0, 0, 0x088000000);

        pressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pressPaint.setColor(pressColor);
        pressPaint.setStyle(Paint.Style.FILL);
        pressPaint.setStrokeWidth(shadowSize);

        circleInsidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        circleInsidePaint.setStyle(Paint.Style.FILL);
        circleInsidePaint.setStrokeWidth(shadowSize);
        circleInsidePaint.setColor(0x0FFECF0F7);

        circleOutsidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        circleOutsidePaint.setStyle(Paint.Style.FILL);
        circleOutsidePaint.setStrokeWidth(shadowSize);
        circleOutsidePaint.setColor(0x0FFCAD2DF);

        arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arrowPaint.setStyle(Paint.Style.FILL);
        arrowPaint.setStrokeWidth(shadowSize);
        arrowPaint.setColor(pressColor);
    }

    public void setDirectionChangeListener(OnControlListener directionChangeListener) {
        this.directionChangeListener = directionChangeListener;
    }

    public void setPressColor(int pressColor) {
        this.pressColor = pressColor;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                measurePressIndex(event.getX(), event.getY());
                if (directionChangeListener != null) {
                    disposeListener();
                }
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pressIndex = 0;
                if (directionChangeListener != null) {
                    directionChangeListener.onChanged(Direction.Null);
                }
                invalidate();
                performClick();
                break;
        }
        return true;
    }

    private void disposeListener() {
        String direction;
        switch (pressIndex) {
            case 1:
                direction = Direction.Left;
                break;
            case 2:
                direction = Direction.Top;
                break;
            case 3:
                direction = Direction.Right;
                break;
            case 4:
                direction = Direction.Bottom;
                break;
            default:
                direction = Direction.Null;
                break;
        }
        directionChangeListener.onChanged(direction);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    private void measurePressIndex(float ex, float ey) {
        float x = ex - center;
        float y = ey - center;
        if ((x * x + y * y) < center * center / 4f) {
            pressIndex = 0;
        } else if (x > 0 && y > 0) {
            pressIndex = x > y ? 3 : 4;
        } else if (x < 0 && y > 0) {
            pressIndex = Math.abs(x) > y ? 1 : 4;
        } else if (x < 0 && y < 0) {
            pressIndex = Math.abs(x) > Math.abs(y) ? 1 : 2;
        } else {
            pressIndex = x > Math.abs(y) ? 3 : 2;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawArc(shadowRect, 0, 360, true, pressPaint);
        canvas.drawArc(shadowRect, 225 + (pressIndex - 1) * 90, pressIndex > 0 ? 270 : 360, true, upliftPaint);

        for (int i = 1; i < 5; i++) {
            drawArrowKey(canvas, i);
        }

        canvas.drawCircle(center, center, center / 2f, circleInsidePaint);
        canvas.drawCircle(center, center, center / 3f, circleOutsidePaint);
    }

    /**
     * 绘制按钮中的小三角
     */
    private void drawArrowKey(Canvas canvas, int index) {
        //外圈圆环宽度的一半
        int halfRing = center / 4;
        int i1 = index > 2 ? 1 : 0;
        int i2 = index > 2 ? 3 : 1;
        int i3 = index > 2 ? 1 : -1;
        float x1 = index % 2 == 0 ? center : (center * i1 + halfRing * i2 + i3 * arrowW / 2);
        float y1 = index % 2 == 0 ? (center * i1 + halfRing * i2 + i3 * arrowW / 2) : center;

        float x2 = index % 2 == 0 ? center - arrowH / 2 : (center * i1 + halfRing * i2 - i3 * arrowW / 2);
        float y2 = index % 2 == 0 ? (center * i1 + halfRing * i2 - i3 * arrowW / 2) : center - arrowH / 2;

        float x3 = index % 2 == 0 ? center + arrowH / 2 : (center * i1 + halfRing * i2 - i3 * arrowW / 2);
        float y3 = index % 2 == 0 ? (center * i1 + halfRing * i2 - i3 * arrowW / 2) : center + arrowH / 2;


        Path path = new Path();
        path.reset();
        arrowPaint.setColor(index == pressIndex ? Color.WHITE : pressColor);
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.lineTo(x1, y1);
        canvas.drawPath(path, arrowPaint);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int wSize = MeasureSpec.getSize(widthMeasureSpec);
        int wMode = MeasureSpec.getMode(widthMeasureSpec);

        int hSize = MeasureSpec.getSize(widthMeasureSpec);
        int hMode = MeasureSpec.getMode(widthMeasureSpec);
        int size;
        if (wMode == MeasureSpec.AT_MOST && hMode == MeasureSpec.AT_MOST) {
            size = DensityUtil.dip2px(getContext(), 160);
        } else {
            size = Math.min(wSize, hSize);
        }
        setMeasuredDimension(size, size);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        shadowRect.right = w - shadowSize;
        shadowRect.bottom = h - shadowSize;
        if (w == h) {
            center = w / 2;
        }
        arrowW = center / 8f;
        arrowH = arrowW * 1.5f;
    }

}
