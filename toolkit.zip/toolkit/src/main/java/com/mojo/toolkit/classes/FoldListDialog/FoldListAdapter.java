package com.mojo.toolkit.classes.FoldListDialog;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.mojo.toolkit.R;
import com.mojo.toolkit.model.FoldItem;
import com.mojo.toolkit.utils.DensityUtil;

import java.util.ArrayList;
import java.util.List;

public class FoldListAdapter<T> extends RecyclerView.Adapter<FoldListAdapter.ViewHolder> {
    private final Context mContext;
    private List<FoldItem<T>> mAllList;
    private final List<FoldItem<T>> mItemList;
    private OnItemClickListener<T> onItemClickListener;

    public FoldListAdapter(Context mContext) {
        this.mContext = mContext;
        mItemList = new ArrayList<>();
    }

    public void setItemList(List<FoldItem<T>> itemList) {
        this.mAllList = new ArrayList<>(itemList);
        refreshShowList();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void refreshShowList() {
        mItemList.clear();
        for (FoldItem<T> item : mAllList) {
            if (item.getParentKey().isEmpty() || item.isShow()) {
                mItemList.add(item);
            }
        }
        if (onItemClickListener != null)
            onItemClickListener.onExpand();
        this.notifyDataSetChanged();
    }


    public void setOnItemClickListener(OnItemClickListener<T> onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.view_grade_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FoldItem<T> item = mItemList.get(position);
        holder.tvItem.setText(item.getKey());
        boolean b = item.getParentKey().isEmpty();
        holder.icon.setVisibility(b ? View.VISIBLE : View.GONE);
        holder.tvItem.setPadding(b ? 0 : 20, 0, 0, 0);
        holder.icon.setVisibility(b ? View.VISIBLE : View.GONE);
        holder.icon.setBackgroundResource(item.isShow() ? R.drawable.icon_up : R.drawable.icon_down);
        holder.tvItem.setTextColor(ContextCompat.getColor(mContext, b ? R.color.black_s : R.color.black_m));
        holder.itemView.setOnClickListener(view -> {
            if (item.isChild()) {
                if (onItemClickListener != null)
                    onItemClickListener.onItemClick(item);
            } else {
                item.setShow(!item.isShow());
                refreshChild(item);
            }
        });
    }

    private void refreshChild(FoldItem<T> item) {
        for (FoldItem<T> item1 : mAllList) {
            if (item1.getParentKey().equals(item.getKey())) {
                item1.setShow(item.isShow());
            }
        }
        refreshShowList();
    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public int getRvHeight() {
        return Math.min(mItemList.size(), 10) * DensityUtil.dip2px(mContext, 45);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvItem;
        ImageView icon;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItem = itemView.findViewById(R.id.tv_item);
            icon = itemView.findViewById(R.id.icon);
        }
    }

    public static interface OnItemClickListener<T> {
        void onItemClick(FoldItem<T> item);

        void onExpand();
    }
}
