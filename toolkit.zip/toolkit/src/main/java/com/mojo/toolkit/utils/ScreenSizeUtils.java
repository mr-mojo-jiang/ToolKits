package com.mojo.toolkit.utils;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.lang.ref.WeakReference;

/**
 * 获取屏幕宽高的帮助类
 */
public class ScreenSizeUtils {
    private final Context mContent;
    private final DisplayMetrics dm;
    private final float density;
    private final int screenWidth;
    private final int screenHeight;


    public static ScreenSizeUtils getInstance(Context mContext) {
        return new ScreenSizeUtils(mContext);
    }

    private ScreenSizeUtils(Context mContext) {
        this.mContent = mContext;
        //软引用context
        WeakReference<Context> contextWeakReference = new WeakReference<>(mContext);
        Context context = contextWeakReference.get();
        WindowManager manager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        dm = new DisplayMetrics();
        manager.getDefaultDisplay().getMetrics(dm);


        screenWidth = dm.widthPixels;// 获取屏幕分辨率宽度
        screenHeight = dm.heightPixels;
        // 屏幕密度（0.75 / 1.0 / 1.5）
        density = dm.density;
        int densityDpi = dm.densityDpi;     // 屏幕密度dpi（120 / 160 / 240）

    }

    public float getDensity() {
        return density;
    }

    //获取屏幕dp宽度
    public int getScreenDpWidth() {
        return (int) (screenWidth / density);
    }

    //获取屏幕dp高度
    public int getScreenDpHeight() {
        return (int) (screenHeight / density);
    }

    //获取屏幕宽度
    public int getScreenWidth() {
        return screenWidth;
    }

    //获取屏幕高度
    public int getScreenHeight() {
        return screenHeight + getStatusBarHeight();
    }

    public int dp2px(int dp) {
        final float scale = dm.density;
        return (int) (dp * scale + 0.5f);
    }

    /**
     * 获取状态栏高度——方法1
     */
    public int getStatusBarHeight() {
        int statusBarHeight1 = -1;
        //获取status_bar_height资源的ID
        int resourceId = mContent.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            //根据资源ID获取响应的尺寸值
            statusBarHeight1 = mContent.getResources().getDimensionPixelSize(resourceId);
        }
        return statusBarHeight1;
    }

}
