package com.mojo.toolkit.utils;

import android.content.res.ColorStateList;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class TabLayoutUtil {
    private final TabLayout tabLayout;
    private static boolean enableChangeSize = false;
    private int unSelectSize = 15, selectSize = 16;

    private TabLayoutUtil(TabLayout tabLayout) {
        this.tabLayout = tabLayout;
    }

    public static TabLayoutUtil build(TabLayout tabLayout) {
        return new TabLayoutUtil(tabLayout);
    }

    /**
     * 使能选择切换时，文字大小变化
     * @return TabLayoutUtil
     */
    public TabLayoutUtil enableChangeStyle() {
        enableChangeSize = true;
        return this;
    }

    /**
     * @param selectSize 选中时的文字大小dp
     * @param unSelectSize 未选中时的文字大小dp
     * @return TabLayoutUtil
     */
    public TabLayoutUtil setTextSizes(int selectSize, int unSelectSize) {
        this.selectSize = selectSize;
        this.unSelectSize = unSelectSize;
        return this;
    }

    /**
     * @param color 点击动画
     * @return TabLayoutUtil
     */
    public TabLayoutUtil setTabRippleColor(@Nullable ColorStateList color) {
        tabLayout.setTabRippleColor(color);
        return this;
    }

    /**
     * 取消切换动画
     * @return TabLayoutUtil
     */
    public TabLayoutUtil cancelClickAnimator() {
        tabLayout.setTabRippleColor(null);
        return this;
    }

    /**
     * @param onSelectedListener 添加监听器，只监听文字
     */
    public void setOnSelectedListener(OnSelectedListener onSelectedListener) {
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                String tabStr = Objects.requireNonNull(tab.getText()).toString();
                if (onSelectedListener != null) {
                    onSelectedListener.onSelected(tabStr);
                }
                disposeTab(tab, true);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                disposeTab(tab, false);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    /**
     * 代码新增Tab或者重新设置Tab时，需要调用该方法，否则会报错
     */
    public void refreshTabs() {
        if (!enableChangeSize) return;
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            if (tab == null) continue;
            if (tab.getCustomView() == null || !(tab.getCustomView() instanceof TextView)) {
                setTabCustomView(tab);
            }
        }
    }

    private void disposeTab(TabLayout.Tab tab, boolean select) {
        if (!enableChangeSize) return;
        if (tab.getCustomView() == null || !(tab.getCustomView() instanceof TextView)) {
            setTabCustomView(tab);
        } else {
            ((TextView) tab.getCustomView()).setTextSize(select ? selectSize : unSelectSize);
        }
    }

    private void setTabCustomView(TabLayout.Tab tab) {
        String tabStr = Objects.requireNonNull(tab.getText()).toString();
        TextView tv = new TextView(tabLayout.getContext());
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(-2, -2);
        tv.setLayoutParams(params);
        tv.setTextColor(tabLayout.getTabTextColors());
        tv.setText(tabStr);
        tv.setTextSize(tab.isSelected() ? selectSize : unSelectSize);
        tab.setCustomView(tv);

    }

    public interface OnSelectedListener {
        void onSelected(String tabStr);
    }
}
