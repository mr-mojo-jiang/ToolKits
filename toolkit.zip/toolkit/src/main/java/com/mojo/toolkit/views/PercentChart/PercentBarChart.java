package com.mojo.toolkit.views.PercentChart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;


import java.util.ArrayList;
import java.util.List;

public class PercentBarChart extends View {
    private final List<BarChartItem> chartItems = new ArrayList<>();
    private static final int yLabelNum = 4;//Y轴显示最多的标签个数-1

    private static int sumColor = 0x0ffb2d1ee;
    private static int textColor = 0x0ff222222;

    private float viewHeight;
    private float viewWidth;//视图高宽

    private float boundaryLeftX;//Y轴距布局左的距离，=左边界
    private float boundaryRightX;//Y轴距布局右的距离 = 控件宽度 - 右边界
    private float boundaryTopY ;//图标顶部距布局顶部距离
    private float boundaryBottomY ;//X轴距底部距离

    private float clipsRightX;//图像右边界

    private Paint linePaint;//用于划线
    private Paint barGraphPaint;//画柱形图

    private float barInterval;//柱形之间的距离
    private float barWidth;//柱的宽度
    private float barToX;//柱形图部分距XY轴距离
    private float barBottom;//柱形图底部的位置
    private float baseHeight;//柱形图高度单位

    private float radiusHeight = 5;
    private float zeroHeight = 5;

    private float maxValue;//最大Y值
    private float labelSize;//标签大小
    private int visibleNum = 8;
    private int sumNum;

    private float lastX = 0;
    private float offsetX = 0;
    private boolean isFirst = true;
    private float maxOffset;
    private float clickX1;
    private float clickY1;
    private int clickNum ;
    private boolean isClick;
    private boolean cancelMark;
    private Path path;

    private Path clipPath;
    private RectF markRect;//用于MarkView点击事件
    private OnMarkClickListener onMarkClickListener;
    private RectF barRect;
    private List<Integer> colors;//颜色
    private List<String> legendList;//图例
    private boolean showLegend = true;//是否显示图例
    private boolean showMark = true;//是否显示MarkView

    public PercentBarChart(Context context) {
        this(context, null,0);
    }

    public PercentBarChart(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs,0);
    }

    public PercentBarChart(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init(){
        linePaint = new Paint();
        linePaint.setAntiAlias(true);
        linePaint.setColor(sumColor);
        barGraphPaint = new Paint();
        barGraphPaint.setAntiAlias(true);//设置抗锯齿，更清晰

        barRect = new RectF();
        markRect = new RectF();
        barRect.bottom = barBottom;
        colors = new ArrayList<>();
        colors.add(0x0ff21a1ff);
        colors.add(0x0ffff6e6d);
        legendList = new ArrayList<>();

        offsetX = 0;
        /*float[] radiusList = new float[8];
        radiusList[0] = radiusList[1] = radiusList[2] = radiusList[3] = radius;*/
    }



    public void setViewData(List<BarChartItem> data){
        if(data == null || data.isEmpty()) return;
        legendList.clear();
        for (int i = 0; i < data.get(0).getValueList().size(); i++) {
            legendList.add(data.get(0).getValueList().get(i).tag);
        }
        this.chartItems.clear();
        this.chartItems.addAll(data);
        isFirst = true;
        invalidate();
    }

    public void setColors(List<Integer> colors) {
        this.colors = colors;
        invalidate();
    }

    public void setLegendList(List<String> legendList) {
        this.legendList = legendList;
        invalidate();
    }

    public void setShowLegend(boolean showLegend) {
        this.showLegend = showLegend;
        invalidate();
    }

    public void setShowMark(boolean showMark) {
        this.showMark = showMark;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if(isFirst)
            initSize(canvas);
        canvas.save();
        barGraphPaint.setStyle(Paint.Style.FILL);
        barRect.right = boundaryLeftX+offsetX;
        canvas.clipPath(clipPath);
        if(chartItems.size()>0){
            for(int i = 0; i < chartItems.size() ; i++){
                BarChartItem item = chartItems.get(i);
                barRect.left = barRect.right + (i== 0? barToX : barInterval);
                barRect.bottom = barBottom;
                barRect.right = barRect.left + barWidth;
                barRect.top = barRect.bottom - (item.getSumValue() == 0 ? 10 : item.getSumValue()*baseHeight);
                drawBarGraph(canvas,barRect,item);
            }
        }

        //绘制x轴
        canvas.drawLine(boundaryLeftX,viewHeight- boundaryBottomY,viewWidth-boundaryRightX
                ,viewHeight-boundaryBottomY, linePaint);
        if(showMark && isClick)
            drawMarkView(canvas);
        canvas.restore();
        linePaint.setColor(textColor);
        //绘制Y轴
        canvas.drawLine(boundaryLeftX,viewHeight- boundaryBottomY, boundaryLeftX,
                boundaryTopY, linePaint);
        drawYAxisLabel(canvas);
        if(showLegend)
            drawViewLabel(canvas);
    }

    /*** 初始化位置 ***/
    private void initSize(Canvas canvas) {
        viewHeight = canvas.getHeight();
        viewWidth = canvas.getWidth();
        boundaryLeftX = viewWidth/12;
        boundaryRightX = viewWidth/20;
        boundaryTopY = viewHeight/12;
        boundaryBottomY = viewHeight/6;
        barToX = viewWidth/23;

        for (BarChartItem data : chartItems) {
            maxValue = Math.max(maxValue,data.getSumValue());
        }
        baseHeight = (viewHeight- boundaryBottomY - boundaryTopY - barToX) / maxValue;
        labelSize = viewWidth/40;
        float barSpace = 90;
        for (BarChartItem item : chartItems) {
            linePaint.setTextSize(labelSize);
            barSpace = Math.max(barSpace,linePaint.measureText(item.getTag())+labelSize);

        }
        barWidth = 30;
        barInterval = barSpace- barWidth;
        visibleNum =  (int) ((viewWidth - boundaryLeftX - boundaryRightX - barToX)/(barInterval+barWidth));
        sumNum = chartItems.size()-1;
        barBottom = viewHeight- boundaryBottomY;
        maxOffset = -(barInterval + barWidth)*(sumNum - visibleNum) ;

        clipsRightX = viewWidth- boundaryRightX;//限制框右边界赋值
        clipPath = new Path();
        clipPath.moveTo(boundaryLeftX,0);
        clipPath.lineTo(clipsRightX,0);
        clipPath.lineTo(clipsRightX,barBottom+radiusHeight*2);
        clipPath.lineTo(clipsRightX+ barToX /4,barBottom+radiusHeight*2);
        clipPath.lineTo(clipsRightX+ barToX /4,viewHeight);
        clipPath.lineTo(boundaryLeftX,viewHeight);
        clipPath.lineTo(boundaryLeftX,boundaryTopY);
    }

    /*** 绘制柱状图 ***/
    void drawBarGraph(Canvas canvas, RectF rect, BarChartItem item){
        for (BarEntry entry  : item.getValueList()) {
            int index = item.getValueList().indexOf(entry);
            rect.bottom = index == 0 ? rect.bottom:rect.top ;
            rect.top = rect.bottom - entry.value * baseHeight;
            barGraphPaint.setColor(colors.get(index));
            canvas.drawRect(rect,barGraphPaint);
        }

        float labelX = rect.left + (rect.right-rect.left)/2;
        float labelY = viewHeight - boundaryBottomY + labelSize*2;
        linePaint.setColor(0x0ff262A2D);
        linePaint.setTextSize(labelSize);
        linePaint.setTextAlign(Paint.Align.CENTER);

        canvas.drawText(item.getTag(),labelX,labelY,linePaint);/**/
    }


    /*** 绘制y轴坐标 ***/
    private void drawYAxisLabel(Canvas canvas) {
        int yLabelInterval =  (int) maxValue / yLabelNum;
        if( maxValue % yLabelNum !=0)
            yLabelInterval += 1;
        float rightToY = boundaryLeftX * 5/6;
        linePaint.setColor(0x0ff262A2D);
        linePaint.setTextSize(labelSize);
        linePaint.setTextAlign(Paint.Align.RIGHT);
        for(int i = 0 ; i < yLabelNum + 1 ;i++){
            String label = String.valueOf(yLabelInterval*i) ;
            float y = barBottom-yLabelInterval*i*baseHeight;
            canvas.drawText(label,rightToY,y+labelSize/2,linePaint);
        }
    }

    /*** 绘制MarkView ***/
    private void drawMarkView(Canvas canvas) {
        BarChartItem item = chartItems.get(clickNum);
        float markWidth = barInterval + barWidth;
        float barX = boundaryLeftX + barToX + (barWidth + barInterval)*clickNum + offsetX ;
        if( barX > clipsRightX || (barX+barWidth) < boundaryLeftX || cancelMark){ return; }

        float left = barX + barWidth/2 - markWidth;
        float right = left + markWidth*2 ;
        //Log.e("界线",right+"..." + clipsRightX+"");
        if(right > clipsRightX  ){
            right = clipsRightX;
            left = right - markWidth*2 ;
        }else if(left < boundaryLeftX){
            left = boundaryLeftX;
            right = left + markWidth*2 ;
        }
        float bottom = barBottom - (item.getSumValue() == 0 ? 10 : item.getSumValue()*baseHeight) - zeroHeight;
        float top = bottom - (right-left)*3/4;
        if(top < 0){
            top = 10;
            bottom = top + barWidth*(legendList.size()+3);
        }
        //画MarkView
        markRect.left = left;
        markRect.top = top;
        markRect.right = right;
        markRect.bottom = bottom;
        barGraphPaint.setColor(0x0AA000000);
        canvas.drawRoundRect(markRect,5,5,barGraphPaint);
        path = new Path();
        path.moveTo(barX,bottom);
        path.lineTo(barX+barWidth/2,bottom+barWidth/3);
        path.lineTo(barX+barWidth,bottom);
        canvas.drawPath(path,barGraphPaint);

        //写字
        linePaint.setColor(0x0ffffffff);
        float textSize = barWidth ;
        linePaint.setTextSize(textSize);
        float textX = left + (right-left)/2;
        float textY = top + (bottom - top)/4;
        canvas.drawText("合计"+"："+item.getSumValue(),textX,textY,linePaint);
        textY += textSize*3/2;
        for (BarEntry entry : item.getValueList()) {
            linePaint.setColor(colors.get(item.getValueList().indexOf(entry)));
            canvas.drawText(entry.tag+"："+entry.value,textX,textY,linePaint);
            textY += textSize*3/2;
        }

    }

    /*** 绘制图例 ***/
    private void drawViewLabel(Canvas canvas) {
        float tSize = boundaryTopY*2/3;
        linePaint.setColor(textColor);
        linePaint.setTextSize(tSize);
        linePaint.setTextAlign(Paint.Align.RIGHT);
        float legendH = tSize * 2/3;
        for (int i = legendList.size() - 1; i >=0 ; i--) {
            barGraphPaint.setColor(colors.get(i));
            String legend = legendList.get(i);
            float textWidth = linePaint.measureText(legend);
            float cx = clipsRightX - (textWidth + tSize * 2) * i;
            float cy = tSize * 3/2;
            canvas.drawText(legend,cx,cy,linePaint);
            float s = cx - textWidth - tSize/3 - tSize;
            float b = cy -( tSize*4/5 - legendH)/2;
            canvas.drawRoundRect(s,b-legendH, s+ tSize,b,2,2,barGraphPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                // 记录触摸点坐标
                lastX =  event.getX();
                clickX1 = event.getX();
                clickY1 = event.getY();
                isFirst = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if(sumNum > visibleNum){
                    // 计算偏移量
                    offsetX +=  event.getX() - lastX;
                    offsetX = Math.min(0,Math.max(offsetX,maxOffset));
                    invalidate();
                    lastX = event.getX();
                }
                break;
            case MotionEvent.ACTION_UP:
                float clickX2 = event.getX();
                float clickY2 = event.getY();
                if(Math.abs(clickX1-clickX2)<5 && Math.abs(clickY1-clickY2)<5
                        && clickX2 > boundaryLeftX && clickX2 < clipsRightX )
                    clickEvent(event);
                else {
                    isClick = false;
                }
                break;
        }
        return true;
    }

    public void setOnMarkClickListener(OnMarkClickListener onMarkClickListener) {
        this.onMarkClickListener = onMarkClickListener;
    }

    /*** 点击事件处理 ***/
    private void clickEvent(MotionEvent event) {
        float clickX = event.getX();
        float clickY = event.getY();
        if(isClickMarkView(event)){
            if(onMarkClickListener != null)
                onMarkClickListener.onClick(chartItems.get(clickNum));
        }else {
            if(clickY > boundaryTopY + barToX && clickY < barBottom ){
                for(int i = 0; i < chartItems.size() ; i++){
                    float left = boundaryLeftX + barToX + (barWidth + barInterval)*i +offsetX - barInterval/2;
                    float right = left + barWidth + barInterval/2;
                    isClick = clickX > left && clickX < right;
                    if(isClick){
                        cancelMark = i == clickNum && !cancelMark;
                        clickNum = i;
                        invalidate();
                        break;
                    }
                }
            }
        }
    }

    /*** 是否点击了MarkView ***/
    boolean isClickMarkView(MotionEvent event){
        float clickX = event.getX();
        float clickY = event.getY();
        if(isClick){
            return markRect != null && clickX > markRect.left && clickX < markRect.right
                    && clickY < markRect.bottom && clickY > markRect.top;
        }else
            return false;

    }
}
