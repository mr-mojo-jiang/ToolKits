package com.mojo.toolkit.base;

public abstract class BaseModel<V extends BaseView,P extends BasePresenter<?,?,?>> {
    public V view;
    public P presenter;

    public BaseModel(P mPresenter,V mView) {
        this.presenter = mPresenter;
        this.view = mView;
    }

    public  void unBindView(){
        this.view = null;
    }

}
