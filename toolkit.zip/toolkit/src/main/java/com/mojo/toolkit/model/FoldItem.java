package com.mojo.toolkit.model;

public class FoldItem<T> {
    private T value;
    private String key;
    private boolean isChild;
    private String parentKey;
    private boolean show;

    public FoldItem() {
    }

    public FoldItem(KeyValueItem<T> item) {
        this.value = item.getValue();
        this.key = item.getKey();
        this.isChild = true;
        this.show = true;
        this.parentKey = "parentKey";
    }

    public FoldItem(String key, T value) {
        this.value = value;
        this.key = key;
        this.isChild = true;
        this.show = true;
        this.parentKey = "parentKey";
    }

    public FoldItem(String key, T value, boolean isShow) {
        this.key = key;
        this.value = value;
        this.isChild = true;
        this.show = isShow;
        this.parentKey = "parentKey";
    }

    public FoldItem(String key, T value, String parentKey) {
        this.key = key;
        this.value = value;
        this.parentKey = parentKey;
        this.isChild = !parentKey.isEmpty();
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isChild() {
        return isChild;
    }

    public void setChild(boolean child) {
        isChild = child;
    }

    public String getParentKey() {
        return parentKey;
    }

    public void setParentKey(String parentKey) {
        this.parentKey = parentKey;
    }

    public boolean isShow() {
        return show;
    }

    public void setShow(boolean show) {
        this.show = show;
    }
}
