package com.mojo.toolkit.datetime;

import java.util.Date;

public interface OnDateSelectListener {
    void onSelected(Date date);
}
