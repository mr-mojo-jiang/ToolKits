package com.mojo.toolkit.classes;

import android.text.Editable;
import android.text.TextWatcher;

public class LimitWatcher implements TextWatcher {
    private int maxSize = -1;
    private int beforeLength;//输入前长度
    private int coursor;//当前光标位置
    private OnLengthChangeListener onLengthChangeListener;

    public LimitWatcher setMaxSize(int size){
        this.maxSize = size;
        return this;
    }

    public LimitWatcher setOnLengthChangeListener(OnLengthChangeListener onLengthChangeListener) {
        this.onLengthChangeListener = onLengthChangeListener;
        return this;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        beforeLength = s.length();
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        coursor = start;
        if(onLengthChangeListener != null){
            onLengthChangeListener.onChanged(s);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {
        int afterLength = s.length();
        if (maxSize != -1 && s.length() > maxSize) {
            int over = afterLength - maxSize;//超出最大限制多少字
            int input = afterLength - beforeLength;//输入了多少字
            int st = coursor + (input - over);
            int en = coursor + input;//此时游标末尾
            s.delete(st, en);
        }
    }

    public interface OnLengthChangeListener{
        void onChanged(CharSequence s);
    }
}
