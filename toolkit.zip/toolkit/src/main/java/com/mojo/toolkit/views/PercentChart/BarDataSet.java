package com.mojo.toolkit.views.PercentChart;

public class BarDataSet {
    int color;
    float value;

}
