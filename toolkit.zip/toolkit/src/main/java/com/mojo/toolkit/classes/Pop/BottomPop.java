package com.mojo.toolkit.classes.Pop;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.mojo.toolkit.R;


public abstract class BottomPop extends PopupWindow implements View.OnClickListener {
    public final Activity mContext;
    private LinearLayout contentView;
    private View view;
    private TextView btnCancel;
    public WindowManager.LayoutParams params;
    private int heightSize = ViewGroup.LayoutParams.WRAP_CONTENT;

    public BottomPop(Activity mContext){
        this.mContext = mContext;
        init();
        initView();
    }

    @SuppressLint("InflateParams")
    private void init(){
        this.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        view = LayoutInflater.from(mContext).inflate(R.layout.view_bottom_pop,null,false);
        contentView = view.findViewById(R.id.lyContent);
        btnCancel = view.findViewById(R.id.btn_cancel);
        TextView btnConfirm = view.findViewById(R.id.btn_confirm);

        btnCancel.setOnClickListener(this);
        btnConfirm.setOnClickListener(this);
        this.setContentView(view);
        this.setWidth(ViewGroup.LayoutParams.MATCH_PARENT);// 设置弹出窗口的宽
        this.setFocusable(true);// 设置可弹出窗口
        this.setAnimationStyle(R.style.my_pop_anim_style);// 设置动画
        params = mContext.getWindow().getAttributes();
    }

    public void setPositiveText(String text){
        btnCancel.setText(text);
        btnCancel.setTextColor(Color.BLACK);
    }

    public void setBackGround(Drawable resourceId){
        view.setBackground(resourceId);
    }

    public abstract void initView();
    public abstract void onCancel();
    public abstract void onConfirm();

    public void setView(View view){
        contentView.addView(view);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btn_cancel){
            this.onCancel();
            dismiss();
        }else {
           this.onConfirm();
        }
    }

    public void setHeightSize(int heightSize) {
        this.heightSize = heightSize;
    }

    public void openPop(){
        this.setHeight(heightSize);// 设置弹出窗口的高
        params.alpha = 0.3f;
        mContext.getWindow().setAttributes(params);
        this.showAtLocation(view, Gravity.BOTTOM, 0, 0);
    }

    @Override
    public void dismiss() {
        params.alpha = 1.0f;
        mContext.getWindow().setAttributes(params);
        super.dismiss();
    }
}
