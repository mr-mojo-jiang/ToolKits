package com.mojo.toolkit.manager;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;

@RequiresApi(api = Build.VERSION_CODES.M)
public class TorchManager {
    String TAG = "TorchManager";
    private final Context mContext;
    private CameraManager mCameraManager;
    private CaptureRequest captureRequest;
    private String mCameraId;

    public TorchManager(Context mContext) {
        this.mContext = mContext;
        if (hasFlashlight()) {
            initVersionM();
        }
    }


    private void initVersionM() {
        mCameraManager = (CameraManager) mContext.getSystemService(Context.CAMERA_SERVICE);
        CameraDevice cameraDevice;

        try {
            mCameraId = getCameraId();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        // 注册针对闪光灯的状态回调
        if (mCameraId != null) {
            mCameraManager.registerTorchCallback(mTorchCallback, null);
        }
    }

    // 判断是否支持
    public boolean hasFlashlight() {
        return mContext.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
    }

    private String getCameraId() throws CameraAccessException {
        String[] ids = mCameraManager.getCameraIdList();
        for (String id : ids) {
            CameraCharacteristics c = mCameraManager.getCameraCharacteristics(id);
            //支持闪光灯
            Boolean flashAvailable = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            //后置
            Integer lensFacing = c.get(CameraCharacteristics.LENS_FACING);
            if (flashAvailable != null && flashAvailable
                    && lensFacing != null && lensFacing == CameraCharacteristics.LENS_FACING_BACK) {
                return id;
            }
        }
        return null;
    }

    // 开启/关闭闪光灯
    public void setFlashlight(boolean enabled) {
        if (mCameraId == null) {
            return;
        }

        try {
            mCameraManager.setTorchMode(mCameraId, enabled);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
        /*new Thread(new Runnable() {
            @Override
            public void run() {
                if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    try {
                        mCameraManager.openCamera(mCameraId, new CameraDevice.StateCallback() {
                            @Override
                            public void onOpened(@NonNull CameraDevice cameraDevice) {
                                Log.e("onOpened: ", cameraDevice.getId());
                                cameraDevice.close();
                            }

                            @Override
                            public void onDisconnected(@NonNull CameraDevice cameraDevice) {
                                Log.e("onOpened: ", cameraDevice.getId());
                            }

                            @Override
                            public void onError(@NonNull CameraDevice cameraDevice, int i) {
                                Log.e("onOpened: ", cameraDevice.getId());
                            }
                        }, new Handler());
                    } catch (CameraAccessException e) {

                    }
                }
            }
        }).start();*/

    }

    // 状态回调
    private final CameraManager.TorchCallback mTorchCallback = new CameraManager.TorchCallback() {
        @Override
        public void onTorchModeUnavailable(String cameraId) {
            Log.e(TAG, "onTorchModeUnavailable: "+cameraId);
        }

        @Override
        public void onTorchModeChanged(String cameraId, boolean enabled) {
        }
    };
}
