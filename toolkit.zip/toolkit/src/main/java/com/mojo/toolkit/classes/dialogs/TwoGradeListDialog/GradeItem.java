package com.mojo.toolkit.classes.dialogs.TwoGradeListDialog;

public class GradeItem {
    private String value;
    private String key;
    private boolean isChild;
    private String parentKey;

    public GradeItem() {
    }

    public GradeItem(String key, String value, boolean isChild) {
        this.key = key;
        this.value = value;
        this.isChild = isChild;
    }

    public GradeItem(String key, String value,String parentKey) {
        this.key = key;
        this.value = value;
        this.parentKey = parentKey;
        this.isChild = true;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isChild() {
        return isChild;
    }

    public void setChild(boolean child) {
        isChild = child;
    }

    public String getParentKey() {
        return parentKey;
    }

    public void setParentKey(String parentKey) {
        this.parentKey = parentKey;
    }
}
