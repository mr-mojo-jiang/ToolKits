package com.mojo.toolkit.views.CircleButton;

import static android.graphics.BitmapFactory.decodeResource;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import com.mojo.toolkit.R;
import com.mojo.toolkit.utils.DensityUtil;

public class CircleButton extends View {
    private Paint paint;
    private int buttonColor = Color.WHITE;
    private float shadowRadius = 6;
    private float center;
    private Rect iconRect;
    private int iconId = 0;
    private OnStateChangeListener onStateChangeListener;

    public CircleButton(Context context) {
        this(context, null);
    }

    public CircleButton(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CircleButton(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView(attrs);
    }

    void initView(AttributeSet attrs) {
        if (attrs != null) {
            //获取自定义属性。
            @SuppressLint("Recycle")
            TypedArray ta = getContext().obtainStyledAttributes(attrs, R.styleable.CircleButton);
            buttonColor = ta.getColor(R.styleable.CircleButton_buttonColor, Color.WHITE);
            iconId = ta.getResourceId(R.styleable.CircleButton_buttonIcon, 0);
            shadowRadius = ta.getDimension(R.styleable.CircleButton_shadowRadius, 6);
        }

        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(buttonColor);
        paint.setShadowLayer(shadowRadius, 0, 0, 0x033000000);
        iconRect = new Rect();
    }

    public void setButtonColor(int buttonColor) {
        this.buttonColor = buttonColor;
    }

    public void setShadowRadius(float shadowRadius) {
        this.shadowRadius = shadowRadius;
    }

    public void setIconId(int iconId) {
        this.iconId = iconId;
    }

    public void setOnStateChangeListener(OnStateChangeListener onStateChangeListener) {
        this.onStateChangeListener = onStateChangeListener;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        setBackground(null);
        canvas.drawCircle(center, center, center - shadowRadius, paint);
        if (iconId != 0) {
            canvas.drawBitmap(decodeResource(getResources(), iconId), null, iconRect, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                shadowRadius += 2;
                if (onStateChangeListener != null) {
                    onStateChangeListener.onChanged(true);
                }
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                shadowRadius -= 2;
                if (onStateChangeListener != null) {
                    onStateChangeListener.onChanged(false);
                }
                invalidate();
                performClick();
                break;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int wSize = MeasureSpec.getSize(widthMeasureSpec);
        int wMode = MeasureSpec.getMode(widthMeasureSpec);

        int hSize = MeasureSpec.getSize(widthMeasureSpec);
        int hMode = MeasureSpec.getMode(widthMeasureSpec);
        int size;
        if (wMode == MeasureSpec.AT_MOST && hMode == MeasureSpec.AT_MOST) {
            size = DensityUtil.dip2px(getContext(), 60);
        } else {
            size = Math.min(wSize, hSize);
        }
        setMeasuredDimension(size, size);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w == h) {
            center = w / 2f;
        }
        int iconHalfSize = (int) (center /3);
        iconRect.left = (int) (center - iconHalfSize);
        iconRect.top = (int) (center - iconHalfSize);
        iconRect.right = (int) (center + iconHalfSize);
        iconRect.bottom = (int) (center + iconHalfSize);
    }

    public interface OnStateChangeListener {
        void onChanged(boolean pressed);
    }
}
