package com.mojo.toolkit.classes.PictureSelector;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.luck.picture.lib.entity.LocalMedia;
import com.mojo.toolkit.R;
import com.mojo.toolkit.classes.PicturePreview.PicturePreviewConfig;

import java.util.ArrayList;
import java.util.List;

//import com.luck.picture.lib.tools.DebugUtil;

/**
 * author：luck
 * project：PictureSelector
 * package：com.luck.pictureselector.adapter
 * email：893855882@qq.com
 * data：16/7/27
 */
public class PictureSelectorImageAdapter extends RecyclerView.Adapter<PictureSelectorImageAdapter.ViewHolder> {
    public final int TYPE_CAMERA = 1;//用于将图片设置为打开相机
    public final int TYPE_PICTURE = 2;

    private List<LocalMedia> urlList;
    private int selectMax = 3;
    private final Context context;
    private int drawableId = R.drawable.icon_take_photo;
    /**
     * 点击添加图片跳转
     */
    private onAddPicClickListener mOnAddPicClickListener;

    @SuppressLint("NotifyDataSetChanged")
    public void refreshList(List<LocalMedia> mediaList) {
        this.urlList = mediaList;
        this.notifyDataSetChanged();
    }

    public interface onAddPicClickListener {
        void onAddPicClick();
        void onDelete(LocalMedia media);
    }

    public PictureSelectorImageAdapter(Context context) {
        this.context = context;
    }

    public PictureSelectorImageAdapter(Context context, onAddPicClickListener mOnAddPicClickListener) {
        this.context = context;
        this.urlList = new ArrayList<>();
        this.mOnAddPicClickListener = mOnAddPicClickListener;
    }

    public void setSelectMax(int selectMax) {
        this.selectMax = selectMax;
    }

    public void setDrawableId(int drawableId){
        this.drawableId = drawableId;
        this.notifyItemRangeChanged(0,urlList.size());
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgSelected;
        ImageView btnDelete;
        TextView tv_duration;

        ViewHolder(View view) {
            super(view);
            imgSelected = (ImageView) view.findViewById(R.id.picture_img);
            btnDelete = (ImageView) view.findViewById(R.id.picture_delete);
            tv_duration = (TextView) view.findViewById(R.id.tv_duration);
        }
    }

    @Override
    public int getItemCount() {
        if (urlList.size() < selectMax) {
            return urlList.size() + 1;
        } else {
            return urlList.size();
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (isShowAddItem(position)) {
            return TYPE_CAMERA;
        } else {
            return TYPE_PICTURE;
        }
    }

    /**
     * 创建ViewHolder
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.adpter_media, viewGroup, false);
        return new ViewHolder(view);
    }

    private boolean isShowAddItem(int position) {
        int size = urlList.size();
        return position == size;
    }

    /**
     * 设置值
     */
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int position) {
        //少于8张，显示继续添加的图标
        if (getItemViewType(position) == TYPE_CAMERA) {
            viewHolder.imgSelected.setImageResource(drawableId);
            viewHolder.imgSelected.setOnClickListener(v -> {
                if(mOnAddPicClickListener!=null)
                    mOnAddPicClickListener.onAddPicClick();
            });
            viewHolder.btnDelete.setVisibility(View.INVISIBLE);
        } else {
            viewHolder.btnDelete.setVisibility(View.VISIBLE);
            viewHolder.btnDelete.setOnClickListener(view -> {
                int index = viewHolder.getAbsoluteAdapterPosition();
                if (index != RecyclerView.NO_POSITION) {
                    if(mOnAddPicClickListener!=null)
                        mOnAddPicClickListener.onDelete(urlList.get(index));
                    urlList.remove(index);
                    notifyItemRemoved(index);
                    notifyItemRangeChanged(index, urlList.size());
                }
            });
            String mediaUrl = urlList.get(position).getPath();

            RequestOptions options = new RequestOptions()
                    .centerCrop()
                    .placeholder(R.color.color_f6)
                    .diskCacheStrategy(DiskCacheStrategy.ALL);
            Log.e("LoadPath",mediaUrl);
            Glide.with(context)
                    .load(mediaUrl)
                    .apply(options)
                    .into(viewHolder.imgSelected);

            //itemView 的点击事件
            viewHolder.itemView.setOnClickListener(v -> PicturePreviewConfig.previewImageOfMedia(context,urlList, viewHolder.getAbsoluteAdapterPosition()));
        }
    }
}
