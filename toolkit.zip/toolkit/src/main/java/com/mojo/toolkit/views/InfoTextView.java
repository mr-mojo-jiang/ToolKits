package com.mojo.toolkit.views;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.util.AttributeSet;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mojo.toolkit.R;


/**
 * 方便显示基本信息
 */
public class InfoTextView extends androidx.appcompat.widget.AppCompatTextView {
    private int tagColor;
    private CharSequence tagStr;
    private String contentStr;

    public InfoTextView(@NonNull Context context) {
        this(context, null, 0);
    }

    public InfoTextView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public InfoTextView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context mContext, AttributeSet attrs) {
        tagColor = getCurrentTextColor();
        if (attrs != null) {
            //获取自定义属性。
            @SuppressLint("Recycle")
            TypedArray ta = mContext.obtainStyledAttributes(attrs, R.styleable.InfoTextView);
            tagStr = ta.getString(R.styleable.InfoTextView_tag_text);
            tagStr = tagStr == null ? "" : tagStr;
            tagColor = ta.getColor(R.styleable.InfoTextView_tag_color, Color.BLACK);
            contentStr = getText().toString();
            setContent();
        }
    }

    public void setInfo(String str) {
        this.contentStr = str;
        setContent();
    }

    public void setTag(String str) {
        this.tagStr = str;
        setContent();
    }

    public void setContent() {
        String text = tagStr + contentStr;
        SpannableStringBuilder builder1 = new SpannableStringBuilder(text);
        if(tagStr.length() > 0){
            ForegroundColorSpan redSpan = new ForegroundColorSpan(tagColor);
            builder1.setSpan(redSpan, 0, tagStr.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        setText(builder1);
    }
}
