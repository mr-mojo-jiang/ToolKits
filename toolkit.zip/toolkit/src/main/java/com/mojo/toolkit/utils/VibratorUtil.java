package com.mojo.toolkit.utils;

import android.content.Context;
import android.os.Build;
import android.os.Vibrator;

import androidx.annotation.RequiresApi;

public class VibratorUtil {

    public static void vibrate(Context context,long millis){
        Vibrator vibrator = (Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(millis);
    }
}
