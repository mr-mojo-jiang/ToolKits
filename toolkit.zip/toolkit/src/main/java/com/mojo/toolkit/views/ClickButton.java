package com.mojo.toolkit.views;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

public class ClickButton extends androidx.appcompat.widget.AppCompatButton implements ValueAnimator.AnimatorUpdateListener {
    private Paint mGradientPaint;
    private static final int START_COLOR = 0X00FFFFFF;
    private static final int END_COLOR = 0xFF58FAAC;
    private float mTouchX;
    private float mTouchY;
    private float mRadius;
    private AnimatorSet animationSet;
    private int balpha = 255;

    public ClickButton(Context context) {
        this(context, null,0);
    }

    public ClickButton(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs,0);
    }

    public ClickButton(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init(){
        this.setGravity(Gravity.CENTER);
        mGradientPaint = new Paint();
    }

    public int getBalpha() {
        return balpha;
    }

    public void setBalpha(int balpha) {
        this.balpha = balpha;
    }

    public float getMRadius() {
        return mRadius;
    }

    public void setMRadius(float mRadius) {
        this.mRadius = mRadius;
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_DOWN) {
            return super.onTouchEvent(event);
        }

        mTouchX = event.getX();
        mTouchY = event.getY();
        RadialGradient radialGradient = new RadialGradient(mTouchX, mTouchY, 150,
                0x00dddddd, 0x00FFFFFF, Shader.TileMode.CLAMP);
//            mGradientPaint.setShader(radialGradient); //shader暂不使用
        mGradientPaint.setColor(Color.GRAY);
//            Logger.i(TAG, "onTouchEvent: " + mTouchx + " mTouchy " + mTouchy, "oddshou");
        startAnimation();
        return super.onTouchEvent(event);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mGradientPaint.setAlpha(balpha);
        canvas.drawCircle(mTouchX, mTouchY, mRadius, mGradientPaint);
    }

    private void createAnimation() {
        if (animationSet == null) {
            animationSet = new AnimatorSet();
            ValueAnimator animation1 = ObjectAnimator.ofFloat(this, "mRadius", 0, 800);
            animation1.setDuration(1000);
            animation1.setInterpolator(new LinearInterpolator());
            animation1.addUpdateListener(this);

            ValueAnimator animator2 = ObjectAnimator.ofInt(this, "balpha", 255, 0);
            animator2.setDuration(1000);
            animator2.setInterpolator(new DecelerateInterpolator());
            animationSet.play(animation1).with(animator2);
        }
    }

    public void startAnimation(){
        //构建动画，执行动画
        createAnimation();
        animationSet.start();
    }

    public void onAnimationUpdate(ValueAnimator animation) {
        invalidate();
    }
}
