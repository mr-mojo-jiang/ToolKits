package com.mojo.toolkit.views;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.annotation.Nullable;

public class HindTextView extends androidx.appcompat.widget.AppCompatTextView {
    private boolean showWhole = false;//

    public HindTextView(Context context) {
        this(context, null,0);
    }

    public HindTextView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs,0);
    }

    public HindTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init(){
        this.setLines(1);
        this.setEllipsize(TextUtils.TruncateAt.END);
        invalidate();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_UP){
            this.setSingleLine(showWhole);
            showWhole = !showWhole;
        }
        return true;
    }
}
