package com.mojo.toolkit.views.LineView;

public enum Location {
    Left,
    Right,
    Top,
    Bottom
}
