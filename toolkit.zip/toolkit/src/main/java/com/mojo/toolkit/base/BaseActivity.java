package com.mojo.toolkit.base;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.mojo.toolkit.manager.ActivityManager;
import com.mojo.toolkit.manager.InputManager;
import com.mojo.toolkit.manager.ProgressManager;
import com.mojo.toolkit.manager.VersionManager;
import com.mojo.toolkit.utils.DecorViewUtil;
import com.mojo.toolkit.utils.StatusBarUtils;
import com.mojo.toolkit.utils.ViewClickUtil;

/**
 * BaseActivity
 * P,中间桥梁，用于连接View（Activity）与Model。
 * CONTRACT，
 */
public abstract class BaseActivity<P extends BasePresenter<?, ?, ?>, M extends BaseModel<?, ?>, CONTRACT> extends AppCompatActivity {
    public P presenter;
    public M model;
    public Context context;
    public ProgressBar pb;
    public BaseActivity<P, M, CONTRACT> baseActivity;
    public String tag;
    private InputMethodManager imm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getContentViewId());

        tag = getClass().getSimpleName();
        pb = ProgressManager.createProgressBar(this);
        ActivityManager.getAppInstance().addActivity(this);//将当前activity添加进入管理栈
        context = this;
        baseActivity = this;
        presenter = getPresenterInstance(getContract());
        model = getModelInstance(presenter, getContract());
        initView();
        initData();
        initListener();
    }

    protected abstract void initData();


    public abstract int getContentViewId();

    public abstract void initView();

    public abstract void initListener();

    public abstract P getPresenterInstance(CONTRACT v);

    public abstract M getModelInstance(P p, CONTRACT contract);

    /*隐藏标题栏*/
    public void hindActionBar() {
        StatusBarUtils.with(this).init();
    }

    /*检查更新*/
    public void checkUpdate(String checkVersionUrl) {
        VersionManager.getInstance(context).checkVersion(checkVersionUrl);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (presenter != null)
            presenter.unBindView();
        if (model != null)
            model.unBindView();
    }

    public abstract CONTRACT getContract();

    public Context getContext() {
        return context;
    }

    ;

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_UP) {
            disPathActionUp(ev);
        }
        return super.dispatchTouchEvent(ev);
    }

    private void disPathActionUp(MotionEvent ev) {
        boolean clickEdit = false;
        View clickView = null;
        for (View view : DecorViewUtil.getAllChildViews(context)) {
            if (view != pb && ViewClickUtil.isClickView(ev, view)) {
                clickEdit = ViewClickUtil.isClickEdit(ev, view);
                clickView = view;
            }
        }
        onScreenClick(clickView);
        if (!clickEdit) {
            hindKeyboard(context);
        }
    }

    /**
     * @param view 点击的View
     */
    public void onScreenClick(View view) {
    }

    /**
     * 隐藏软键盘
     */
    public void hindKeyboard(Context context) {
        if (imm == null) {
            imm = InputManager.getImm(context);
        }
        InputManager.hindKeyboard(context);
    }

    /**
     * 显示ProgressBar
     */
    public void showProgressBar() {
        if (pb.getVisibility() != View.VISIBLE)
            pb.setVisibility(View.VISIBLE);
    }

    /**
     * 隐藏ProgressBar
     */
    public void hideProgressBar() {
        if (pb.getVisibility() != View.GONE)
            pb.setVisibility(View.GONE);
    }
}
