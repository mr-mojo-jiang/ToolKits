package com.mojo.toolkit.views.MultiListView;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MultiListView extends HorizontalScrollView implements MultiAdapter.OnItemClickListener {
    private final Context mContext;
    private OnItemSelectListener onItemSelectListener;
    private List<GradeView> gradeViewList;
    private LinearLayout rootView;

    public MultiListView(Context context) {
        this(context, null);
    }

    public MultiListView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MultiListView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        initView();
    }

    private void initView() {
        rootView = new LinearLayout(mContext);
        rootView.setLayoutParams(new ViewGroup.LayoutParams(-1,-1));
        this.addView(rootView);
        rootView.setOrientation(LinearLayout.HORIZONTAL);
        gradeViewList = new ArrayList<>();
    }

    private MultiAdapter createRecyclerView(int tier) {
        TextView vl = null;
        if (tier > 0) {
            //添加竖向分割线
            vl = new TextView(mContext);
            vl.setBackgroundColor(0x0ffF3F4F6);
            LayoutParams params = new LayoutParams(2, -1);
            vl.setLayoutParams(params);
            rootView.addView(vl);
        }
        RecyclerView rv = new RecyclerView(mContext);
        rv.setLayoutManager(new LinearLayoutManager(mContext));
        MultiAdapter adapter = new MultiAdapter(mContext, tier);
        adapter.setOnItemClickListener(this);
        rv.setAdapter(adapter);
        rootView.addView(rv);
        gradeViewList.add(new GradeView(vl, rv));
        return adapter;
    }

    public void setData(List<MultiItem> multiItems) {
        MultiAdapter multiAdapter = createRecyclerView(0);
        multiAdapter.setItemList(multiItems);
    }

    public void setOnItemSelectListener(OnItemSelectListener onItemSelectListener) {
        this.onItemSelectListener = onItemSelectListener;
    }

    @Override
    public void onItemClick(MultiItem item, int tier) {
        MultiAdapter multiAdapter = null;
        Iterator<GradeView> iterator = gradeViewList.iterator();
        while (iterator.hasNext()) {
            MultiAdapter ma = (MultiAdapter) iterator.next().rv.getAdapter();
            if (ma != null) {
                if (ma.getTier() == tier + 1) {
                    multiAdapter = ma;
                } else if (ma.getTier() > tier + 1) {
                    iterator.remove();
                }
            }
        }
        rootView.removeAllViews();
        for (GradeView itemView : gradeViewList) {
            if (itemView.vl != null) rootView.addView(itemView.vl);
            rootView.addView(itemView.rv);
        }
        if (multiAdapter == null && !item.getValues().isEmpty()) {
            multiAdapter = createRecyclerView(tier + 1);
        }
        if (multiAdapter != null)
            multiAdapter.setItemList(item.getValues());
        onItemSelectListener.onItemSelect(item);
    }


    /**
     * 没一层菜单都由一个TextView（竖向分割线）和一个RecyclerView构成
     * 第一层没有vl 为null
     */
    static class GradeView {
        TextView vl;
        RecyclerView rv;

        public GradeView(TextView vl, RecyclerView rv) {
            this.vl = vl;
            this.rv = rv;
        }
    }
}
